"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // kwirth-globals:@kwirthmagnify/kwirth-common
  var require_kwirth_common = __commonJS({
    "kwirth-globals:@kwirthmagnify/kwirth-common"(exports, module) {
      module.exports = window.__kwirth__.kwirthCommon;
    }
  });

  // kwirth-globals:react
  var require_react = __commonJS({
    "kwirth-globals:react"(exports, module) {
      module.exports = window.__kwirth__.React;
    }
  });

  // kwirth-globals:@mui/material
  var require_material = __commonJS({
    "kwirth-globals:@mui/material"(exports, module) {
      module.exports = window.__kwirth__.MUI.material;
    }
  });

  // kwirth-globals:@mui/icons-material
  var require_icons_material = __commonJS({
    "kwirth-globals:@mui/icons-material"(exports, module) {
      module.exports = window.__kwirth__.MUI.icons;
    }
  });

  // src/front/NewsChannel.ts
  var import_kwirth_common2 = __toESM(require_kwirth_common(), 1);

  // src/front/NewsConfig.ts
  var feedsAvailable = ["kubernetes", "ai"];
  var NewsChannelConfig = class {
    constructor() {
      this.maxItems = 50;
    }
  };
  var NewsInstanceConfig = class {
    constructor() {
      this.selectedFeeds = [...feedsAvailable];
    }
  };

  // src/front/NewsData.ts
  var NewsData = class {
    constructor() {
      this.items = [];
      this.paused = false;
      this.started = false;
    }
  };

  // src/front/NewsSetup.tsx
  var import_react = __toESM(require_react(), 1);
  var import_material = __toESM(require_material(), 1);
  var import_icons_material = __toESM(require_icons_material(), 1);
  var NewsIcon = /* @__PURE__ */ import_react.default.createElement(import_icons_material.Newspaper, null);
  var NewsSetup = (props) => {
    const newsInstanceConfig = props.setupConfig?.channelInstanceConfig || new NewsInstanceConfig();
    const newsChannelConfig = props.setupConfig?.channelConfig || new NewsChannelConfig();
    const [maxItems, setMaxItems] = (0, import_react.useState)(newsChannelConfig.maxItems);
    const [selectedFeeds, setSelectedFeeds] = (0, import_react.useState)(newsInstanceConfig.selectedFeeds ?? [...feedsAvailable]);
    const defaultRef = (0, import_react.useRef)(null);
    const toggleFeed = (feed) => {
      setSelectedFeeds((prev) => prev.includes(feed) ? prev.filter((f) => f !== feed) : [...prev, feed]);
    };
    const ok = () => {
      newsChannelConfig.maxItems = maxItems;
      newsInstanceConfig.selectedFeeds = selectedFeeds;
      props.onChannelSetupClosed(props.channel, {
        channelId: props.channel.channelId,
        channelConfig: newsChannelConfig,
        channelInstanceConfig: newsInstanceConfig
      }, true, defaultRef.current?.checked || false);
    };
    const cancel = () => {
      props.onChannelSetupClosed(props.channel, {
        channelId: props.channel.channelId,
        channelConfig: void 0,
        channelInstanceConfig: void 0
      }, false, false);
    };
    return /* @__PURE__ */ import_react.default.createElement(import_material.Dialog, { open: true, maxWidth: false, sx: { "& .MuiDialog-paper": { width: "25vw", maxWidth: "35vw" } } }, /* @__PURE__ */ import_react.default.createElement(import_material.DialogTitle, null, "Configure News channel"), /* @__PURE__ */ import_react.default.createElement(import_material.DialogContent, null, /* @__PURE__ */ import_react.default.createElement(import_material.Stack, { direction: "column", spacing: 1, sx: { m: 1 } }, /* @__PURE__ */ import_react.default.createElement(import_material.TextField, { value: maxItems, onChange: (e) => setMaxItems(+e.target.value), type: "number", variant: "standard", label: "Max items", fullWidth: true }), /* @__PURE__ */ import_react.default.createElement(import_material.Typography, { variant: "body2", sx: { mt: 1 } }, /* @__PURE__ */ import_react.default.createElement("b", null, "Topics")), feedsAvailable.map((feed) => /* @__PURE__ */ import_react.default.createElement(
      import_material.FormControlLabel,
      {
        key: feed,
        control: /* @__PURE__ */ import_react.default.createElement(import_material.Checkbox, { checked: selectedFeeds.includes(feed), onChange: () => toggleFeed(feed) }),
        label: feed
      }
    )))), /* @__PURE__ */ import_react.default.createElement(import_material.DialogActions, null, /* @__PURE__ */ import_react.default.createElement(import_material.FormControlLabel, { control: /* @__PURE__ */ import_react.default.createElement(import_material.Checkbox, { slotProps: { input: { ref: defaultRef } } }), label: "Set as default", sx: { width: "100%", ml: "8px" } }), /* @__PURE__ */ import_react.default.createElement(import_material.Button, { onClick: ok }, "OK"), /* @__PURE__ */ import_react.default.createElement(import_material.Button, { onClick: cancel }, "CANCEL")));
  };

  // src/front/NewsTabContent.tsx
  var import_react2 = __toESM(require_react(), 1);
  var import_material2 = __toESM(require_material(), 1);
  var import_icons_material2 = __toESM(require_icons_material(), 1);
  var import_kwirth_common = __toESM(require_kwirth_common(), 1);
  var NewsTabContent = (props) => {
    const newsData = props.channelObject.data;
    const newsConfig = props.channelObject.config;
    if (!newsData || !newsConfig) return /* @__PURE__ */ import_react2.default.createElement(import_react2.default.Fragment, null);
    const newsBoxRef = (0, import_react2.useRef)(null);
    const [newsBoxTop, setNewsBoxTop] = (0, import_react2.useState)(0);
    (0, import_react2.useEffect)(() => {
      if (newsBoxRef.current) setNewsBoxTop(newsBoxRef.current.getBoundingClientRect().top);
    });
    const categoryColors = {
      kubernetes: "primary",
      ai: "secondary"
    };
    const categoryColor = (category) => categoryColors[category] ?? "default";
    const formatDate = (pubDate) => {
      const d = new Date(pubDate);
      if (isNaN(d.getTime())) return pubDate;
      return d.toLocaleDateString() + " " + d.toLocaleTimeString();
    };
    const plainText = (html) => {
      const decode = (s) => {
        const div = document.createElement("div");
        div.innerHTML = s;
        return (div.textContent ?? div.innerText ?? "").trim();
      };
      return decode(decode(html)).replace(/<[^>]*>/g, "").trim();
    };
    const showItems = () => {
      if (!newsData?.items) return /* @__PURE__ */ import_react2.default.createElement(import_react2.default.Fragment, null);
      return [...newsData.items].sort((a, b) => new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime()).map((item, index) => /* @__PURE__ */ import_react2.default.createElement(import_material2.Box, { key: index, sx: { mb: 1, p: 1, borderBottom: "1px solid", borderColor: "divider" } }, /* @__PURE__ */ import_react2.default.createElement(import_material2.Stack, { direction: "row", alignItems: "center", spacing: 1, sx: { mb: 0.5 } }, /* @__PURE__ */ import_react2.default.createElement(import_material2.Chip, { label: item.category, color: categoryColor(item.category), size: "small" }), /* @__PURE__ */ import_react2.default.createElement(import_material2.Chip, { label: item.source, variant: "outlined", size: "small" }), /* @__PURE__ */ import_react2.default.createElement(import_material2.Typography, { variant: "caption", color: "text.secondary" }, formatDate(item.pubDate))), /* @__PURE__ */ import_react2.default.createElement(import_material2.Link, { href: item.link, target: "_blank", rel: "noopener", underline: "hover" }, /* @__PURE__ */ import_react2.default.createElement(import_material2.Typography, { variant: "body2", fontWeight: "bold" }, item.title)), item.description && /* @__PURE__ */ import_react2.default.createElement(import_material2.Typography, { variant: "caption", color: "text.secondary", display: "block", sx: { mt: 0.5 } }, plainText(item.description))));
    };
    const isCluster = props.channelObject.view === import_kwirth_common.EInstanceConfigView.CLUSTER;
    const resourceParts = [];
    if (!isCluster) {
      if (props.channelObject.namespace) resourceParts.push(`namespaces: ${props.channelObject.namespace}`);
      if (props.channelObject.group) resourceParts.push(`groups: ${props.channelObject.group}`);
      if (props.channelObject.pod) resourceParts.push(`pods: ${props.channelObject.pod}`);
      if (props.channelObject.container) resourceParts.push(`containers: ${props.channelObject.container}`);
    }
    return /* @__PURE__ */ import_react2.default.createElement(import_react2.default.Fragment, null, newsData.started && /* @__PURE__ */ import_react2.default.createElement(import_material2.Card, { sx: { display: "flex", flexDirection: "column", flex: 1, width: "98%", alignSelf: "center", marginTop: "8px", minHeight: 0 } }, /* @__PURE__ */ import_react2.default.createElement(import_material2.CardHeader, { title: /* @__PURE__ */ import_react2.default.createElement(import_material2.Stack, { direction: "row", alignItems: "center" }, /* @__PURE__ */ import_react2.default.createElement(import_material2.Typography, { marginRight: "32px" }, /* @__PURE__ */ import_react2.default.createElement("b", null, "Items:"), " ", newsData.items.length, " / ", newsConfig.maxItems), /* @__PURE__ */ import_react2.default.createElement(import_material2.Typography, { marginRight: "32px", flex: 1 }, /* @__PURE__ */ import_react2.default.createElement(import_icons_material2.Info, { fontSize: "small", sx: { marginBottom: "2px" } }), /* @__PURE__ */ import_react2.default.createElement("b", null, "\xA0Status:"), " ", newsData.paused ? "paused" : "started"), /* @__PURE__ */ import_react2.default.createElement(import_material2.Typography, null, /* @__PURE__ */ import_react2.default.createElement("b", null, "Mode:"), " ", isCluster ? "cluster" : "resourced")) }), /* @__PURE__ */ import_react2.default.createElement(import_material2.CardContent, { sx: { flex: 1, display: "flex", flexDirection: "column", minHeight: 0, p: 0, "&:last-child": { pb: 0 } } }, !isCluster && resourceParts.length > 0 && /* @__PURE__ */ import_react2.default.createElement(import_material2.Box, { sx: { px: 1, py: 0.5, bgcolor: "action.hover", borderBottom: "1px solid", borderColor: "divider" } }, /* @__PURE__ */ import_react2.default.createElement(import_material2.Typography, { variant: "caption", color: "text.secondary" }, /* @__PURE__ */ import_react2.default.createElement("b", null, "Resources:"), " ", resourceParts.join(" \xB7 "))), /* @__PURE__ */ import_react2.default.createElement(import_material2.Box, { ref: newsBoxRef, sx: { display: "flex", flexDirection: "column", width: "100%", overflowY: "auto", flexGrow: 1, height: `calc(100vh - ${newsBoxTop}px - 16px)` } }, /* @__PURE__ */ import_react2.default.createElement(import_material2.Box, { sx: { flex: 1, overflowY: "auto", ml: 1, mr: 1 } }, showItems())))));
  };

  // src/front/NewsChannel.ts
  var NewsChannel = class {
    constructor() {
      this.setupVisible = false;
      this.SetupDialog = NewsSetup;
      this.TabContent = NewsTabContent;
      this.channelId = "news";
      this.requirements = {
        accessString: false,
        clusterUrl: false,
        clusterInfo: false,
        exit: false,
        frontChannels: false,
        metrics: false,
        notifier: true,
        notifications: true,
        setup: true,
        settings: false,
        palette: false,
        userSettings: false,
        webSocket: false
      };
    }
    getScope() {
      return import_kwirth_common2.EInstanceConfigScope.NONE;
    }
    getChannelIcon() {
      return NewsIcon;
    }
    getSetupVisibility() {
      return this.setupVisible;
    }
    setSetupVisibility(visibility) {
      this.setupVisible = visibility;
    }
    processChannelMessage(channelObject, wsEvent) {
      const msg = JSON.parse(wsEvent.data);
      const newsData = channelObject.data;
      const newsConfig = channelObject.config;
      switch (msg.type) {
        case import_kwirth_common2.EInstanceMessageType.DATA:
          if (msg.item) {
            newsData.items.unshift(msg.item);
            while (newsData.items.length > newsConfig.maxItems) newsData.items.pop();
          }
          return { action: 1 /* REFRESH */ };
        case import_kwirth_common2.EInstanceMessageType.SIGNAL: {
          const instanceMessage = JSON.parse(wsEvent.data);
          if (instanceMessage.flow === import_kwirth_common2.EInstanceMessageFlow.RESPONSE && instanceMessage.action === import_kwirth_common2.EInstanceMessageAction.START) {
            channelObject.instanceId = instanceMessage.instance;
          }
          return { action: 1 /* REFRESH */ };
        }
        default:
          return { action: 0 /* NONE */ };
      }
    }
    async initChannel(channelObject) {
      channelObject.instanceConfig = new NewsInstanceConfig();
      channelObject.config = new NewsChannelConfig();
      channelObject.data = new NewsData();
      return false;
    }
    startChannel(channelObject) {
      const newsData = channelObject.data;
      newsData.items = [];
      newsData.paused = false;
      newsData.started = true;
      return true;
    }
    pauseChannel(channelObject) {
      const newsData = channelObject.data;
      newsData.paused = true;
      return true;
    }
    continueChannel(channelObject) {
      const newsData = channelObject.data;
      newsData.paused = false;
      return true;
    }
    stopChannel(channelObject) {
      const newsData = channelObject.data;
      newsData.paused = false;
      newsData.started = false;
      return true;
    }
    socketDisconnected(_channelObject) {
      return false;
    }
    socketReconnect(_channelObject) {
      return false;
    }
  };

  // src/front/index.ts
  window.__kwirth_plugins__ = window.__kwirth_plugins__ || {};
  window.__kwirth_plugins__["news"] = NewsChannel;
})();
