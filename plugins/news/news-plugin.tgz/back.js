"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/back.ts
var back_exports = {};
__export(back_exports, {
  default: () => back_default
});
module.exports = __toCommonJS(back_exports);
var import_kwirth_common = require("@kwirthmagnify/kwirth-common");
var import_https = __toESM(require("https"), 1);
var import_http = __toESM(require("http"), 1);
var POLL_INTERVAL_MS = 5 * 60 * 1e3;
var FEEDS = {
  kubernetes: { url: "https://kubernetes.io/feed.xml", source: "kubernetes.io" },
  ai: { url: "https://techcrunch.com/category/artificial-intelligence/feed/", source: "techcrunch.com" }
};
var NewsChannel = class {
  constructor(clusterInfo, backChannelObject) {
    this.channelId = "news";
    this.requirements = { storage: false, providers: [] };
    this.webSockets = [];
    this.getChannelData = () => ({
      id: "news",
      routable: false,
      pauseable: true,
      modifiable: false,
      reconnectable: true,
      metrics: false,
      sources: [import_kwirth_common.EClusterType.KUBERNETES, import_kwirth_common.EClusterType.DOCKER],
      endpoints: [],
      websocket: false,
      cluster: true,
      resourced: true
    });
    this.getChannelScopeLevel = (_scope) => 0;
    this.startChannel = async () => {
    };
    this.containsAsset = (webSocket, podNamespace, podName, containerName) => {
      const socket = this.webSockets.find((s) => s.ws === webSocket);
      if (socket) return socket.instances.some((i) => i.assets.some((a) => a.podNamespace === podNamespace && a.podName === podName && a.containerName === containerName));
      return false;
    };
    this.containsInstance = (instanceId) => this.webSockets.some((socket) => socket.instances.some((i) => i.instanceId === instanceId));
    this.processCommand = async (_webSocket, _instanceMessage) => true;
    this.addObject = async (webSocket, instanceConfig, podNamespace, podName, containerName) => {
      let socket = this.webSockets.find((s) => s.ws === webSocket);
      if (!socket) {
        const len = this.webSockets.push({ ws: webSocket, lastRefresh: Date.now(), instances: [] });
        socket = this.webSockets[len - 1];
      }
      let instance = socket.instances.find((i) => i.instanceId === instanceConfig.instance);
      if (!instance) {
        const newInstance = {
          accessKey: (0, import_kwirth_common.accessKeyDeserialize)(instanceConfig.accessKey),
          instanceId: instanceConfig.instance,
          selectedFeeds: instanceConfig.data?.selectedFeeds ?? Object.keys(FEEDS),
          paused: false,
          seenLinks: /* @__PURE__ */ new Set(),
          assets: []
        };
        socket.instances.push(newInstance);
        instance = newInstance;
        instance.pollInterval = setInterval((ws, i) => this.pollFeeds(ws, i), POLL_INTERVAL_MS, webSocket, instance);
        this.pollFeeds(webSocket, instance);
      }
      instance.assets.push({ podNamespace, podName, containerName });
      return true;
    };
    this.deleteObject = async (_webSocket, _instanceConfig, _podNamespace, _podName, _containerName) => true;
    this.pauseContinueInstance = (webSocket, instanceConfig, action) => {
      const instance = this.getInstance(webSocket, instanceConfig.instance);
      if (instance) {
        if (action === import_kwirth_common.EInstanceMessageAction.PAUSE) instance.paused = true;
        if (action === import_kwirth_common.EInstanceMessageAction.CONTINUE) instance.paused = false;
      } else {
        this.sendSignalMessage(webSocket, action, import_kwirth_common.EInstanceMessageFlow.RESPONSE, import_kwirth_common.ESignalMessageLevel.ERROR, instanceConfig.instance, "News instance not found");
      }
    };
    this.modifyInstance = (_webSocket, _instanceConfig) => {
    };
    this.stopInstance = (webSocket, instanceConfig) => {
      const instance = this.getInstance(webSocket, instanceConfig.instance);
      if (instance) {
        this.removeInstance(webSocket, instanceConfig.instance);
        this.sendSignalMessage(webSocket, import_kwirth_common.EInstanceMessageAction.STOP, import_kwirth_common.EInstanceMessageFlow.RESPONSE, import_kwirth_common.ESignalMessageLevel.INFO, instanceConfig.instance, "News instance stopped");
      } else {
        this.sendSignalMessage(webSocket, import_kwirth_common.EInstanceMessageAction.STOP, import_kwirth_common.EInstanceMessageFlow.RESPONSE, import_kwirth_common.ESignalMessageLevel.ERROR, instanceConfig.instance, "News instance not found");
      }
    };
    this.removeInstance = (webSocket, instanceId) => {
      const socket = this.webSockets.find((s) => s.ws === webSocket);
      if (socket) {
        const pos = socket.instances.findIndex((i) => i.instanceId === instanceId);
        if (pos >= 0) {
          clearInterval(socket.instances[pos].pollInterval);
          socket.instances.splice(pos, 1);
        }
      }
    };
    this.containsConnection = (webSocket) => Boolean(this.webSockets.find((s) => s.ws === webSocket));
    this.removeConnection = (webSocket) => {
      const socket = this.webSockets.find((s) => s.ws === webSocket);
      if (socket) {
        for (const instance of socket.instances) clearInterval(instance.pollInterval);
        const pos = this.webSockets.findIndex((s) => s.ws === webSocket);
        this.webSockets.splice(pos, 1);
      }
    };
    this.refreshConnection = (webSocket) => {
      const socket = this.webSockets.find((s) => s.ws === webSocket);
      if (socket) {
        socket.lastRefresh = Date.now();
        return true;
      }
      return false;
    };
    this.updateConnection = (newWebSocket, instanceId) => {
      for (const entry of this.webSockets) {
        if (entry.instances.find((i) => i.instanceId === instanceId)) {
          entry.ws = newWebSocket;
          return true;
        }
      }
      return false;
    };
    this.fetchUrl = (url) => {
      return new Promise((resolve, reject) => {
        const protocol = url.startsWith("https") ? import_https.default : import_http.default;
        const req = protocol.get(url, { headers: { "User-Agent": "kwirth-news/1.0" } }, (res) => {
          if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            resolve(this.fetchUrl(res.headers.location));
            return;
          }
          let data = "";
          res.on("data", (chunk) => data += chunk);
          res.on("end", () => resolve(data));
          res.on("error", reject);
        });
        req.on("error", reject);
      });
    };
    this.parseRssItems = (xml, source, category) => {
      const items = [];
      const itemRegex = /<item>([\s\S]*?)<\/item>/g;
      let match;
      while ((match = itemRegex.exec(xml)) !== null) {
        const itemXml = match[1];
        const title = (/<title><!\[CDATA\[([\s\S]*?)\]\]><\/title>/.exec(itemXml) || /<title>([\s\S]*?)<\/title>/.exec(itemXml))?.[1] || "";
        const link = (/<link>([\s\S]*?)<\/link>/.exec(itemXml) || /<guid[^>]*>([\s\S]*?)<\/guid>/.exec(itemXml))?.[1] || "";
        const description = (/<description><!\[CDATA\[([\s\S]*?)\]\]><\/description>/.exec(itemXml) || /<description>([\s\S]*?)<\/description>/.exec(itemXml))?.[1] || "";
        const pubDate = /<pubDate>([\s\S]*?)<\/pubDate>/.exec(itemXml)?.[1] || (/* @__PURE__ */ new Date()).toISOString();
        if (title.trim() && link.trim()) {
          items.push({
            title: title.trim(),
            link: link.trim(),
            description: description.replace(/<[^>]*>/g, "").trim().substring(0, 300),
            pubDate: pubDate.trim(),
            source,
            category
          });
        }
      }
      return items;
    };
    this.pollFeeds = async (ws, instance) => {
      if (instance.paused) return;
      for (const category of Object.keys(FEEDS).filter((f) => instance.selectedFeeds.includes(f))) {
        const feed = FEEDS[category];
        try {
          const xml = await this.fetchUrl(feed.url);
          const items = this.parseRssItems(xml, feed.source, category);
          for (const item of items) {
            if (!instance.seenLinks.has(item.link)) {
              instance.seenLinks.add(item.link);
              const msg = {
                msgtype: "newsmessageresponse",
                channel: "news",
                action: import_kwirth_common.EInstanceMessageAction.NONE,
                flow: import_kwirth_common.EInstanceMessageFlow.UNSOLICITED,
                type: import_kwirth_common.EInstanceMessageType.DATA,
                instance: instance.instanceId,
                item
              };
              ws.send(JSON.stringify(msg));
            }
          }
        } catch (err) {
          console.log(`[news-plugin] error polling ${category}: ${err}`);
        }
      }
    };
    this.sendSignalMessage = (ws, action, flow, level, instanceId, text) => {
      const resp = { action, flow, channel: "news", instance: instanceId, type: import_kwirth_common.EInstanceMessageType.SIGNAL, text, level };
      ws.send(JSON.stringify(resp));
    };
    this.getInstance = (webSocket, instanceId) => {
      const socket = this.webSockets.find((entry) => entry.ws === webSocket);
      if (socket) return socket.instances.find((i) => i.instanceId === instanceId);
      return void 0;
    };
    this.clusterInfo = clusterInfo;
    this.backChannelObject = backChannelObject;
  }
  processProviderEvent(_providerId, _obj) {
  }
  async endpointRequest(_endpoint, _req, _res) {
  }
  async websocketRequest(_newWebSocket) {
  }
};
var back_default = NewsChannel;
