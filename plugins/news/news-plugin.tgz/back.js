"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/@kwirthmagnify/kwirth-common/dist/Channel.js
var require_Channel = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/Channel.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.EClusterType = exports2.ClusterTypeEnum = void 0;
    var ClusterTypeEnum;
    (function(ClusterTypeEnum2) {
      ClusterTypeEnum2["KUBERNETES"] = "kubernetes";
      ClusterTypeEnum2["DOCKER"] = "docker";
    })(ClusterTypeEnum || (exports2.ClusterTypeEnum = ClusterTypeEnum = {}));
    var EClusterType2;
    (function(EClusterType3) {
      EClusterType3["KUBERNETES"] = "kubernetes";
      EClusterType3["DOCKER"] = "docker";
    })(EClusterType2 || (exports2.EClusterType = EClusterType2 = {}));
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/InstanceMessage.js
var require_InstanceMessage = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/InstanceMessage.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.EInstanceMessageFlow = exports2.InstanceMessageFlowEnum = exports2.EInstanceMessageAction = exports2.InstanceMessageActionEnum = exports2.EInstanceMessageType = exports2.InstanceMessageTypeEnum = exports2.EInstanceMessageChannel = exports2.InstanceMessageChannelEnum = void 0;
    var InstanceMessageChannelEnum;
    (function(InstanceMessageChannelEnum2) {
      InstanceMessageChannelEnum2["NONE"] = "none";
      InstanceMessageChannelEnum2["LOG"] = "log";
      InstanceMessageChannelEnum2["METRICS"] = "metrics";
      InstanceMessageChannelEnum2["AUDIT"] = "audit";
      InstanceMessageChannelEnum2["OPS"] = "ops";
      InstanceMessageChannelEnum2["ALERT"] = "alert";
      InstanceMessageChannelEnum2["TRIVY"] = "trivy";
    })(InstanceMessageChannelEnum || (exports2.InstanceMessageChannelEnum = InstanceMessageChannelEnum = {}));
    var EInstanceMessageChannel;
    (function(EInstanceMessageChannel2) {
      EInstanceMessageChannel2["NONE"] = "none";
      EInstanceMessageChannel2["LOG"] = "log";
      EInstanceMessageChannel2["METRICS"] = "metrics";
      EInstanceMessageChannel2["AUDIT"] = "audit";
      EInstanceMessageChannel2["OPS"] = "ops";
      EInstanceMessageChannel2["ALERT"] = "alert";
      EInstanceMessageChannel2["TRIVY"] = "trivy";
      EInstanceMessageChannel2["MAGNIFY"] = "magnify";
    })(EInstanceMessageChannel || (exports2.EInstanceMessageChannel = EInstanceMessageChannel = {}));
    var InstanceMessageTypeEnum;
    (function(InstanceMessageTypeEnum2) {
      InstanceMessageTypeEnum2["DATA"] = "data";
      InstanceMessageTypeEnum2["SIGNAL"] = "signal";
    })(InstanceMessageTypeEnum || (exports2.InstanceMessageTypeEnum = InstanceMessageTypeEnum = {}));
    var EInstanceMessageType2;
    (function(EInstanceMessageType3) {
      EInstanceMessageType3["DATA"] = "data";
      EInstanceMessageType3["SIGNAL"] = "signal";
    })(EInstanceMessageType2 || (exports2.EInstanceMessageType = EInstanceMessageType2 = {}));
    var InstanceMessageActionEnum;
    (function(InstanceMessageActionEnum2) {
      InstanceMessageActionEnum2["NONE"] = "none";
      InstanceMessageActionEnum2["ROUTE"] = "route";
      InstanceMessageActionEnum2["START"] = "start";
      InstanceMessageActionEnum2["STOP"] = "stop";
      InstanceMessageActionEnum2["PAUSE"] = "pause";
      InstanceMessageActionEnum2["CONTINUE"] = "continue";
      InstanceMessageActionEnum2["MODIFY"] = "modify";
      InstanceMessageActionEnum2["PING"] = "ping";
      InstanceMessageActionEnum2["RECONNECT"] = "reconnect";
      InstanceMessageActionEnum2["COMMAND"] = "command";
      InstanceMessageActionEnum2["WEBSOCKET"] = "websocket";
    })(InstanceMessageActionEnum || (exports2.InstanceMessageActionEnum = InstanceMessageActionEnum = {}));
    var EInstanceMessageAction2;
    (function(EInstanceMessageAction3) {
      EInstanceMessageAction3["NONE"] = "none";
      EInstanceMessageAction3["RI"] = "ri";
      EInstanceMessageAction3["ROUTE"] = "route";
      EInstanceMessageAction3["START"] = "start";
      EInstanceMessageAction3["STOP"] = "stop";
      EInstanceMessageAction3["PAUSE"] = "pause";
      EInstanceMessageAction3["CONTINUE"] = "continue";
      EInstanceMessageAction3["MODIFY"] = "modify";
      EInstanceMessageAction3["PING"] = "ping";
      EInstanceMessageAction3["RECONNECT"] = "reconnect";
      EInstanceMessageAction3["COMMAND"] = "command";
      EInstanceMessageAction3["WEBSOCKET"] = "websocket";
    })(EInstanceMessageAction2 || (exports2.EInstanceMessageAction = EInstanceMessageAction2 = {}));
    var InstanceMessageFlowEnum;
    (function(InstanceMessageFlowEnum2) {
      InstanceMessageFlowEnum2["IMMEDIATE"] = "immediate";
      InstanceMessageFlowEnum2["REQUEST"] = "request";
      InstanceMessageFlowEnum2["RESPONSE"] = "response";
      InstanceMessageFlowEnum2["UNSOLICITED"] = "unsolicited";
    })(InstanceMessageFlowEnum || (exports2.InstanceMessageFlowEnum = InstanceMessageFlowEnum = {}));
    var EInstanceMessageFlow2;
    (function(EInstanceMessageFlow3) {
      EInstanceMessageFlow3["IMMEDIATE"] = "immediate";
      EInstanceMessageFlow3["REQUEST"] = "request";
      EInstanceMessageFlow3["RESPONSE"] = "response";
      EInstanceMessageFlow3["UNSOLICITED"] = "unsolicited";
    })(EInstanceMessageFlow2 || (exports2.EInstanceMessageFlow = EInstanceMessageFlow2 = {}));
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/InstanceConfig.js
var require_InstanceConfig = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/InstanceConfig.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.EInstanceConfigScope = exports2.EInstanceConfigView = exports2.EInstanceConfigObject = exports2.InstanceConfigScopeEnum = exports2.InstanceConfigViewEnum = exports2.InstanceConfigObjectEnum = void 0;
    var InstanceConfigObjectEnum;
    (function(InstanceConfigObjectEnum2) {
      InstanceConfigObjectEnum2["PODS"] = "pods";
      InstanceConfigObjectEnum2["EVENTS"] = "events";
    })(InstanceConfigObjectEnum || (exports2.InstanceConfigObjectEnum = InstanceConfigObjectEnum = {}));
    var InstanceConfigViewEnum;
    (function(InstanceConfigViewEnum2) {
      InstanceConfigViewEnum2["NONE"] = "none";
      InstanceConfigViewEnum2["CLUSTER"] = "cluster";
      InstanceConfigViewEnum2["NAMESPACE"] = "namespace";
      InstanceConfigViewEnum2["GROUP"] = "group";
      InstanceConfigViewEnum2["POD"] = "pod";
      InstanceConfigViewEnum2["CONTAINER"] = "container";
    })(InstanceConfigViewEnum || (exports2.InstanceConfigViewEnum = InstanceConfigViewEnum = {}));
    var InstanceConfigScopeEnum;
    (function(InstanceConfigScopeEnum2) {
      InstanceConfigScopeEnum2["NONE"] = "none";
      InstanceConfigScopeEnum2["API"] = "api";
      InstanceConfigScopeEnum2["CLUSTER"] = "cluster";
      InstanceConfigScopeEnum2["FILTER"] = "filter";
      InstanceConfigScopeEnum2["VIEW"] = "view";
      InstanceConfigScopeEnum2["SNAPSHOT"] = "snapshot";
      InstanceConfigScopeEnum2["STREAM"] = "stream";
      InstanceConfigScopeEnum2["CREATE"] = "create";
      InstanceConfigScopeEnum2["SUBSCRIBE"] = "subscribe";
      InstanceConfigScopeEnum2["GET"] = "get";
      InstanceConfigScopeEnum2["EXECUTE"] = "execute";
      InstanceConfigScopeEnum2["RESTART"] = "restart";
      InstanceConfigScopeEnum2["WORKLOAD"] = "workload";
      InstanceConfigScopeEnum2["KUBERNETES"] = "kubernetes";
    })(InstanceConfigScopeEnum || (exports2.InstanceConfigScopeEnum = InstanceConfigScopeEnum = {}));
    var EInstanceConfigObject;
    (function(EInstanceConfigObject2) {
      EInstanceConfigObject2["PODS"] = "pods";
      EInstanceConfigObject2["EVENTS"] = "events";
    })(EInstanceConfigObject || (exports2.EInstanceConfigObject = EInstanceConfigObject = {}));
    var EInstanceConfigView;
    (function(EInstanceConfigView2) {
      EInstanceConfigView2["NONE"] = "none";
      EInstanceConfigView2["CLUSTER"] = "cluster";
      EInstanceConfigView2["NAMESPACE"] = "namespace";
      EInstanceConfigView2["GROUP"] = "group";
      EInstanceConfigView2["POD"] = "pod";
      EInstanceConfigView2["CONTAINER"] = "container";
    })(EInstanceConfigView || (exports2.EInstanceConfigView = EInstanceConfigView = {}));
    var EInstanceConfigScope;
    (function(EInstanceConfigScope2) {
      EInstanceConfigScope2["NONE"] = "none";
      EInstanceConfigScope2["API"] = "api";
      EInstanceConfigScope2["CLUSTER"] = "cluster";
      EInstanceConfigScope2["FILTER"] = "filter";
      EInstanceConfigScope2["VIEW"] = "view";
      EInstanceConfigScope2["SNAPSHOT"] = "snapshot";
      EInstanceConfigScope2["STREAM"] = "stream";
      EInstanceConfigScope2["CREATE"] = "create";
      EInstanceConfigScope2["SUBSCRIBE"] = "subscribe";
      EInstanceConfigScope2["GET"] = "get";
      EInstanceConfigScope2["EXECUTE"] = "execute";
      EInstanceConfigScope2["RESTART"] = "restart";
      EInstanceConfigScope2["WORKLOAD"] = "workload";
      EInstanceConfigScope2["KUBERNETES"] = "kubernetes";
    })(EInstanceConfigScope || (exports2.EInstanceConfigScope = EInstanceConfigScope = {}));
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/RouteMessage.js
var require_RouteMessage = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/RouteMessage.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/SignalMessage.js
var require_SignalMessage = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/SignalMessage.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ESignalMessageEvent = exports2.ESignalMessageLevel = exports2.SignalMessageEventEnum = exports2.SignalMessageLevelEnum = void 0;
    var SignalMessageLevelEnum;
    (function(SignalMessageLevelEnum2) {
      SignalMessageLevelEnum2["INFO"] = "info";
      SignalMessageLevelEnum2["WARNING"] = "warning";
      SignalMessageLevelEnum2["ERROR"] = "error";
    })(SignalMessageLevelEnum || (exports2.SignalMessageLevelEnum = SignalMessageLevelEnum = {}));
    var SignalMessageEventEnum;
    (function(SignalMessageEventEnum2) {
      SignalMessageEventEnum2["ADD"] = "add";
      SignalMessageEventEnum2["DELETE"] = "delete";
      SignalMessageEventEnum2["OTHER"] = "other";
    })(SignalMessageEventEnum || (exports2.SignalMessageEventEnum = SignalMessageEventEnum = {}));
    var ESignalMessageLevel2;
    (function(ESignalMessageLevel3) {
      ESignalMessageLevel3["INFO"] = "info";
      ESignalMessageLevel3["WARNING"] = "warning";
      ESignalMessageLevel3["ERROR"] = "error";
    })(ESignalMessageLevel2 || (exports2.ESignalMessageLevel = ESignalMessageLevel2 = {}));
    var ESignalMessageEvent;
    (function(ESignalMessageEvent2) {
      ESignalMessageEvent2["ADD"] = "add";
      ESignalMessageEvent2["DELETE"] = "delete";
      ESignalMessageEvent2["OTHER"] = "other";
    })(ESignalMessageEvent || (exports2.ESignalMessageEvent = ESignalMessageEvent = {}));
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/ApiKey.js
var require_ApiKey = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/ApiKey.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// node_modules/uuid/dist/cjs/max.js
var require_max = __commonJS({
  "node_modules/uuid/dist/cjs/max.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.default = "ffffffff-ffff-ffff-ffff-ffffffffffff";
  }
});

// node_modules/uuid/dist/cjs/nil.js
var require_nil = __commonJS({
  "node_modules/uuid/dist/cjs/nil.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.default = "00000000-0000-0000-0000-000000000000";
  }
});

// node_modules/uuid/dist/cjs/regex.js
var require_regex = __commonJS({
  "node_modules/uuid/dist/cjs/regex.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.default = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/i;
  }
});

// node_modules/uuid/dist/cjs/validate.js
var require_validate = __commonJS({
  "node_modules/uuid/dist/cjs/validate.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var regex_js_1 = require_regex();
    function validate(uuid) {
      return typeof uuid === "string" && regex_js_1.default.test(uuid);
    }
    exports2.default = validate;
  }
});

// node_modules/uuid/dist/cjs/parse.js
var require_parse = __commonJS({
  "node_modules/uuid/dist/cjs/parse.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var validate_js_1 = require_validate();
    function parse(uuid) {
      if (!(0, validate_js_1.default)(uuid)) {
        throw TypeError("Invalid UUID");
      }
      let v;
      return Uint8Array.of((v = parseInt(uuid.slice(0, 8), 16)) >>> 24, v >>> 16 & 255, v >>> 8 & 255, v & 255, (v = parseInt(uuid.slice(9, 13), 16)) >>> 8, v & 255, (v = parseInt(uuid.slice(14, 18), 16)) >>> 8, v & 255, (v = parseInt(uuid.slice(19, 23), 16)) >>> 8, v & 255, (v = parseInt(uuid.slice(24, 36), 16)) / 1099511627776 & 255, v / 4294967296 & 255, v >>> 24 & 255, v >>> 16 & 255, v >>> 8 & 255, v & 255);
    }
    exports2.default = parse;
  }
});

// node_modules/uuid/dist/cjs/stringify.js
var require_stringify = __commonJS({
  "node_modules/uuid/dist/cjs/stringify.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.unsafeStringify = void 0;
    var validate_js_1 = require_validate();
    var byteToHex = [];
    for (let i = 0; i < 256; ++i) {
      byteToHex.push((i + 256).toString(16).slice(1));
    }
    function unsafeStringify(arr, offset = 0) {
      return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
    }
    exports2.unsafeStringify = unsafeStringify;
    function stringify(arr, offset = 0) {
      const uuid = unsafeStringify(arr, offset);
      if (!(0, validate_js_1.default)(uuid)) {
        throw TypeError("Stringified UUID is invalid");
      }
      return uuid;
    }
    exports2.default = stringify;
  }
});

// node_modules/uuid/dist/cjs/rng.js
var require_rng = __commonJS({
  "node_modules/uuid/dist/cjs/rng.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var crypto_1 = require("crypto");
    var rnds8Pool = new Uint8Array(256);
    var poolPtr = rnds8Pool.length;
    function rng() {
      if (poolPtr > rnds8Pool.length - 16) {
        (0, crypto_1.randomFillSync)(rnds8Pool);
        poolPtr = 0;
      }
      return rnds8Pool.slice(poolPtr, poolPtr += 16);
    }
    exports2.default = rng;
  }
});

// node_modules/uuid/dist/cjs/v1.js
var require_v1 = __commonJS({
  "node_modules/uuid/dist/cjs/v1.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.updateV1State = void 0;
    var rng_js_1 = require_rng();
    var stringify_js_1 = require_stringify();
    var _state = {};
    function v1(options, buf, offset) {
      let bytes;
      const isV6 = options?._v6 ?? false;
      if (options) {
        const optionsKeys = Object.keys(options);
        if (optionsKeys.length === 1 && optionsKeys[0] === "_v6") {
          options = void 0;
        }
      }
      if (options) {
        bytes = v1Bytes(options.random ?? options.rng?.() ?? (0, rng_js_1.default)(), options.msecs, options.nsecs, options.clockseq, options.node, buf, offset);
      } else {
        const now = Date.now();
        const rnds = (0, rng_js_1.default)();
        updateV1State(_state, now, rnds);
        bytes = v1Bytes(rnds, _state.msecs, _state.nsecs, isV6 ? void 0 : _state.clockseq, isV6 ? void 0 : _state.node, buf, offset);
      }
      return buf ?? (0, stringify_js_1.unsafeStringify)(bytes);
    }
    function updateV1State(state, now, rnds) {
      state.msecs ??= -Infinity;
      state.nsecs ??= 0;
      if (now === state.msecs) {
        state.nsecs++;
        if (state.nsecs >= 1e4) {
          state.node = void 0;
          state.nsecs = 0;
        }
      } else if (now > state.msecs) {
        state.nsecs = 0;
      } else if (now < state.msecs) {
        state.node = void 0;
      }
      if (!state.node) {
        state.node = rnds.slice(10, 16);
        state.node[0] |= 1;
        state.clockseq = (rnds[8] << 8 | rnds[9]) & 16383;
      }
      state.msecs = now;
      return state;
    }
    exports2.updateV1State = updateV1State;
    function v1Bytes(rnds, msecs, nsecs, clockseq, node, buf, offset = 0) {
      if (rnds.length < 16) {
        throw new Error("Random bytes length must be >= 16");
      }
      if (!buf) {
        buf = new Uint8Array(16);
        offset = 0;
      } else {
        if (offset < 0 || offset + 16 > buf.length) {
          throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
      }
      msecs ??= Date.now();
      nsecs ??= 0;
      clockseq ??= (rnds[8] << 8 | rnds[9]) & 16383;
      node ??= rnds.slice(10, 16);
      msecs += 122192928e5;
      const tl = ((msecs & 268435455) * 1e4 + nsecs) % 4294967296;
      buf[offset++] = tl >>> 24 & 255;
      buf[offset++] = tl >>> 16 & 255;
      buf[offset++] = tl >>> 8 & 255;
      buf[offset++] = tl & 255;
      const tmh = msecs / 4294967296 * 1e4 & 268435455;
      buf[offset++] = tmh >>> 8 & 255;
      buf[offset++] = tmh & 255;
      buf[offset++] = tmh >>> 24 & 15 | 16;
      buf[offset++] = tmh >>> 16 & 255;
      buf[offset++] = clockseq >>> 8 | 128;
      buf[offset++] = clockseq & 255;
      for (let n = 0; n < 6; ++n) {
        buf[offset++] = node[n];
      }
      return buf;
    }
    exports2.default = v1;
  }
});

// node_modules/uuid/dist/cjs/v1ToV6.js
var require_v1ToV6 = __commonJS({
  "node_modules/uuid/dist/cjs/v1ToV6.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var parse_js_1 = require_parse();
    var stringify_js_1 = require_stringify();
    function v1ToV6(uuid) {
      const v1Bytes = typeof uuid === "string" ? (0, parse_js_1.default)(uuid) : uuid;
      const v6Bytes = _v1ToV6(v1Bytes);
      return typeof uuid === "string" ? (0, stringify_js_1.unsafeStringify)(v6Bytes) : v6Bytes;
    }
    exports2.default = v1ToV6;
    function _v1ToV6(v1Bytes) {
      return Uint8Array.of((v1Bytes[6] & 15) << 4 | v1Bytes[7] >> 4 & 15, (v1Bytes[7] & 15) << 4 | (v1Bytes[4] & 240) >> 4, (v1Bytes[4] & 15) << 4 | (v1Bytes[5] & 240) >> 4, (v1Bytes[5] & 15) << 4 | (v1Bytes[0] & 240) >> 4, (v1Bytes[0] & 15) << 4 | (v1Bytes[1] & 240) >> 4, (v1Bytes[1] & 15) << 4 | (v1Bytes[2] & 240) >> 4, 96 | v1Bytes[2] & 15, v1Bytes[3], v1Bytes[8], v1Bytes[9], v1Bytes[10], v1Bytes[11], v1Bytes[12], v1Bytes[13], v1Bytes[14], v1Bytes[15]);
    }
  }
});

// node_modules/uuid/dist/cjs/md5.js
var require_md5 = __commonJS({
  "node_modules/uuid/dist/cjs/md5.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var crypto_1 = require("crypto");
    function md5(bytes) {
      if (Array.isArray(bytes)) {
        bytes = Buffer.from(bytes);
      } else if (typeof bytes === "string") {
        bytes = Buffer.from(bytes, "utf8");
      }
      return (0, crypto_1.createHash)("md5").update(bytes).digest();
    }
    exports2.default = md5;
  }
});

// node_modules/uuid/dist/cjs/v35.js
var require_v35 = __commonJS({
  "node_modules/uuid/dist/cjs/v35.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.URL = exports2.DNS = exports2.stringToBytes = void 0;
    var parse_js_1 = require_parse();
    var stringify_js_1 = require_stringify();
    function stringToBytes(str) {
      str = unescape(encodeURIComponent(str));
      const bytes = new Uint8Array(str.length);
      for (let i = 0; i < str.length; ++i) {
        bytes[i] = str.charCodeAt(i);
      }
      return bytes;
    }
    exports2.stringToBytes = stringToBytes;
    exports2.DNS = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";
    exports2.URL = "6ba7b811-9dad-11d1-80b4-00c04fd430c8";
    function v35(version, hash, value, namespace, buf, offset) {
      const valueBytes = typeof value === "string" ? stringToBytes(value) : value;
      const namespaceBytes = typeof namespace === "string" ? (0, parse_js_1.default)(namespace) : namespace;
      if (typeof namespace === "string") {
        namespace = (0, parse_js_1.default)(namespace);
      }
      if (namespace?.length !== 16) {
        throw TypeError("Namespace must be array-like (16 iterable integer values, 0-255)");
      }
      let bytes = new Uint8Array(16 + valueBytes.length);
      bytes.set(namespaceBytes);
      bytes.set(valueBytes, namespaceBytes.length);
      bytes = hash(bytes);
      bytes[6] = bytes[6] & 15 | version;
      bytes[8] = bytes[8] & 63 | 128;
      if (buf) {
        offset = offset || 0;
        if (offset < 0 || offset + 16 > buf.length) {
          throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
        for (let i = 0; i < 16; ++i) {
          buf[offset + i] = bytes[i];
        }
        return buf;
      }
      return (0, stringify_js_1.unsafeStringify)(bytes);
    }
    exports2.default = v35;
  }
});

// node_modules/uuid/dist/cjs/v3.js
var require_v3 = __commonJS({
  "node_modules/uuid/dist/cjs/v3.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.URL = exports2.DNS = void 0;
    var md5_js_1 = require_md5();
    var v35_js_1 = require_v35();
    var v35_js_2 = require_v35();
    Object.defineProperty(exports2, "DNS", { enumerable: true, get: function() {
      return v35_js_2.DNS;
    } });
    Object.defineProperty(exports2, "URL", { enumerable: true, get: function() {
      return v35_js_2.URL;
    } });
    function v3(value, namespace, buf, offset) {
      return (0, v35_js_1.default)(48, md5_js_1.default, value, namespace, buf, offset);
    }
    v3.DNS = v35_js_1.DNS;
    v3.URL = v35_js_1.URL;
    exports2.default = v3;
  }
});

// node_modules/uuid/dist/cjs/native.js
var require_native = __commonJS({
  "node_modules/uuid/dist/cjs/native.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var crypto_1 = require("crypto");
    exports2.default = { randomUUID: crypto_1.randomUUID };
  }
});

// node_modules/uuid/dist/cjs/v4.js
var require_v4 = __commonJS({
  "node_modules/uuid/dist/cjs/v4.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var native_js_1 = require_native();
    var rng_js_1 = require_rng();
    var stringify_js_1 = require_stringify();
    function v4(options, buf, offset) {
      if (native_js_1.default.randomUUID && !buf && !options) {
        return native_js_1.default.randomUUID();
      }
      options = options || {};
      const rnds = options.random ?? options.rng?.() ?? (0, rng_js_1.default)();
      if (rnds.length < 16) {
        throw new Error("Random bytes length must be >= 16");
      }
      rnds[6] = rnds[6] & 15 | 64;
      rnds[8] = rnds[8] & 63 | 128;
      if (buf) {
        offset = offset || 0;
        if (offset < 0 || offset + 16 > buf.length) {
          throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
        for (let i = 0; i < 16; ++i) {
          buf[offset + i] = rnds[i];
        }
        return buf;
      }
      return (0, stringify_js_1.unsafeStringify)(rnds);
    }
    exports2.default = v4;
  }
});

// node_modules/uuid/dist/cjs/sha1.js
var require_sha1 = __commonJS({
  "node_modules/uuid/dist/cjs/sha1.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var crypto_1 = require("crypto");
    function sha1(bytes) {
      if (Array.isArray(bytes)) {
        bytes = Buffer.from(bytes);
      } else if (typeof bytes === "string") {
        bytes = Buffer.from(bytes, "utf8");
      }
      return (0, crypto_1.createHash)("sha1").update(bytes).digest();
    }
    exports2.default = sha1;
  }
});

// node_modules/uuid/dist/cjs/v5.js
var require_v5 = __commonJS({
  "node_modules/uuid/dist/cjs/v5.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.URL = exports2.DNS = void 0;
    var sha1_js_1 = require_sha1();
    var v35_js_1 = require_v35();
    var v35_js_2 = require_v35();
    Object.defineProperty(exports2, "DNS", { enumerable: true, get: function() {
      return v35_js_2.DNS;
    } });
    Object.defineProperty(exports2, "URL", { enumerable: true, get: function() {
      return v35_js_2.URL;
    } });
    function v5(value, namespace, buf, offset) {
      return (0, v35_js_1.default)(80, sha1_js_1.default, value, namespace, buf, offset);
    }
    v5.DNS = v35_js_1.DNS;
    v5.URL = v35_js_1.URL;
    exports2.default = v5;
  }
});

// node_modules/uuid/dist/cjs/v6.js
var require_v6 = __commonJS({
  "node_modules/uuid/dist/cjs/v6.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var stringify_js_1 = require_stringify();
    var v1_js_1 = require_v1();
    var v1ToV6_js_1 = require_v1ToV6();
    function v6(options, buf, offset) {
      options ??= {};
      offset ??= 0;
      let bytes = (0, v1_js_1.default)({ ...options, _v6: true }, new Uint8Array(16));
      bytes = (0, v1ToV6_js_1.default)(bytes);
      if (buf) {
        if (offset < 0 || offset + 16 > buf.length) {
          throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
        for (let i = 0; i < 16; i++) {
          buf[offset + i] = bytes[i];
        }
        return buf;
      }
      return (0, stringify_js_1.unsafeStringify)(bytes);
    }
    exports2.default = v6;
  }
});

// node_modules/uuid/dist/cjs/v6ToV1.js
var require_v6ToV1 = __commonJS({
  "node_modules/uuid/dist/cjs/v6ToV1.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var parse_js_1 = require_parse();
    var stringify_js_1 = require_stringify();
    function v6ToV1(uuid) {
      const v6Bytes = typeof uuid === "string" ? (0, parse_js_1.default)(uuid) : uuid;
      const v1Bytes = _v6ToV1(v6Bytes);
      return typeof uuid === "string" ? (0, stringify_js_1.unsafeStringify)(v1Bytes) : v1Bytes;
    }
    exports2.default = v6ToV1;
    function _v6ToV1(v6Bytes) {
      return Uint8Array.of((v6Bytes[3] & 15) << 4 | v6Bytes[4] >> 4 & 15, (v6Bytes[4] & 15) << 4 | (v6Bytes[5] & 240) >> 4, (v6Bytes[5] & 15) << 4 | v6Bytes[6] & 15, v6Bytes[7], (v6Bytes[1] & 15) << 4 | (v6Bytes[2] & 240) >> 4, (v6Bytes[2] & 15) << 4 | (v6Bytes[3] & 240) >> 4, 16 | (v6Bytes[0] & 240) >> 4, (v6Bytes[0] & 15) << 4 | (v6Bytes[1] & 240) >> 4, v6Bytes[8], v6Bytes[9], v6Bytes[10], v6Bytes[11], v6Bytes[12], v6Bytes[13], v6Bytes[14], v6Bytes[15]);
    }
  }
});

// node_modules/uuid/dist/cjs/v7.js
var require_v7 = __commonJS({
  "node_modules/uuid/dist/cjs/v7.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.updateV7State = void 0;
    var rng_js_1 = require_rng();
    var stringify_js_1 = require_stringify();
    var _state = {};
    function v7(options, buf, offset) {
      let bytes;
      if (options) {
        bytes = v7Bytes(options.random ?? options.rng?.() ?? (0, rng_js_1.default)(), options.msecs, options.seq, buf, offset);
      } else {
        const now = Date.now();
        const rnds = (0, rng_js_1.default)();
        updateV7State(_state, now, rnds);
        bytes = v7Bytes(rnds, _state.msecs, _state.seq, buf, offset);
      }
      return buf ?? (0, stringify_js_1.unsafeStringify)(bytes);
    }
    function updateV7State(state, now, rnds) {
      state.msecs ??= -Infinity;
      state.seq ??= 0;
      if (now > state.msecs) {
        state.seq = rnds[6] << 23 | rnds[7] << 16 | rnds[8] << 8 | rnds[9];
        state.msecs = now;
      } else {
        state.seq = state.seq + 1 | 0;
        if (state.seq === 0) {
          state.msecs++;
        }
      }
      return state;
    }
    exports2.updateV7State = updateV7State;
    function v7Bytes(rnds, msecs, seq, buf, offset = 0) {
      if (rnds.length < 16) {
        throw new Error("Random bytes length must be >= 16");
      }
      if (!buf) {
        buf = new Uint8Array(16);
        offset = 0;
      } else {
        if (offset < 0 || offset + 16 > buf.length) {
          throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
      }
      msecs ??= Date.now();
      seq ??= rnds[6] * 127 << 24 | rnds[7] << 16 | rnds[8] << 8 | rnds[9];
      buf[offset++] = msecs / 1099511627776 & 255;
      buf[offset++] = msecs / 4294967296 & 255;
      buf[offset++] = msecs / 16777216 & 255;
      buf[offset++] = msecs / 65536 & 255;
      buf[offset++] = msecs / 256 & 255;
      buf[offset++] = msecs & 255;
      buf[offset++] = 112 | seq >>> 28 & 15;
      buf[offset++] = seq >>> 20 & 255;
      buf[offset++] = 128 | seq >>> 14 & 63;
      buf[offset++] = seq >>> 6 & 255;
      buf[offset++] = seq << 2 & 255 | rnds[10] & 3;
      buf[offset++] = rnds[11];
      buf[offset++] = rnds[12];
      buf[offset++] = rnds[13];
      buf[offset++] = rnds[14];
      buf[offset++] = rnds[15];
      return buf;
    }
    exports2.default = v7;
  }
});

// node_modules/uuid/dist/cjs/version.js
var require_version = __commonJS({
  "node_modules/uuid/dist/cjs/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var validate_js_1 = require_validate();
    function version(uuid) {
      if (!(0, validate_js_1.default)(uuid)) {
        throw TypeError("Invalid UUID");
      }
      return parseInt(uuid.slice(14, 15), 16);
    }
    exports2.default = version;
  }
});

// node_modules/uuid/dist/cjs/index.js
var require_cjs = __commonJS({
  "node_modules/uuid/dist/cjs/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.version = exports2.validate = exports2.v7 = exports2.v6ToV1 = exports2.v6 = exports2.v5 = exports2.v4 = exports2.v3 = exports2.v1ToV6 = exports2.v1 = exports2.stringify = exports2.parse = exports2.NIL = exports2.MAX = void 0;
    var max_js_1 = require_max();
    Object.defineProperty(exports2, "MAX", { enumerable: true, get: function() {
      return max_js_1.default;
    } });
    var nil_js_1 = require_nil();
    Object.defineProperty(exports2, "NIL", { enumerable: true, get: function() {
      return nil_js_1.default;
    } });
    var parse_js_1 = require_parse();
    Object.defineProperty(exports2, "parse", { enumerable: true, get: function() {
      return parse_js_1.default;
    } });
    var stringify_js_1 = require_stringify();
    Object.defineProperty(exports2, "stringify", { enumerable: true, get: function() {
      return stringify_js_1.default;
    } });
    var v1_js_1 = require_v1();
    Object.defineProperty(exports2, "v1", { enumerable: true, get: function() {
      return v1_js_1.default;
    } });
    var v1ToV6_js_1 = require_v1ToV6();
    Object.defineProperty(exports2, "v1ToV6", { enumerable: true, get: function() {
      return v1ToV6_js_1.default;
    } });
    var v3_js_1 = require_v3();
    Object.defineProperty(exports2, "v3", { enumerable: true, get: function() {
      return v3_js_1.default;
    } });
    var v4_js_1 = require_v4();
    Object.defineProperty(exports2, "v4", { enumerable: true, get: function() {
      return v4_js_1.default;
    } });
    var v5_js_1 = require_v5();
    Object.defineProperty(exports2, "v5", { enumerable: true, get: function() {
      return v5_js_1.default;
    } });
    var v6_js_1 = require_v6();
    Object.defineProperty(exports2, "v6", { enumerable: true, get: function() {
      return v6_js_1.default;
    } });
    var v6ToV1_js_1 = require_v6ToV1();
    Object.defineProperty(exports2, "v6ToV1", { enumerable: true, get: function() {
      return v6ToV1_js_1.default;
    } });
    var v7_js_1 = require_v7();
    Object.defineProperty(exports2, "v7", { enumerable: true, get: function() {
      return v7_js_1.default;
    } });
    var validate_js_1 = require_validate();
    Object.defineProperty(exports2, "validate", { enumerable: true, get: function() {
      return validate_js_1.default;
    } });
    var version_js_1 = require_version();
    Object.defineProperty(exports2, "version", { enumerable: true, get: function() {
      return version_js_1.default;
    } });
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/AccessKey.js
var require_AccessKey = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/AccessKey.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AccessKey = void 0;
    exports2.accessKeyBuild = accessKeyBuild;
    exports2.accessKeyCreate = accessKeyCreate;
    exports2.accessKeyDeserialize = accessKeyDeserialize2;
    exports2.accessKeySerialize = accessKeySerialize;
    exports2.parseResource = parseResource;
    exports2.parseResources = parseResources;
    exports2.buildResource = buildResource;
    var uuid_1 = require_cjs();
    var AccessKey2 = class {
      constructor() {
        this.id = "";
        this.type = "volatile";
        this.resources = "";
      }
    };
    exports2.AccessKey = AccessKey2;
    function accessKeyCreate(type, resources) {
      let accessKey = new AccessKey2();
      accessKey.id = (0, uuid_1.v4)();
      accessKey.type = type;
      accessKey.resources = resources;
      return accessKey;
    }
    function accessKeyBuild(id, type, resources) {
      let accessKey = new AccessKey2();
      accessKey.id = id;
      accessKey.type = type;
      accessKey.resources = resources;
      return accessKey;
    }
    function accessKeySerialize(accessKey) {
      return `${accessKey.id}|${accessKey.type}|${accessKey.resources}`;
    }
    function accessKeyDeserialize2(key) {
      var parts = key.split("|");
      return accessKeyBuild(parts[0], parts[1], parts[2]);
    }
    function parseResource(key) {
      var parts = key.split(":");
      return {
        scopes: parts[0],
        namespaces: parts[1],
        groups: parts[2],
        pods: parts[3],
        containers: parts[4]
      };
    }
    function parseResources(key) {
      if (!key)
        return [];
      let ress = key.split(";");
      let result = [];
      for (var res of ress) {
        result.push(parseResource(res));
      }
      return result;
    }
    function buildResource(scopes, namespaces, groups, pods, containers) {
      return `${scopes.join(",")}:${namespaces.join(",")}:${groups.join(",")}:${pods.join(",")}:${containers.join(",")}`;
    }
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/Global.js
var require_Global = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/Global.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/Version.js
var require_Version = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/Version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.versionGreaterThan = exports2.versionGreatOrEqualThan = void 0;
    var versionGreatOrEqualThan = (version1, version2) => {
      return versionGreaterThan(version1, version2) || version1 === version2;
    };
    exports2.versionGreatOrEqualThan = versionGreatOrEqualThan;
    var versionGreaterThan = (version1, version2) => {
      const v1 = version1.split(".").map(Number);
      const v2 = version2.split(".").map(Number);
      for (let i = 0; i < Math.max(v1.length, v2.length); i++) {
        const num1 = v1[i] || 0;
        const num2 = v2[i] || 0;
        if (num1 > num2)
          return true;
        else if (num1 < num2)
          return false;
      }
      return false;
    };
    exports2.versionGreaterThan = versionGreaterThan;
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/index.js
var require_dist = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p)) __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_Channel(), exports2);
    __exportStar(require_InstanceMessage(), exports2);
    __exportStar(require_InstanceConfig(), exports2);
    __exportStar(require_RouteMessage(), exports2);
    __exportStar(require_SignalMessage(), exports2);
    __exportStar(require_ApiKey(), exports2);
    __exportStar(require_AccessKey(), exports2);
    __exportStar(require_Global(), exports2);
    __exportStar(require_Version(), exports2);
  }
});

// src/back.ts
var back_exports = {};
__export(back_exports, {
  default: () => back_default
});
module.exports = __toCommonJS(back_exports);
var import_kwirth_common = __toESM(require_dist(), 1);
var import_https = __toESM(require("https"), 1);
var import_http = __toESM(require("http"), 1);
var POLL_INTERVAL_MS = 5 * 60 * 1e3;
var FEEDS = {
  kubernetes: { url: "https://kubernetes.io/feed.xml", source: "kubernetes.io" },
  ai: { url: "https://techcrunch.com/category/artificial-intelligence/feed/", source: "techcrunch.com" }
};
var NewsChannel = class {
  constructor(clusterInfo, backChannelObject) {
    this.channelId = "news";
    this.requirements = { storage: false, providers: [] };
    this.webSockets = [];
    this.getChannelData = () => ({
      id: "news",
      routable: false,
      pauseable: true,
      modifiable: false,
      reconnectable: true,
      metrics: false,
      sources: [import_kwirth_common.EClusterType.KUBERNETES, import_kwirth_common.EClusterType.DOCKER],
      endpoints: [],
      websocket: false,
      cluster: true,
      resourced: true
    });
    this.getChannelScopeLevel = (_scope) => 0;
    this.startChannel = async () => {
    };
    this.containsAsset = (webSocket, podNamespace, podName, containerName) => {
      const socket = this.webSockets.find((s) => s.ws === webSocket);
      if (socket) return socket.instances.some((i) => i.assets.some((a) => a.podNamespace === podNamespace && a.podName === podName && a.containerName === containerName));
      return false;
    };
    this.containsInstance = (instanceId) => this.webSockets.some((socket) => socket.instances.some((i) => i.instanceId === instanceId));
    this.processCommand = async (_webSocket, _instanceMessage) => true;
    this.addObject = async (webSocket, instanceConfig, podNamespace, podName, containerName) => {
      let socket = this.webSockets.find((s) => s.ws === webSocket);
      if (!socket) {
        const len = this.webSockets.push({ ws: webSocket, lastRefresh: Date.now(), instances: [] });
        socket = this.webSockets[len - 1];
      }
      let instance = socket.instances.find((i) => i.instanceId === instanceConfig.instance);
      if (!instance) {
        const newInstance = {
          accessKey: (0, import_kwirth_common.accessKeyDeserialize)(instanceConfig.accessKey),
          instanceId: instanceConfig.instance,
          selectedFeeds: instanceConfig.data?.selectedFeeds ?? Object.keys(FEEDS),
          paused: false,
          seenLinks: /* @__PURE__ */ new Set(),
          assets: []
        };
        socket.instances.push(newInstance);
        instance = newInstance;
        instance.pollInterval = setInterval((ws, i) => this.pollFeeds(ws, i), POLL_INTERVAL_MS, webSocket, instance);
        this.pollFeeds(webSocket, instance);
      }
      instance.assets.push({ podNamespace, podName, containerName });
      return true;
    };
    this.deleteObject = async (_webSocket, _instanceConfig, _podNamespace, _podName, _containerName) => true;
    this.pauseContinueInstance = (webSocket, instanceConfig, action) => {
      const instance = this.getInstance(webSocket, instanceConfig.instance);
      if (instance) {
        if (action === import_kwirth_common.EInstanceMessageAction.PAUSE) instance.paused = true;
        if (action === import_kwirth_common.EInstanceMessageAction.CONTINUE) instance.paused = false;
      } else {
        this.sendSignalMessage(webSocket, action, import_kwirth_common.EInstanceMessageFlow.RESPONSE, import_kwirth_common.ESignalMessageLevel.ERROR, instanceConfig.instance, "News instance not found");
      }
    };
    this.modifyInstance = (_webSocket, _instanceConfig) => {
    };
    this.stopInstance = (webSocket, instanceConfig) => {
      const instance = this.getInstance(webSocket, instanceConfig.instance);
      if (instance) {
        this.removeInstance(webSocket, instanceConfig.instance);
        this.sendSignalMessage(webSocket, import_kwirth_common.EInstanceMessageAction.STOP, import_kwirth_common.EInstanceMessageFlow.RESPONSE, import_kwirth_common.ESignalMessageLevel.INFO, instanceConfig.instance, "News instance stopped");
      } else {
        this.sendSignalMessage(webSocket, import_kwirth_common.EInstanceMessageAction.STOP, import_kwirth_common.EInstanceMessageFlow.RESPONSE, import_kwirth_common.ESignalMessageLevel.ERROR, instanceConfig.instance, "News instance not found");
      }
    };
    this.removeInstance = (webSocket, instanceId) => {
      const socket = this.webSockets.find((s) => s.ws === webSocket);
      if (socket) {
        const pos = socket.instances.findIndex((i) => i.instanceId === instanceId);
        if (pos >= 0) {
          clearInterval(socket.instances[pos].pollInterval);
          socket.instances.splice(pos, 1);
        }
      }
    };
    this.containsConnection = (webSocket) => Boolean(this.webSockets.find((s) => s.ws === webSocket));
    this.removeConnection = (webSocket) => {
      const socket = this.webSockets.find((s) => s.ws === webSocket);
      if (socket) {
        for (const instance of socket.instances) clearInterval(instance.pollInterval);
        const pos = this.webSockets.findIndex((s) => s.ws === webSocket);
        this.webSockets.splice(pos, 1);
      }
    };
    this.refreshConnection = (webSocket) => {
      const socket = this.webSockets.find((s) => s.ws === webSocket);
      if (socket) {
        socket.lastRefresh = Date.now();
        return true;
      }
      return false;
    };
    this.updateConnection = (newWebSocket, instanceId) => {
      for (const entry of this.webSockets) {
        if (entry.instances.find((i) => i.instanceId === instanceId)) {
          entry.ws = newWebSocket;
          return true;
        }
      }
      return false;
    };
    this.fetchUrl = (url) => {
      return new Promise((resolve, reject) => {
        const protocol = url.startsWith("https") ? import_https.default : import_http.default;
        const req = protocol.get(url, { headers: { "User-Agent": "kwirth-news/1.0" } }, (res) => {
          if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            resolve(this.fetchUrl(res.headers.location));
            return;
          }
          let data = "";
          res.on("data", (chunk) => data += chunk);
          res.on("end", () => resolve(data));
          res.on("error", reject);
        });
        req.on("error", reject);
      });
    };
    this.parseRssItems = (xml, source, category) => {
      const items = [];
      const itemRegex = /<item>([\s\S]*?)<\/item>/g;
      let match;
      while ((match = itemRegex.exec(xml)) !== null) {
        const itemXml = match[1];
        const title = (/<title><!\[CDATA\[([\s\S]*?)\]\]><\/title>/.exec(itemXml) || /<title>([\s\S]*?)<\/title>/.exec(itemXml))?.[1] || "";
        const link = (/<link>([\s\S]*?)<\/link>/.exec(itemXml) || /<guid[^>]*>([\s\S]*?)<\/guid>/.exec(itemXml))?.[1] || "";
        const description = (/<description><!\[CDATA\[([\s\S]*?)\]\]><\/description>/.exec(itemXml) || /<description>([\s\S]*?)<\/description>/.exec(itemXml))?.[1] || "";
        const pubDate = /<pubDate>([\s\S]*?)<\/pubDate>/.exec(itemXml)?.[1] || (/* @__PURE__ */ new Date()).toISOString();
        if (title.trim() && link.trim()) {
          items.push({
            title: title.trim(),
            link: link.trim(),
            description: description.replace(/<[^>]*>/g, "").trim().substring(0, 300),
            pubDate: pubDate.trim(),
            source,
            category
          });
        }
      }
      return items;
    };
    this.pollFeeds = async (ws, instance) => {
      if (instance.paused) return;
      for (const category of Object.keys(FEEDS).filter((f) => instance.selectedFeeds.includes(f))) {
        const feed = FEEDS[category];
        try {
          const xml = await this.fetchUrl(feed.url);
          const items = this.parseRssItems(xml, feed.source, category);
          for (const item of items) {
            if (!instance.seenLinks.has(item.link)) {
              instance.seenLinks.add(item.link);
              const msg = {
                msgtype: "newsmessageresponse",
                channel: "news",
                action: import_kwirth_common.EInstanceMessageAction.NONE,
                flow: import_kwirth_common.EInstanceMessageFlow.UNSOLICITED,
                type: import_kwirth_common.EInstanceMessageType.DATA,
                instance: instance.instanceId,
                item
              };
              ws.send(JSON.stringify(msg));
            }
          }
        } catch (err) {
          console.log(`[news-plugin] error polling ${category}: ${err}`);
        }
      }
    };
    this.sendSignalMessage = (ws, action, flow, level, instanceId, text) => {
      const resp = { action, flow, channel: "news", instance: instanceId, type: import_kwirth_common.EInstanceMessageType.SIGNAL, text, level };
      ws.send(JSON.stringify(resp));
    };
    this.getInstance = (webSocket, instanceId) => {
      const socket = this.webSockets.find((entry) => entry.ws === webSocket);
      if (socket) return socket.instances.find((i) => i.instanceId === instanceId);
      return void 0;
    };
    this.clusterInfo = clusterInfo;
    this.backChannelObject = backChannelObject;
  }
  processProviderEvent(_providerId, _obj) {
  }
  async endpointRequest(_endpoint, _req, _res) {
  }
  async websocketRequest(_newWebSocket) {
  }
};
var back_default = NewsChannel;
