"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // kwirth-globals:react
  var require_react = __commonJS({
    "kwirth-globals:react"(exports, module) {
      module.exports = window.__kwirth__.React;
    }
  });

  // kwirth-globals:@mui/icons-material
  var require_icons_material = __commonJS({
    "kwirth-globals:@mui/icons-material"(exports, module) {
      module.exports = window.__kwirth__.MUI.icons;
    }
  });

  // kwirth-globals:@kwirthmagnify/kwirth-common
  var require_kwirth_common = __commonJS({
    "kwirth-globals:@kwirthmagnify/kwirth-common"(exports, module) {
      module.exports = window.__kwirth__.kwirthCommon;
    }
  });

  // kwirth-globals:@mui/material
  var require_material = __commonJS({
    "kwirth-globals:@mui/material"(exports, module) {
      module.exports = window.__kwirth__.MUI.material;
    }
  });

  // src/front/PinocchioConfig.ts
  var kindsAvailable = ["Pod", "Deployment", "DaemonSet", "StatefulSet", "ReplicaSet", "Job", "CronJob", "ReplicationController", "Service", "Ingress", "HTTPRoute"];
  var PinocchioConfig = class {
    constructor() {
      this.triggers = [];
      this.llms = [];
    }
  };
  var PinocchioInstanceConfig = class {
  };

  // src/front/PinocchioSetup.tsx
  var import_react = __toESM(require_react(), 1);
  var import_icons_material = __toESM(require_icons_material(), 1);
  var PinocchioIcon = /* @__PURE__ */ import_react.default.createElement(import_icons_material.AutoFixHigh, null);
  var PinocchioSetup = (props) => {
    return /* @__PURE__ */ import_react.default.createElement(import_react.default.Fragment, null);
  };

  // src/front/PinocchioChannel.ts
  var import_kwirth_common3 = __toESM(require_kwirth_common(), 1);

  // src/front/PinocchioData.ts
  var PinocchioData = class {
    constructor() {
      this.toolsAvailable = [];
      this.providersAvailable = [];
      this.providers = [];
      this.config = {
        triggers: [],
        llms: []
      };
      this.content = [];
      this.paused = false;
      this.started = false;
    }
  };

  // src/front/PinocchioTabContent.tsx
  var import_react10 = __toESM(require_react(), 1);
  var import_material8 = __toESM(require_material(), 1);
  var import_icons_material8 = __toESM(require_icons_material(), 1);

  // src/front/PinocchioConfigTrigger.tsx
  var import_react4 = __toESM(require_react(), 1);
  var import_material2 = __toESM(require_material(), 1);
  var import_icons_material3 = __toESM(require_icons_material(), 1);

  // src/front/utils.tsx
  var import_react2 = __toESM(require_react(), 1);
  var import_icons_material2 = __toESM(require_icons_material(), 1);
  var import_material = __toESM(require_material(), 1);
  var import_react3 = __toESM(require_react(), 1);
  function objectClone(obj) {
    if (!obj) return void 0;
    return JSON.parse(JSON.stringify(obj));
  }
  var useKeyboard = () => {
    (0, import_react2.useEffect)(() => {
      const handleKeyDown = (event) => {
        event.stopPropagation();
      };
      window.addEventListener("keydown", handleKeyDown, true);
      return () => {
        window.removeEventListener("keydown", handleKeyDown, true);
      };
    });
  };
  var MsgBoxOkWarning = (title, message, onClose, onResult) => MsgBoxShow(title, message, onClose, 1 /* Ok */, /* @__PURE__ */ import_react3.default.createElement(import_icons_material2.Warning, { fontSize: "large", color: "warning" }), onResult);
  var MsgBoxYesNo = (title, message, onClose, onResult) => MsgBoxShow(title, message, onClose, 2 /* Yes */ + 8 /* No */, /* @__PURE__ */ import_react3.default.createElement(import_icons_material2.HelpOutline, { fontSize: "large", color: "primary" }), onResult);
  var MsgBoxShow = (title, message, onClose, buttons, icon, onResult) => {
    return /* @__PURE__ */ import_react3.default.createElement(import_material.Dialog, { open: true, onClose: () => {
      onClose(/* @__PURE__ */ import_react3.default.createElement(import_react3.default.Fragment, null));
      if (onResult) onResult(32 /* Cancel */);
    } }, /* @__PURE__ */ import_react3.default.createElement(import_material.DialogTitle, null, title), /* @__PURE__ */ import_react3.default.createElement(import_material.DialogContent, null, /* @__PURE__ */ import_react3.default.createElement(import_material.Stack, { sx: { mt: 2 }, direction: "row", alignItems: "center" }, icon, /* @__PURE__ */ import_react3.default.createElement(import_material.Box, { sx: { width: "12px" } }), typeof message === "string" ? /* @__PURE__ */ import_react3.default.createElement(import_material.Typography, { component: "div" }, /* @__PURE__ */ import_react3.default.createElement("div", { dangerouslySetInnerHTML: { __html: message } })) : message)), /* @__PURE__ */ import_react3.default.createElement(import_material.DialogActions, { sx: { p: "4px 4px" } }, buttons & 1 /* Ok */ ? /* @__PURE__ */ import_react3.default.createElement(import_material.Button, { onClick: () => {
      onClose(/* @__PURE__ */ import_react3.default.createElement(import_react3.default.Fragment, null));
      if (onResult) onResult(1 /* Ok */);
    } }, "ok") : /* @__PURE__ */ import_react3.default.createElement(import_react3.default.Fragment, null), buttons & 2 /* Yes */ ? /* @__PURE__ */ import_react3.default.createElement(import_material.Button, { onClick: () => {
      onClose(/* @__PURE__ */ import_react3.default.createElement(import_react3.default.Fragment, null));
      if (onResult) onResult(2 /* Yes */);
    } }, "yes") : /* @__PURE__ */ import_react3.default.createElement(import_react3.default.Fragment, null), buttons & 8 /* No */ ? /* @__PURE__ */ import_react3.default.createElement(import_material.Button, { onClick: () => {
      onClose(/* @__PURE__ */ import_react3.default.createElement(import_react3.default.Fragment, null));
      if (onResult) onResult(8 /* No */);
    } }, "no") : /* @__PURE__ */ import_react3.default.createElement(import_react3.default.Fragment, null), buttons & 32 /* Cancel */ ? /* @__PURE__ */ import_react3.default.createElement(import_material.Button, { onClick: () => {
      onClose(/* @__PURE__ */ import_react3.default.createElement(import_react3.default.Fragment, null));
      if (onResult) onResult(32 /* Cancel */);
    } }, "cancel") : /* @__PURE__ */ import_react3.default.createElement(import_react3.default.Fragment, null)));
  };

  // src/front/PinocchioConfigTrigger.tsx
  var PinocchioConfigTrigger = (props) => {
    const [config, setConfig] = (0, import_react4.useState)(objectClone(props.pinocchioConfig));
    const [selectedTriggerIndex, setSelectedTriggerIndex] = (0, import_react4.useState)(null);
    const [newTriggerId, setNewTriggerId] = (0, import_react4.useState)("");
    const [triggerId, setTriggerId] = (0, import_react4.useState)("");
    const [triggerType, setTriggerType] = (0, import_react4.useState)("artifact");
    const [triggerKind, setTriggerKind] = (0, import_react4.useState)("");
    const [selectedVersionIndex, setSelectedVersionIndex] = (0, import_react4.useState)(null);
    const [msgBox, setMsgBox] = (0, import_react4.useState)(/* @__PURE__ */ import_react4.default.createElement(import_react4.default.Fragment, null));
    const [versionId, setVersionId] = (0, import_react4.useState)("");
    const [description, setDescription] = (0, import_react4.useState)("");
    const [enabled, setEnabled] = (0, import_react4.useState)(true);
    const [system, setSystem] = (0, import_react4.useState)("");
    const [promptType, setPromptType] = (0, import_react4.useState)("jinja");
    const [prompt, setPrompt] = (0, import_react4.useState)("");
    const [action, setAction] = (0, import_react4.useState)("inform");
    const [llm, setLlm] = (0, import_react4.useState)("");
    const [steps, setSteps] = (0, import_react4.useState)(1);
    const [tools, setTools] = (0, import_react4.useState)([]);
    const [autoTools, setAutoTools] = (0, import_react4.useState)(false);
    const [spaces, setSpaces] = (0, import_react4.useState)("");
    useKeyboard();
    const selectedTrigger = selectedTriggerIndex !== null ? config.triggers[selectedTriggerIndex] : null;
    const clearVersionEditor = () => {
      setVersionId("");
      setDescription("");
      setEnabled(true);
      setSystem("");
      setPromptType("jinja");
      setPrompt("");
      setAction("inform");
      setLlm("");
      setSteps(1);
      setTools([]);
      setAutoTools(false);
      setSpaces("");
    };
    const onTriggerSelect = (index) => {
      setSelectedTriggerIndex(index);
      setTriggerId(config.triggers[index].id);
      setTriggerType(config.triggers[index].trigger);
      setTriggerKind(config.triggers[index].kind ?? "");
      setSelectedVersionIndex(null);
      clearVersionEditor();
    };
    const onTriggerIdChange = (newId) => {
      if (selectedTriggerIndex === null) return;
      setTriggerId(newId);
      const newTriggers = [...config.triggers ?? []];
      newTriggers[selectedTriggerIndex] = { ...newTriggers[selectedTriggerIndex], id: newId };
      setConfig((c) => ({ ...c, triggers: newTriggers }));
    };
    const onTriggerTypeChange = (newType) => {
      if (selectedTriggerIndex === null) return;
      setTriggerType(newType);
      const kind = newType === "artifact" ? triggerKind : void 0;
      const newTriggers = [...config.triggers ?? []];
      newTriggers[selectedTriggerIndex] = { ...newTriggers[selectedTriggerIndex], trigger: newType, kind };
      setConfig((c) => ({ ...c, triggers: newTriggers }));
    };
    const onTriggerKindChange = (newKind) => {
      if (selectedTriggerIndex === null) return;
      setTriggerKind(newKind);
      const newTriggers = [...config.triggers ?? []];
      newTriggers[selectedTriggerIndex] = { ...newTriggers[selectedTriggerIndex], kind: newKind };
      setConfig((c) => ({ ...c, triggers: newTriggers }));
    };
    const onTriggerAdd = () => {
      const id = newTriggerId.trim() || `trigger-${(config.triggers ?? []).length + 1}`;
      const t = { id, trigger: "artifact", versions: [] };
      const newTriggers = [...config.triggers ?? [], t];
      setConfig({ ...config, triggers: newTriggers });
      setSelectedTriggerIndex(newTriggers.length - 1);
      setSelectedVersionIndex(null);
      clearVersionEditor();
      setNewTriggerId("");
    };
    const onTriggerDelete = () => {
      if (selectedTriggerIndex === null) return;
      const t = config.triggers[selectedTriggerIndex];
      setMsgBox(MsgBoxYesNo("Delete trigger", `Delete trigger "${t.id}"?`, setMsgBox, (a) => {
        if (a !== 2 /* Yes */) return;
        const newTriggers = (config.triggers ?? []).filter((_, i) => i !== selectedTriggerIndex);
        setConfig((c) => ({ ...c, triggers: newTriggers }));
        setSelectedTriggerIndex(null);
        setSelectedVersionIndex(null);
        clearVersionEditor();
      }));
    };
    const onVersionSelect = (v, index) => {
      setSelectedVersionIndex(index);
      setVersionId(v.id);
      setDescription(v.description ?? "");
      setEnabled(v.enabled);
      setSystem(v.system);
      setPromptType(v.promptType);
      setPrompt(v.prompt);
      setAction(v.action);
      setLlm(v.llm);
      setSteps(v.steps);
      setTools(v.tools);
      setAutoTools(v.autoTools ?? false);
      setSpaces(v.spaces?.join(",") ?? "");
    };
    const onNewVersion = () => {
      setSelectedVersionIndex(null);
      clearVersionEditor();
    };
    const onVersionSave = () => {
      if (selectedTriggerIndex === null) return;
      const existingVersions = config.triggers[selectedTriggerIndex].versions ?? [];
      const duplicate = existingVersions.some((v2, i) => v2.id === versionId.trim() && i !== selectedVersionIndex);
      if (duplicate) {
        setMsgBox(MsgBoxOkWarning("Duplicate version", `A version with id "${versionId.trim()}" already exists.`, setMsgBox));
        return;
      }
      const v = { id: versionId.trim(), description, enabled, system, promptType, prompt, action, llm, steps, tools, autoTools, spaces: spaces.split(",").filter(Boolean) };
      const newTriggers = [...config.triggers ?? []];
      let versions = [...existingVersions];
      if (enabled)
        versions = versions.map((ver, i) => i === selectedVersionIndex ? ver : { ...ver, enabled: false });
      if (selectedVersionIndex !== null)
        versions[selectedVersionIndex] = v;
      else
        versions.push(v);
      newTriggers[selectedTriggerIndex] = { ...newTriggers[selectedTriggerIndex], versions };
      setConfig({ ...config, triggers: newTriggers });
      onNewVersion();
    };
    const onVersionDelete = () => {
      if (selectedTriggerIndex === null || selectedVersionIndex === null) return;
      const v = config.triggers[selectedTriggerIndex].versions[selectedVersionIndex];
      setMsgBox(MsgBoxYesNo("Delete version", `Delete version "${v.id}"?`, setMsgBox, (a) => {
        if (a !== 2 /* Yes */) return;
        const newTriggers = [...config.triggers ?? []];
        const versions = (newTriggers[selectedTriggerIndex].versions ?? []).filter((_, i) => i !== selectedVersionIndex);
        newTriggers[selectedTriggerIndex] = { ...newTriggers[selectedTriggerIndex], versions };
        setConfig((c) => ({ ...c, triggers: newTriggers }));
        onNewVersion();
      }));
    };
    const onVersionToggle = (vIndex) => {
      if (selectedTriggerIndex === null) return;
      const newTriggers = [...config.triggers ?? []];
      const versions = [...newTriggers[selectedTriggerIndex].versions ?? []];
      const enabling = !versions[vIndex].enabled;
      newTriggers[selectedTriggerIndex] = {
        ...newTriggers[selectedTriggerIndex],
        versions: versions.map((v, i) => ({ ...v, enabled: enabling ? i === vIndex : i === vIndex ? false : v.enabled }))
      };
      setConfig({ ...config, triggers: newTriggers });
    };
    const onChangeTools = (event) => {
      setTools(event.target.value);
    };
    return /* @__PURE__ */ import_react4.default.createElement(import_react4.default.Fragment, null, /* @__PURE__ */ import_react4.default.createElement(import_material2.Dialog, { open: true, PaperProps: { sx: { width: "80vw", maxWidth: "1200px", height: "65vh" } } }, /* @__PURE__ */ import_react4.default.createElement(import_material2.DialogTitle, null, "Trigger Config"), /* @__PURE__ */ import_react4.default.createElement(import_material2.DialogContent, { style: { display: "flex", height: "100%", overflow: "hidden", padding: "8px 16px" } }, /* @__PURE__ */ import_react4.default.createElement(import_material2.Box, { sx: { flex: "0 0 220px", display: "flex", flexDirection: "column", boxSizing: "border-box", pr: 1 } }, /* @__PURE__ */ import_react4.default.createElement(import_material2.Typography, { variant: "caption", color: "text.secondary", sx: { fontWeight: "bold", px: 0.5, pt: 0.5 } }, "Triggers"), /* @__PURE__ */ import_react4.default.createElement(import_material2.Stack, { direction: "row", spacing: 0.5, alignItems: "center", sx: { px: 0.5, pb: 0.5 } }, /* @__PURE__ */ import_react4.default.createElement(
      import_material2.TextField,
      {
        size: "small",
        value: newTriggerId,
        onChange: (e) => setNewTriggerId(e.target.value),
        placeholder: "Trigger id",
        variant: "outlined",
        fullWidth: true,
        inputProps: { style: { fontSize: 12, padding: "4px 6px" } },
        onKeyDown: (e) => {
          if (e.key === "Enter") onTriggerAdd();
        }
      }
    ), /* @__PURE__ */ import_react4.default.createElement(import_material2.IconButton, { size: "small", onClick: onTriggerAdd }, /* @__PURE__ */ import_react4.default.createElement(import_icons_material3.Add, { fontSize: "small" })), /* @__PURE__ */ import_react4.default.createElement(import_material2.IconButton, { size: "small", onClick: onTriggerDelete, disabled: selectedTriggerIndex === null, color: "error" }, /* @__PURE__ */ import_react4.default.createElement(import_icons_material3.Delete, { fontSize: "small" }))), /* @__PURE__ */ import_react4.default.createElement(import_material2.Box, { sx: { flex: "0 0 auto", maxHeight: "40%", overflowY: "auto", overflowX: "hidden" } }, /* @__PURE__ */ import_react4.default.createElement(import_material2.List, { dense: true, sx: { py: 0 } }, (config.triggers ?? []).map((t, index) => /* @__PURE__ */ import_react4.default.createElement(import_material2.ListItemButton, { key: index, selected: selectedTriggerIndex === index, onClick: () => onTriggerSelect(index), dense: true }, /* @__PURE__ */ import_react4.default.createElement(import_material2.Stack, { direction: "column" }, /* @__PURE__ */ import_react4.default.createElement(import_material2.Typography, { variant: "body2", sx: { fontWeight: selectedTriggerIndex === index ? "bold" : "normal" } }, t.id), /* @__PURE__ */ import_react4.default.createElement(import_material2.Typography, { color: "textSecondary", fontSize: 10 }, t.trigger, t.kind ? ` \xB7 ${t.kind}` : "")))))), /* @__PURE__ */ import_react4.default.createElement(import_material2.Divider, { sx: { my: 0.5 } }), /* @__PURE__ */ import_react4.default.createElement(import_material2.Typography, { variant: "caption", color: "text.secondary", sx: { fontWeight: "bold", px: 0.5 } }, "Versions", selectedTrigger ? ` \u2014 ${selectedTrigger.id}` : ""), /* @__PURE__ */ import_react4.default.createElement(import_material2.Box, { sx: { flex: 1, overflowY: "auto", overflowX: "hidden" } }, /* @__PURE__ */ import_react4.default.createElement(import_material2.List, { dense: true, sx: { py: 0 } }, (selectedTrigger?.versions ?? []).map((v, index) => /* @__PURE__ */ import_react4.default.createElement(import_material2.ListItemButton, { key: index, selected: selectedVersionIndex === index, onClick: () => onVersionSelect(v, index), dense: true, sx: { py: 0.5 } }, /* @__PURE__ */ import_react4.default.createElement(import_material2.Switch, { size: "small", checked: v.enabled, onChange: () => onVersionToggle(index), onClick: (e) => e.stopPropagation(), sx: { mr: 0.5 } }), /* @__PURE__ */ import_react4.default.createElement(import_material2.Stack, { direction: "column" }, /* @__PURE__ */ import_react4.default.createElement(import_material2.Typography, { variant: "body2", sx: { fontWeight: selectedVersionIndex === index ? "bold" : "normal" } }, v.id), v.description && /* @__PURE__ */ import_react4.default.createElement(import_material2.Typography, { variant: "caption", color: "text.secondary", sx: { lineHeight: 1.2 } }, v.description))))))), /* @__PURE__ */ import_react4.default.createElement(import_material2.Box, { sx: { flex: 1, minWidth: 0, display: "flex", alignItems: "start", padding: "8px 8px 8px 16px" } }, /* @__PURE__ */ import_react4.default.createElement(import_material2.Stack, { spacing: 1, style: { width: "100%" } }, /* @__PURE__ */ import_react4.default.createElement(import_material2.Stack, { direction: "row", spacing: 1 }, /* @__PURE__ */ import_react4.default.createElement(import_material2.TextField, { value: triggerId, onChange: (e) => onTriggerIdChange(e.target.value), placeholder: "Trigger id", label: "Trigger ID", variant: "standard", fullWidth: true, disabled: selectedTriggerIndex === null }), /* @__PURE__ */ import_react4.default.createElement(import_material2.FormControl, { variant: "standard", fullWidth: true, disabled: selectedTriggerIndex === null }, /* @__PURE__ */ import_react4.default.createElement(import_material2.InputLabel, null, "Trigger type"), /* @__PURE__ */ import_react4.default.createElement(import_material2.Select, { value: triggerType, onChange: (e) => onTriggerTypeChange(e.target.value), variant: "standard" }, /* @__PURE__ */ import_react4.default.createElement(import_material2.MenuItem, { value: "artifact" }, "artifact"), /* @__PURE__ */ import_react4.default.createElement(import_material2.MenuItem, { value: "business" }, "business"))), triggerType === "artifact" && /* @__PURE__ */ import_react4.default.createElement(import_material2.FormControl, { variant: "standard", fullWidth: true, disabled: selectedTriggerIndex === null }, /* @__PURE__ */ import_react4.default.createElement(import_material2.InputLabel, null, "Kind"), /* @__PURE__ */ import_react4.default.createElement(import_material2.Select, { value: triggerKind, onChange: (e) => onTriggerKindChange(e.target.value), variant: "standard" }, kindsAvailable.map((k) => /* @__PURE__ */ import_react4.default.createElement(import_material2.MenuItem, { key: k, value: k }, k)))), /* @__PURE__ */ import_react4.default.createElement(import_material2.TextField, { value: versionId, onChange: (e) => setVersionId(e.target.value), placeholder: "Version id", label: "Version ID", variant: "standard", fullWidth: true, disabled: selectedTriggerIndex === null })), /* @__PURE__ */ import_react4.default.createElement(import_material2.TextField, { value: description, onChange: (e) => setDescription(e.target.value), placeholder: "Short description", label: "Description", variant: "standard", fullWidth: true, disabled: selectedTriggerIndex === null }), /* @__PURE__ */ import_react4.default.createElement(import_material2.Stack, { direction: "row" }, /* @__PURE__ */ import_react4.default.createElement(import_material2.FormControl, { variant: "standard", sx: { width: "100%", mr: 1 } }, /* @__PURE__ */ import_react4.default.createElement(import_material2.InputLabel, null, "Action"), /* @__PURE__ */ import_react4.default.createElement(import_material2.Select, { value: action, onChange: (e) => setAction(e.target.value), variant: "standard", disabled: selectedTriggerIndex === null }, ["inform", "cancel", "repair"].map((v) => /* @__PURE__ */ import_react4.default.createElement(import_material2.MenuItem, { key: v, value: v }, v)))), /* @__PURE__ */ import_react4.default.createElement(import_material2.FormControl, { variant: "standard", sx: { width: "100%", mr: 1 } }, /* @__PURE__ */ import_react4.default.createElement(import_material2.InputLabel, null, "LLM"), /* @__PURE__ */ import_react4.default.createElement(import_material2.Select, { value: llm, onChange: (e) => setLlm(e.target.value), variant: "standard", disabled: selectedTriggerIndex === null }, config.llms.map((l) => /* @__PURE__ */ import_react4.default.createElement(import_material2.MenuItem, { key: l.id, value: l.id }, l.id)))), /* @__PURE__ */ import_react4.default.createElement(import_material2.TextField, { value: steps, onChange: (e) => setSteps(+e.target.value), variant: "standard", type: "number", sx: { width: "20%", mr: 1 }, label: "Steps", disabled: selectedTriggerIndex === null }), selectedTrigger?.trigger !== "artifact" && /* @__PURE__ */ import_react4.default.createElement(import_material2.TextField, { value: spaces, onChange: (e) => setSpaces(e.target.value), placeholder: "space.type,...", label: "Spaces", variant: "standard", fullWidth: true, disabled: selectedTriggerIndex === null })), /* @__PURE__ */ import_react4.default.createElement(import_material2.Stack, { direction: "row", alignItems: "flex-end", spacing: 1 }, /* @__PURE__ */ import_react4.default.createElement(
      import_material2.FormControlLabel,
      {
        control: /* @__PURE__ */ import_react4.default.createElement(import_material2.Switch, { size: "small", checked: autoTools, onChange: (e) => setAutoTools(e.target.checked), disabled: selectedTriggerIndex === null }),
        label: /* @__PURE__ */ import_react4.default.createElement(import_material2.Typography, { variant: "caption" }, "Auto"),
        sx: { mr: 0, flexShrink: 0 }
      }
    ), /* @__PURE__ */ import_react4.default.createElement(import_material2.FormControl, { variant: "standard", sx: { flex: 1 }, disabled: autoTools }, /* @__PURE__ */ import_react4.default.createElement(import_material2.InputLabel, null, "Tools"), /* @__PURE__ */ import_react4.default.createElement(import_material2.Select, { onChange: onChangeTools, multiple: true, value: tools, renderValue: (sel) => autoTools ? `all (${props.toolsAvailable.length})` : sel.join(", "), variant: "standard", disabled: selectedTriggerIndex === null || autoTools }, props.toolsAvailable.map((tool) => /* @__PURE__ */ import_react4.default.createElement(import_material2.MenuItem, { key: tool, value: tool }, /* @__PURE__ */ import_react4.default.createElement(import_material2.Checkbox, { size: "small", checked: tools.includes(tool) }), /* @__PURE__ */ import_react4.default.createElement(import_material2.Typography, null, tool)))))), /* @__PURE__ */ import_react4.default.createElement(import_material2.Box, null, /* @__PURE__ */ import_react4.default.createElement(import_material2.Typography, { variant: "caption", color: "text.secondary" }, "System"), /* @__PURE__ */ import_react4.default.createElement(import_material2.TextareaAutosize, { value: system, onChange: (e) => setSystem(e.target.value), minRows: 3, maxRows: 3, style: { width: "100%", resize: "none", boxSizing: "border-box", padding: "6px", fontFamily: "monospace", fontSize: 12 }, placeholder: "System prompt", disabled: selectedTriggerIndex === null })), /* @__PURE__ */ import_react4.default.createElement(import_material2.Box, null, /* @__PURE__ */ import_react4.default.createElement(import_material2.Stack, { direction: "row", alignItems: "center", spacing: 1, sx: { mb: 0.5 } }, /* @__PURE__ */ import_react4.default.createElement(import_material2.Typography, { variant: "caption", color: "text.secondary" }, "Prompt"), /* @__PURE__ */ import_react4.default.createElement(import_material2.FormControl, { variant: "standard", sx: { minWidth: 100 } }, /* @__PURE__ */ import_react4.default.createElement(import_material2.Select, { value: promptType, onChange: (e) => setPromptType(e.target.value), variant: "standard", disabled: selectedTriggerIndex === null, sx: { fontSize: 12 } }, /* @__PURE__ */ import_react4.default.createElement(import_material2.MenuItem, { value: "artifact" }, "artifact"), /* @__PURE__ */ import_react4.default.createElement(import_material2.MenuItem, { value: "jinja" }, "jinja")))), /* @__PURE__ */ import_react4.default.createElement(import_material2.TextareaAutosize, { value: prompt, onChange: (e) => setPrompt(e.target.value), minRows: 3, maxRows: 3, style: { width: "100%", resize: "none", boxSizing: "border-box", padding: "6px", fontFamily: "monospace", fontSize: 12 }, placeholder: "Prompt", disabled: selectedTriggerIndex === null })), /* @__PURE__ */ import_react4.default.createElement(import_material2.Stack, { direction: "row", spacing: 1 }, /* @__PURE__ */ import_react4.default.createElement(import_material2.Button, { variant: "outlined", onClick: onNewVersion, disabled: selectedTriggerIndex === null }, "New"), /* @__PURE__ */ import_react4.default.createElement(import_material2.Typography, { flex: 1 }), /* @__PURE__ */ import_react4.default.createElement(import_material2.Button, { variant: "text", color: "error", onClick: onVersionDelete, disabled: selectedVersionIndex === null }, "Remove"), /* @__PURE__ */ import_react4.default.createElement(import_material2.Button, { variant: "contained", onClick: onVersionSave, disabled: selectedTriggerIndex === null || !versionId.trim() }, selectedVersionIndex !== null ? "Update" : "Add"))))), /* @__PURE__ */ import_react4.default.createElement(import_material2.DialogActions, null, /* @__PURE__ */ import_react4.default.createElement(import_material2.Button, { onClick: () => props.onClose(config) }, "OK"), /* @__PURE__ */ import_react4.default.createElement(import_material2.Button, { onClick: () => props.onClose(void 0) }, "Cancel"))), msgBox);
  };

  // src/front/PinocchioConfigLlm.tsx
  var import_react5 = __toESM(require_react(), 1);
  var import_material3 = __toESM(require_material(), 1);
  var import_icons_material4 = __toESM(require_icons_material(), 1);
  var PinocchioConfigLlm = (props) => {
    const [config, setConfig] = (0, import_react5.useState)(objectClone(props.pinocchioConfig));
    const [selectedIndex, setSelectedIndex] = (0, import_react5.useState)(null);
    const [showPassword, setShowPassword] = (0, import_react5.useState)(false);
    const [id, setId] = (0, import_react5.useState)("");
    const [provider, setProvider] = (0, import_react5.useState)("google");
    const [model, setModel] = (0, import_react5.useState)("");
    const [temperature, setTemperature] = (0, import_react5.useState)(0);
    const [useProviderKey, setUseProviderKey] = (0, import_react5.useState)(true);
    const [key, setKey] = (0, import_react5.useState)("");
    useKeyboard();
    const onLlmSelected = (index) => {
      const l = config.llms[index];
      if (l) {
        setId(l.id);
        setProvider(l.provider);
        setModel(l.model);
        setTemperature(l.temperature);
        setUseProviderKey(l.useProviderKey);
        setKey(l.key);
        setSelectedIndex(index);
      }
    };
    const onNew = () => {
      setSelectedIndex(null);
      setId("");
      setProvider("");
      setModel("");
      setTemperature(0);
      setUseProviderKey(false);
      setKey("");
    };
    const onAdd = () => {
      const llm = {
        id,
        provider,
        model,
        temperature,
        useProviderKey,
        key
      };
      let newLlms = [...config.llms];
      if (selectedIndex !== null)
        newLlms[selectedIndex] = llm;
      else
        newLlms.push(llm);
      setConfig({ ...config, llms: newLlms });
      onNew();
    };
    const onRemove = () => {
      if (selectedIndex === null) return;
      const newLlms = config.llms.filter((_, i) => i !== selectedIndex);
      setConfig({ ...config, llms: newLlms });
      onNew();
    };
    return /* @__PURE__ */ import_react5.default.createElement(import_react5.default.Fragment, null, /* @__PURE__ */ import_react5.default.createElement(import_material3.Dialog, { open: true, PaperProps: { sx: { width: "80vw", maxWidth: "800px", height: "55vh" } } }, /* @__PURE__ */ import_react5.default.createElement(import_material3.DialogTitle, null, "LLM Config"), /* @__PURE__ */ import_react5.default.createElement(import_material3.DialogContent, { style: { display: "flex", height: "100%" } }, /* @__PURE__ */ import_react5.default.createElement(import_material3.Box, { sx: { flex: 1, display: "flex", flexDirection: "column", boxSizing: "border-box", maxWidth: "40%" } }, /* @__PURE__ */ import_react5.default.createElement(import_material3.Box, { sx: { flex: 1, overflowY: "auto", overflowX: "hidden" } }, /* @__PURE__ */ import_react5.default.createElement(import_material3.List, { sx: { flexGrow: 1, mr: 2, width: "100%" } }, config.llms.map(
      (llm, index) => /* @__PURE__ */ import_react5.default.createElement(import_material3.ListItemButton, { key: index, selected: selectedIndex === index, onClick: () => onLlmSelected(index) }, /* @__PURE__ */ import_react5.default.createElement(import_material3.Stack, { direction: "column" }, /* @__PURE__ */ import_react5.default.createElement(import_material3.Typography, { sx: { fontWeight: selectedIndex === index ? "bold" : "normal" } }, llm.id), /* @__PURE__ */ import_react5.default.createElement(import_material3.Typography, { color: "darkgray", fontSize: 12 }, llm.provider)))
    )))), /* @__PURE__ */ import_react5.default.createElement(import_material3.Box, { sx: { flex: 1, display: "flex", alignItems: "start", padding: "16px" } }, /* @__PURE__ */ import_react5.default.createElement(import_material3.Stack, { spacing: 2, style: { width: "100%" } }, /* @__PURE__ */ import_react5.default.createElement(import_material3.Stack, { direction: "column", spacing: 1 }, /* @__PURE__ */ import_react5.default.createElement(import_material3.TextField, { value: id, onChange: (e) => setId(e.target.value), placeholder: "Enter LLM id", label: "LLM ID", variant: "standard", fullWidth: true }), /* @__PURE__ */ import_react5.default.createElement(import_material3.FormControl, { variant: "standard", sx: { width: "100%" } }, /* @__PURE__ */ import_react5.default.createElement(import_material3.InputLabel, null, "Provider"), /* @__PURE__ */ import_react5.default.createElement(import_material3.Select, { value: provider, onChange: (e) => {
      setProvider(e.target.value);
      setModel("");
    }, variant: "standard", fullWidth: true }, props.providers.map((prov) => /* @__PURE__ */ import_react5.default.createElement(import_material3.MenuItem, { key: prov.name, value: prov.name, disabled: props.providers.find((p) => p.name === prov.name)?.models.length === 0 }, prov.name)))), /* @__PURE__ */ import_react5.default.createElement(import_material3.FormControl, { variant: "standard", sx: { width: "100%" } }, /* @__PURE__ */ import_react5.default.createElement(import_material3.InputLabel, null, "Model"), /* @__PURE__ */ import_react5.default.createElement(import_material3.Select, { value: model, onChange: (e) => setModel(e.target.value), variant: "standard", fullWidth: true, displayEmpty: true }, props.providers.find((p) => p.name === provider)?.models.map((model2, index) => /* @__PURE__ */ import_react5.default.createElement(import_material3.MenuItem, { key: index, value: model2.id }, model2.name)))), /* @__PURE__ */ import_react5.default.createElement(import_material3.TextField, { value: temperature, onChange: (e) => setTemperature(+e.target.value), label: "Model temperature", variant: "standard", type: "number", fullWidth: true }), /* @__PURE__ */ import_react5.default.createElement(import_material3.Stack, { direction: "row", alignItems: "center" }, /* @__PURE__ */ import_react5.default.createElement(import_material3.Typography, { flex: 1 }, "Use provider API Key (or enter a specific one)"), /* @__PURE__ */ import_react5.default.createElement(import_material3.Checkbox, { checked: useProviderKey, onChange: (e) => setUseProviderKey(e.target.checked) })), /* @__PURE__ */ import_react5.default.createElement(
      import_material3.TextField,
      {
        value: key,
        onChange: (e) => setKey(e.target.value),
        disabled: useProviderKey,
        label: "API Key",
        placeholder: "Enter API Key",
        variant: "standard",
        fullWidth: true,
        type: showPassword ? "text" : "password",
        InputProps: {
          endAdornment: /* @__PURE__ */ import_react5.default.createElement(import_material3.InputAdornment, { position: "end" }, /* @__PURE__ */ import_react5.default.createElement(import_material3.IconButton, { onClick: () => setShowPassword(!showPassword), edge: "end" }, showPassword ? /* @__PURE__ */ import_react5.default.createElement(import_icons_material4.VisibilityOff, null) : /* @__PURE__ */ import_react5.default.createElement(import_icons_material4.Visibility, null)))
        }
      }
    )), /* @__PURE__ */ import_react5.default.createElement(import_material3.Stack, { direction: "row", spacing: 1 }, /* @__PURE__ */ import_react5.default.createElement(import_material3.Button, { variant: "outlined", size: "small", onClick: onNew }, "New"), /* @__PURE__ */ import_react5.default.createElement(import_material3.Typography, { flex: 1 }), /* @__PURE__ */ import_react5.default.createElement(import_material3.Button, { color: "error", onClick: onRemove, disabled: selectedIndex === null }, "remove"), /* @__PURE__ */ import_react5.default.createElement(import_material3.Button, { variant: "contained", onClick: onAdd, disabled: !id || !model }, selectedIndex !== null ? "update" : "add"))))), /* @__PURE__ */ import_react5.default.createElement(import_material3.DialogActions, null, /* @__PURE__ */ import_react5.default.createElement(import_material3.Button, { onClick: () => props.onClose(config) }, "ok"), /* @__PURE__ */ import_react5.default.createElement(import_material3.Button, { onClick: () => props.onClose(void 0) }, "cancel"))));
  };

  // src/front/PinocchioTabContent.tsx
  var import_kwirth_common2 = __toESM(require_kwirth_common(), 1);

  // src/front/PinocchioConfigProvider.tsx
  var import_react6 = __toESM(require_react(), 1);
  var import_material4 = __toESM(require_material(), 1);
  var import_icons_material5 = __toESM(require_icons_material(), 1);
  var PinocchioConfigProvider = (props) => {
    const [providers, setProviders] = (0, import_react6.useState)(objectClone(props.providers));
    const [selectedIndex, setSelectedIndex] = (0, import_react6.useState)(null);
    const [showPassword, setShowPassword] = (0, import_react6.useState)(false);
    const [providerName, setProviderName] = (0, import_react6.useState)("");
    const [providerKey, setProviderKey] = (0, import_react6.useState)(props.providersAvailable[0]);
    useKeyboard();
    const onProviderSelected = (p, index) => {
      setProviderName(p.name);
      setProviderKey(p.key);
      setSelectedIndex(index);
    };
    const onNew = () => {
      setSelectedIndex(null);
      setProviderName("");
      setProviderKey("");
    };
    const onAdd = () => {
      if (!providerName.trim()) return;
      let newProviders = [...providers];
      if (selectedIndex !== null) {
        newProviders[selectedIndex] = {
          ...newProviders[selectedIndex],
          name: providerName,
          key: providerKey
        };
      } else {
        const newProvider = {
          name: providerName,
          key: providerKey,
          models: []
        };
        newProviders.push(newProvider);
      }
      setProviders(newProviders);
      onNew();
    };
    const onRemove = () => {
      if (selectedIndex === null) return;
      const newProviders = providers.filter((_, i) => i !== selectedIndex);
      setProviders(newProviders);
      onNew();
    };
    return /* @__PURE__ */ import_react6.default.createElement(import_material4.Dialog, { open: true, PaperProps: { sx: { width: "80vw", maxWidth: "900px", height: "45vh" } } }, /* @__PURE__ */ import_react6.default.createElement(import_material4.DialogTitle, null, "Manage Providers"), /* @__PURE__ */ import_react6.default.createElement(import_material4.DialogContent, { style: { display: "flex", height: "100%" } }, /* @__PURE__ */ import_react6.default.createElement(import_material4.Box, { sx: { flex: 1, display: "flex", flexDirection: "column", boxSizing: "border-box", maxWidth: "30%" } }, /* @__PURE__ */ import_react6.default.createElement(import_material4.Box, { sx: { flex: 1, overflowY: "auto" } }, /* @__PURE__ */ import_react6.default.createElement(import_material4.List, { sx: { mr: 1 } }, providers.map((p, index) => /* @__PURE__ */ import_react6.default.createElement(
      import_material4.ListItemButton,
      {
        key: index,
        selected: selectedIndex === index,
        onClick: () => onProviderSelected(p, index)
      },
      /* @__PURE__ */ import_react6.default.createElement(import_material4.Stack, { direction: "column" }, /* @__PURE__ */ import_react6.default.createElement(import_material4.Typography, { sx: { fontWeight: selectedIndex === index ? "bold" : "normal" } }, p.name), /* @__PURE__ */ import_react6.default.createElement(import_material4.Typography, { color: "darkgray", fontSize: 11 }, p.models?.length || 0, " models loaded"))
    ))))), /* @__PURE__ */ import_react6.default.createElement(import_material4.Box, { sx: { flex: 1, display: "flex", alignItems: "start", padding: "24px" } }, /* @__PURE__ */ import_react6.default.createElement(import_material4.Stack, { spacing: 3, style: { width: "100%" } }, /* @__PURE__ */ import_react6.default.createElement(import_material4.FormControl, { variant: "standard", sx: { width: "100%" } }, /* @__PURE__ */ import_react6.default.createElement(import_material4.InputLabel, null, "Provider"), /* @__PURE__ */ import_react6.default.createElement(import_material4.Select, { value: providerName, onChange: (e) => {
      setProviderName(e.target.value);
    }, variant: "standard", fullWidth: true }, props.providersAvailable.map((name) => /* @__PURE__ */ import_react6.default.createElement(import_material4.MenuItem, { key: name, value: name, disabled: props.providersAvailable.length === 0 }, name)))), /* @__PURE__ */ import_react6.default.createElement(
      import_material4.TextField,
      {
        label: "API Key / Token",
        type: showPassword ? "text" : "password",
        variant: "standard",
        fullWidth: true,
        value: providerKey,
        onChange: (e) => setProviderKey(e.target.value),
        helperText: "This key can be afterwards linked to specific uses.",
        InputProps: {
          endAdornment: /* @__PURE__ */ import_react6.default.createElement(import_material4.InputAdornment, { position: "end" }, /* @__PURE__ */ import_react6.default.createElement(import_material4.IconButton, { onClick: () => setShowPassword(!showPassword), edge: "end" }, showPassword ? /* @__PURE__ */ import_react6.default.createElement(import_icons_material5.VisibilityOff, null) : /* @__PURE__ */ import_react6.default.createElement(import_icons_material5.Visibility, null)))
        }
      }
    ), /* @__PURE__ */ import_react6.default.createElement(import_material4.Box, { sx: { flexGrow: 1 } }), /* @__PURE__ */ import_react6.default.createElement(import_material4.Stack, { direction: "row", spacing: 1 }, /* @__PURE__ */ import_react6.default.createElement(import_material4.Button, { variant: "outlined", onClick: onNew }, "New"), /* @__PURE__ */ import_react6.default.createElement(import_material4.Typography, { flex: 1 }), /* @__PURE__ */ import_react6.default.createElement(import_material4.Button, { variant: "text", color: "error", onClick: onRemove, disabled: selectedIndex === null }, "Remove"), /* @__PURE__ */ import_react6.default.createElement(import_material4.Button, { variant: "contained", onClick: onAdd, disabled: !providerName }, selectedIndex !== null ? "Update" : "Add"))))), /* @__PURE__ */ import_react6.default.createElement(import_material4.DialogActions, { sx: { p: 2 } }, /* @__PURE__ */ import_react6.default.createElement(import_material4.Button, { onClick: () => props.onClose(providers), color: "primary", variant: "contained" }, "Save"), /* @__PURE__ */ import_react6.default.createElement(import_material4.Button, { onClick: () => props.onClose(void 0), color: "inherit" }, "Cancel")));
  };

  // src/front/PinocchioTabContent.tsx
  var import_react11 = __toESM(require_react(), 1);

  // src/front/MenuConfig.tsx
  var import_react7 = __toESM(require_react(), 1);
  var import_material5 = __toESM(require_material(), 1);
  var import_icons_material6 = __toESM(require_icons_material(), 1);
  var MenuConfig = (props) => {
    return /* @__PURE__ */ import_react7.default.createElement(import_material5.Menu, { anchorEl: props.anchorParent, open: true, onClose: props.onClose }, /* @__PURE__ */ import_react7.default.createElement(import_material5.MenuList, { dense: true, sx: { width: "200px" } }, /* @__PURE__ */ import_react7.default.createElement(import_material5.MenuItem, { onClick: () => props.onAction("provider") }, /* @__PURE__ */ import_react7.default.createElement(import_material5.ListItemIcon, null, /* @__PURE__ */ import_react7.default.createElement(import_icons_material6.Hub, { fontSize: "small" })), /* @__PURE__ */ import_react7.default.createElement(import_material5.ListItemText, null, "Provider")), /* @__PURE__ */ import_react7.default.createElement(import_material5.MenuItem, { onClick: () => props.onAction("llm"), disabled: props.providers.length === 0 }, /* @__PURE__ */ import_react7.default.createElement(import_material5.ListItemIcon, null, /* @__PURE__ */ import_react7.default.createElement(import_icons_material6.Memory, { fontSize: "small" })), /* @__PURE__ */ import_react7.default.createElement(import_material5.ListItemText, null, "LLM")), /* @__PURE__ */ import_react7.default.createElement(import_material5.MenuItem, { onClick: () => props.onAction("trigger"), disabled: props.pinocchioConfig.llms.length === 0 }, /* @__PURE__ */ import_react7.default.createElement(import_material5.ListItemIcon, null, /* @__PURE__ */ import_react7.default.createElement(import_icons_material6.Bolt, { fontSize: "small" })), /* @__PURE__ */ import_react7.default.createElement(import_material5.ListItemText, null, "Trigger")), /* @__PURE__ */ import_react7.default.createElement(import_material5.MenuItem, { onClick: () => props.onAction("importexport") }, /* @__PURE__ */ import_react7.default.createElement(import_material5.ListItemIcon, null, /* @__PURE__ */ import_react7.default.createElement(import_icons_material6.ImportExport, { fontSize: "small" })), /* @__PURE__ */ import_react7.default.createElement(import_material5.ListItemText, null, "Import / Export"))));
  };

  // src/front/PinocchioImportExport.tsx
  var import_react8 = __toESM(require_react(), 1);
  var import_material6 = __toESM(require_material(), 1);
  var CheckSection = ({ label, items, selected, onChange, existsLabel }) => {
    const allChecked = items.length > 0 && items.every((k) => selected.has(k));
    const someChecked = items.some((k) => selected.has(k));
    const toggleAll = () => onChange(allChecked ? /* @__PURE__ */ new Set() : new Set(items));
    const toggleOne = (key) => {
      const next = new Set(selected);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      onChange(next);
    };
    return /* @__PURE__ */ import_react8.default.createElement(import_material6.Box, { sx: { mb: 1 } }, /* @__PURE__ */ import_react8.default.createElement(import_material6.Stack, { direction: "row", alignItems: "center" }, /* @__PURE__ */ import_react8.default.createElement(import_material6.Checkbox, { size: "small", checked: allChecked, indeterminate: someChecked && !allChecked, onChange: toggleAll, disabled: items.length === 0 }), /* @__PURE__ */ import_react8.default.createElement(import_material6.Typography, { variant: "subtitle2", sx: { fontWeight: "bold" } }, label)), /* @__PURE__ */ import_react8.default.createElement(import_material6.Box, { sx: { pl: 3 } }, items.length === 0 ? /* @__PURE__ */ import_react8.default.createElement(import_material6.Typography, { variant: "body2", color: "text.secondary", sx: { ml: 1 } }, "\u2014 none \u2014") : items.map((key) => /* @__PURE__ */ import_react8.default.createElement(import_material6.Stack, { key, direction: "row", alignItems: "center" }, /* @__PURE__ */ import_react8.default.createElement(import_material6.Checkbox, { size: "small", checked: selected.has(key), onChange: () => toggleOne(key) }), /* @__PURE__ */ import_react8.default.createElement(import_material6.Typography, { variant: "body2" }, key), existsLabel?.(key) && /* @__PURE__ */ import_react8.default.createElement(import_material6.Typography, { variant: "caption", color: "warning.main", sx: { ml: 1 } }, "(overwrites existing)")))));
  };
  var PinocchioImportExport = (props) => {
    const [tab, setTab] = (0, import_react8.useState)(0);
    const fileInputRef = (0, import_react8.useRef)(null);
    const [exportProviders, setExportProviders] = (0, import_react8.useState)(new Set(props.providers.map((p) => p.name)));
    const [exportLlms, setExportLlms] = (0, import_react8.useState)(new Set(props.config.llms.map((l) => l.id)));
    const [exportTriggers, setExportTriggers] = (0, import_react8.useState)(new Set(props.config.triggers.map((t) => t.id)));
    const [importFile, setImportFile] = (0, import_react8.useState)(null);
    const [importProviders, setImportProviders] = (0, import_react8.useState)(/* @__PURE__ */ new Set());
    const [importLlms, setImportLlms] = (0, import_react8.useState)(/* @__PURE__ */ new Set());
    const [importTriggers, setImportTriggers] = (0, import_react8.useState)(/* @__PURE__ */ new Set());
    const [importError, setImportError] = (0, import_react8.useState)("");
    const handleDownload = () => {
      const data = {
        version: "1",
        providers: props.providers.filter((p) => exportProviders.has(p.name)),
        llms: props.config.llms.filter((l) => exportLlms.has(l.id)),
        triggers: props.config.triggers.filter((t) => exportTriggers.has(t.id))
      };
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `pinocchio-config-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
    };
    const handleFileChange = (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        try {
          const parsed = JSON.parse(ev.target?.result);
          if (parsed.version !== "1") throw new Error("Unsupported version");
          setImportFile(parsed);
          setImportProviders(new Set((parsed.providers ?? []).map((p) => p.name)));
          setImportLlms(new Set((parsed.llms ?? []).map((l) => l.id)));
          setImportTriggers(new Set((parsed.triggers ?? []).map((t) => t.id)));
          setImportError("");
        } catch {
          setImportError("Invalid or unsupported file");
          setImportFile(null);
        }
      };
      reader.readAsText(file);
      e.target.value = "";
    };
    const handleImport = () => {
      if (!importFile) return;
      const mergeById = (current, incoming, key) => {
        const result = [...current];
        for (const item of incoming) {
          const idx = result.findIndex((x) => x[key] === item[key]);
          if (idx >= 0) result[idx] = item;
          else result.push(item);
        }
        return result;
      };
      const newProviders = mergeById(props.providers, (importFile.providers ?? []).filter((p) => importProviders.has(p.name)), "name");
      const newLlms = mergeById(props.config.llms, (importFile.llms ?? []).filter((l) => importLlms.has(l.id)), "id");
      const newTriggers = mergeById(props.config.triggers, (importFile.triggers ?? []).filter((t) => importTriggers.has(t.id)), "id");
      props.onClose(newProviders, { ...props.config, llms: newLlms, triggers: newTriggers });
    };
    const totalExport = exportProviders.size + exportLlms.size + exportTriggers.size;
    const totalImport = importProviders.size + importLlms.size + importTriggers.size;
    return /* @__PURE__ */ import_react8.default.createElement(import_material6.Dialog, { open: true, PaperProps: { sx: { width: "60vw", maxWidth: "680px", height: "58vh" } } }, /* @__PURE__ */ import_react8.default.createElement(import_material6.DialogTitle, null, "Import / Export"), /* @__PURE__ */ import_react8.default.createElement(import_material6.DialogContent, { sx: { display: "flex", flexDirection: "column", p: 0 } }, /* @__PURE__ */ import_react8.default.createElement(import_material6.Tabs, { value: tab, onChange: (_, v) => setTab(v), sx: { borderBottom: 1, borderColor: "divider", px: 2 } }, /* @__PURE__ */ import_react8.default.createElement(import_material6.Tab, { label: "Export" }), /* @__PURE__ */ import_react8.default.createElement(import_material6.Tab, { label: "Import" })), /* @__PURE__ */ import_react8.default.createElement(import_material6.Box, { sx: { flex: 1, overflowY: "auto", p: 2 } }, tab === 0 && /* @__PURE__ */ import_react8.default.createElement(import_react8.default.Fragment, null, /* @__PURE__ */ import_react8.default.createElement(CheckSection, { label: "Providers", items: props.providers.map((p) => p.name), selected: exportProviders, onChange: setExportProviders }), /* @__PURE__ */ import_react8.default.createElement(import_material6.Divider, { sx: { my: 1 } }), /* @__PURE__ */ import_react8.default.createElement(CheckSection, { label: "LLMs", items: props.config.llms.map((l) => l.id), selected: exportLlms, onChange: setExportLlms }), /* @__PURE__ */ import_react8.default.createElement(import_material6.Divider, { sx: { my: 1 } }), /* @__PURE__ */ import_react8.default.createElement(CheckSection, { label: "Triggers", items: props.config.triggers.map((t) => t.id), selected: exportTriggers, onChange: setExportTriggers }), /* @__PURE__ */ import_react8.default.createElement(import_material6.Box, { sx: { mt: 2 } }, /* @__PURE__ */ import_react8.default.createElement(import_material6.Button, { variant: "contained", size: "small", onClick: handleDownload, disabled: totalExport === 0 }, "Download JSON"))), tab === 1 && /* @__PURE__ */ import_react8.default.createElement(import_react8.default.Fragment, null, /* @__PURE__ */ import_react8.default.createElement(import_material6.Stack, { direction: "row", alignItems: "center", spacing: 2, sx: { mb: 2 } }, /* @__PURE__ */ import_react8.default.createElement("input", { ref: fileInputRef, type: "file", accept: ".json", style: { display: "none" }, onChange: handleFileChange }), /* @__PURE__ */ import_react8.default.createElement(import_material6.Button, { variant: "outlined", size: "small", onClick: () => fileInputRef.current?.click() }, "Upload JSON file\u2026"), importError && /* @__PURE__ */ import_react8.default.createElement(import_material6.Typography, { color: "error", variant: "body2" }, importError)), importFile && /* @__PURE__ */ import_react8.default.createElement(import_react8.default.Fragment, null, /* @__PURE__ */ import_react8.default.createElement(CheckSection, { label: "Providers", items: (importFile.providers ?? []).map((p) => p.name), selected: importProviders, onChange: setImportProviders, existsLabel: (key) => props.providers.some((p) => p.name === key) }), /* @__PURE__ */ import_react8.default.createElement(import_material6.Divider, { sx: { my: 1 } }), /* @__PURE__ */ import_react8.default.createElement(CheckSection, { label: "LLMs", items: (importFile.llms ?? []).map((l) => l.id), selected: importLlms, onChange: setImportLlms, existsLabel: (key) => props.config.llms.some((l) => l.id === key) }), /* @__PURE__ */ import_react8.default.createElement(import_material6.Divider, { sx: { my: 1 } }), /* @__PURE__ */ import_react8.default.createElement(CheckSection, { label: "Triggers", items: (importFile.triggers ?? []).map((t) => t.id), selected: importTriggers, onChange: setImportTriggers, existsLabel: (key) => props.config.triggers.some((t) => t.id === key) }), /* @__PURE__ */ import_react8.default.createElement(import_material6.Box, { sx: { mt: 2 } }, /* @__PURE__ */ import_react8.default.createElement(import_material6.Button, { variant: "contained", size: "small", onClick: handleImport, disabled: totalImport === 0 }, "Import selected")))))), /* @__PURE__ */ import_react8.default.createElement(import_material6.DialogActions, null, /* @__PURE__ */ import_react8.default.createElement(import_material6.Button, { onClick: () => props.onClose() }, "Close")));
  };

  // src/front/PinocchioPlayground.tsx
  var import_react9 = __toESM(require_react(), 1);
  var import_material7 = __toESM(require_material(), 1);
  var import_icons_material7 = __toESM(require_icons_material(), 1);
  var import_kwirth_common = __toESM(require_kwirth_common(), 1);
  var PinocchioPlayground = (props) => {
    const initialLengthRef = (0, import_react9.useRef)(props.content.length);
    const saved = props.pinocchioConfig.playground;
    const [llm, setLlm] = (0, import_react9.useState)(saved?.llm ?? "");
    const [steps, setSteps] = (0, import_react9.useState)(saved?.steps ?? 5);
    const [tools, setTools] = (0, import_react9.useState)(saved?.tools ?? []);
    const [autoTools, setAutoTools] = (0, import_react9.useState)(saved?.autoTools ?? false);
    const [toolFilter, setToolFilter] = (0, import_react9.useState)("");
    const [system, setSystem] = (0, import_react9.useState)(saved?.system ?? "");
    const [prompt, setPrompt] = (0, import_react9.useState)(saved?.prompt ?? "");
    const [eventData, setEventData] = (0, import_react9.useState)(saved?.eventData ?? "");
    const [triggerType, setTriggerType] = (0, import_react9.useState)(saved?.triggerType ?? "business");
    const [artifactKind, setArtifactKind] = (0, import_react9.useState)(saved?.artifactKind ?? "");
    const [eventSpace, setEventSpace] = (0, import_react9.useState)(saved?.eventSpace ?? "launch");
    const [eventType, setEventType] = (0, import_react9.useState)(saved?.eventType ?? "immediate");
    const [systemHistory, setSystemHistory] = (0, import_react9.useState)(saved?.systemHistory ?? []);
    const [promptHistory, setPromptHistory] = (0, import_react9.useState)(saved?.promptHistory ?? []);
    const [artifactHistory, setArtifactHistory] = (0, import_react9.useState)(saved?.artifactHistory ?? []);
    const [businessHistory, setBusinessHistory] = (0, import_react9.useState)(saved?.businessHistory ?? []);
    const [spaceTypeHistory, setSpaceTypeHistory] = (0, import_react9.useState)(saved?.spaceTypeHistory ?? []);
    const [historyAnchor, setHistoryAnchor] = (0, import_react9.useState)(null);
    const [historyType, setHistoryType] = (0, import_react9.useState)("system");
    const [configApplied, setConfigApplied] = (0, import_react9.useState)(false);
    const [firing, setFiring] = (0, import_react9.useState)(false);
    const [exportId, setExportId] = (0, import_react9.useState)("");
    const [showExport, setShowExport] = (0, import_react9.useState)(false);
    const [showImportDialog, setShowImportDialog] = (0, import_react9.useState)(false);
    const [pendingImportTriggerId, setPendingImportTriggerId] = (0, import_react9.useState)("");
    useKeyboard();
    const newContent = props.content.slice(initialLengthRef.current);
    const pushToHistory = (arr, value) => {
      if (!value.trim()) return arr;
      const filtered = arr.filter((v) => v !== value);
      return [value, ...filtered].slice(0, 25);
    };
    const pushToSpaceTypeHistory = (arr, space, type) => {
      if (!space.trim() && !type.trim()) return arr;
      const filtered = arr.filter((v) => v.space !== space || v.type !== type);
      return [{ space, type }, ...filtered].slice(0, 25);
    };
    const saveAndClose = (newTrigger) => {
      const newSystemHistory = pushToHistory(systemHistory, system);
      const newPromptHistory = pushToHistory(promptHistory, prompt);
      const newArtifactHistory = triggerType === "artifact" ? pushToHistory(artifactHistory, eventData) : artifactHistory;
      const newBusinessHistory = triggerType === "business" ? pushToHistory(businessHistory, eventData) : businessHistory;
      const newSpaceTypeHistory = triggerType === "business" ? pushToSpaceTypeHistory(spaceTypeHistory, eventSpace, eventType) : spaceTypeHistory;
      setSystemHistory(newSystemHistory);
      setPromptHistory(newPromptHistory);
      setArtifactHistory(newArtifactHistory);
      setBusinessHistory(newBusinessHistory);
      setSpaceTypeHistory(newSpaceTypeHistory);
      props.onStateChange({ llm, steps, tools, autoTools, system, prompt, eventData, triggerType, artifactKind, eventSpace, eventType, systemHistory: newSystemHistory, promptHistory: newPromptHistory, artifactHistory: newArtifactHistory, businessHistory: newBusinessHistory, spaceTypeHistory: newSpaceTypeHistory });
      props.onClose(newTrigger);
    };
    const openHistory = (e, type) => {
      setHistoryType(type);
      setHistoryAnchor(e.currentTarget);
    };
    const selectHistory = (value) => {
      if (historyType === "system") setSystem(value);
      else if (historyType === "prompt") {
        setPrompt(value);
        markDirty();
      } else setEventData(value);
      setHistoryAnchor(null);
    };
    const selectSpaceTypeHistory = (entry) => {
      setEventSpace(entry.space);
      setEventType(entry.type);
      setHistoryAnchor(null);
    };
    const removeFromHistory = (index) => {
      if (historyType === "system") setSystemHistory((h) => h.filter((_, i) => i !== index));
      else if (historyType === "prompt") setPromptHistory((h) => h.filter((_, i) => i !== index));
      else if (historyType === "artifact") setArtifactHistory((h) => h.filter((_, i) => i !== index));
      else if (historyType === "business") setBusinessHistory((h) => h.filter((_, i) => i !== index));
      else if (historyType === "spacetype") setSpaceTypeHistory((h) => h.filter((_, i) => i !== index));
    };
    const currentHistory = historyType === "system" ? systemHistory : historyType === "prompt" ? promptHistory : historyType === "artifact" ? artifactHistory : businessHistory;
    const markDirty = () => setConfigApplied(false);
    const confirmImportTrigger = () => {
      const t = props.pinocchioConfig.triggers.find((tr) => tr.id === pendingImportTriggerId);
      if (t) {
        if (t.trigger === "artifact" || t.trigger === "business") setTriggerType(t.trigger);
        const v = t.versions.find((v2) => v2.enabled) ?? t.versions[0];
        if (v) {
          setLlm(v.llm);
          setSteps(v.steps);
          setTools(v.tools);
          setAutoTools(v.autoTools ?? false);
          setSystem(v.system);
          setPrompt(v.prompt);
          markDirty();
        }
      }
      setShowImportDialog(false);
      setPendingImportTriggerId("");
    };
    const handleApply = () => {
      const version = {
        id: "playground",
        enabled: true,
        llm,
        steps,
        tools: autoTools ? props.toolsAvailable.map((t) => t.name) : tools,
        autoTools,
        system,
        prompt,
        promptType: "jinja",
        action: "inform",
        spaces: ["launch.immediate"]
      };
      const msg = {
        channel: "pinocchio",
        msgtype: "pinocchiomessage",
        id: "1",
        accessKey: props.accessString,
        instance: props.instanceId,
        command: "playgroundset" /* PLAYGROUNDSET */,
        action: import_kwirth_common.EInstanceMessageAction.COMMAND,
        flow: import_kwirth_common.EInstanceMessageFlow.REQUEST,
        type: import_kwirth_common.EInstanceMessageType.DATA,
        data: version
      };
      props.webSocket.send(JSON.stringify(msg));
      setConfigApplied(true);
    };
    const handleFire = async () => {
      setFiring(true);
      try {
        await fetch(`${props.clusterUrl}/business`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${props.accessString}`
          },
          body: JSON.stringify({
            space: triggerType === "artifact" ? "launch" : eventSpace,
            type: triggerType === "artifact" ? "immediate" : eventType,
            data: eventData,
            triggerType,
            kind: artifactKind
          })
        });
      } finally {
        setFiring(false);
      }
    };
    const handleExport = () => {
      if (!exportId.trim()) return;
      const trigger = {
        id: exportId.trim(),
        trigger: "business",
        versions: [{
          id: "v1",
          enabled: true,
          llm,
          steps,
          tools,
          autoTools,
          system,
          prompt,
          promptType: "jinja",
          action: "inform",
          spaces: ["launch.immediate"]
        }]
      };
      saveAndClose(trigger);
    };
    const onChangeTools = (e) => {
      setTools(e.target.value);
      markDirty();
    };
    const renderItem = (item, index) => {
      if ("findings" in item) return null;
      const msg = item;
      return /* @__PURE__ */ import_react9.default.createElement(import_material7.Typography, { key: index, variant: "body2", sx: { fontFamily: "monospace", whiteSpace: "pre-wrap", mb: 0.5 } }, /* @__PURE__ */ import_react9.default.createElement("span", { style: { color: "gray" } }, new Date(msg.timestamp).toLocaleTimeString(), " "), msg.text);
    };
    return /* @__PURE__ */ import_react9.default.createElement(import_material7.Dialog, { open: true, PaperProps: { sx: { width: "90vw", maxWidth: "1300px", height: "85vh" } } }, /* @__PURE__ */ import_react9.default.createElement(import_material7.DialogTitle, null, /* @__PURE__ */ import_react9.default.createElement(import_material7.Stack, { direction: "row", alignItems: "center", spacing: 1 }, /* @__PURE__ */ import_react9.default.createElement(import_icons_material7.ScienceOutlined, null), /* @__PURE__ */ import_react9.default.createElement(import_material7.Typography, { variant: "h6", flex: 1 }, "Playground"))), /* @__PURE__ */ import_react9.default.createElement(import_material7.DialogContent, { sx: { display: "flex", flexDirection: "column", gap: 1, pt: 1 } }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Stack, { direction: "row", spacing: 2, sx: { flex: "0 0 auto" } }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Stack, { spacing: 1, sx: { width: 260, flexShrink: 0 } }, /* @__PURE__ */ import_react9.default.createElement(import_material7.FormControl, { variant: "standard", fullWidth: true }, /* @__PURE__ */ import_react9.default.createElement(import_material7.InputLabel, null, "LLM"), /* @__PURE__ */ import_react9.default.createElement(import_material7.Select, { value: llm, onChange: (e) => {
      setLlm(e.target.value);
      markDirty();
    } }, props.pinocchioConfig.llms.map((l) => /* @__PURE__ */ import_react9.default.createElement(import_material7.MenuItem, { key: l.id, value: l.id }, l.id)))), /* @__PURE__ */ import_react9.default.createElement(
      import_material7.TextField,
      {
        label: "Max steps",
        type: "number",
        variant: "standard",
        value: steps,
        onChange: (e) => {
          setSteps(Math.max(1, +e.target.value));
          markDirty();
        },
        fullWidth: true
      }
    )), /* @__PURE__ */ import_react9.default.createElement(import_material7.Box, { flex: 1 }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Stack, { direction: "row", alignItems: "center", spacing: 0.5 }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Typography, { variant: "caption", color: "text.secondary" }, "System"), /* @__PURE__ */ import_react9.default.createElement(import_material7.IconButton, { size: "small", onClick: (e) => openHistory(e, "system"), disabled: systemHistory.length === 0 }, /* @__PURE__ */ import_react9.default.createElement(import_icons_material7.HistoryOutlined, { sx: { fontSize: 14 } }))), /* @__PURE__ */ import_react9.default.createElement(import_material7.Stack, { direction: "row", alignItems: "center", spacing: 1 }, /* @__PURE__ */ import_react9.default.createElement(
      import_material7.TextareaAutosize,
      {
        value: system,
        onChange: (e) => {
          setSystem(e.target.value);
          markDirty();
        },
        minRows: 5,
        maxRows: 5,
        style: { flex: 1, width: "100%", resize: "none", boxSizing: "border-box", fontFamily: "monospace", fontSize: 13, overflowY: "auto" },
        placeholder: "Enter system prompt\u2026"
      }
    ), /* @__PURE__ */ import_react9.default.createElement(import_material7.Stack, { spacing: 1, sx: { flexShrink: 0 } }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Button, { size: "small", startIcon: /* @__PURE__ */ import_react9.default.createElement(import_icons_material7.Upload, null), onClick: () => setShowImportDialog(true) }, "Import"), showExport ? /* @__PURE__ */ import_react9.default.createElement(import_material7.Stack, { spacing: 0.5 }, /* @__PURE__ */ import_react9.default.createElement(
      import_material7.TextField,
      {
        size: "small",
        label: "Trigger ID",
        value: exportId,
        onChange: (e) => setExportId(e.target.value),
        onKeyDown: (e) => {
          if (e.key === "Enter") handleExport();
        },
        autoFocus: true,
        sx: { width: 140 }
      }
    ), /* @__PURE__ */ import_react9.default.createElement(import_material7.Stack, { direction: "row", spacing: 0.5 }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Button, { size: "small", variant: "contained", onClick: handleExport, disabled: !exportId.trim() }, "Create"), /* @__PURE__ */ import_react9.default.createElement(import_material7.Button, { size: "small", onClick: () => setShowExport(false) }, "Cancel"))) : /* @__PURE__ */ import_react9.default.createElement(import_material7.Tooltip, { title: "Export current config as a new trigger (spaces: launch.immediate)" }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Button, { size: "small", startIcon: /* @__PURE__ */ import_react9.default.createElement(import_icons_material7.FileDownload, null), onClick: () => setShowExport(true) }, "Export")))))), /* @__PURE__ */ import_react9.default.createElement(import_material7.Divider, null), /* @__PURE__ */ import_react9.default.createElement(import_material7.Stack, { direction: "row", spacing: 1, sx: { flex: "0 0 auto" } }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Box, { flex: 1 }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Stack, { direction: "row", alignItems: "center", spacing: 0.5 }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Typography, { variant: "caption", color: "text.secondary" }, "Prompt"), /* @__PURE__ */ import_react9.default.createElement(import_material7.IconButton, { size: "small", onClick: (e) => openHistory(e, "prompt"), disabled: promptHistory.length === 0 }, /* @__PURE__ */ import_react9.default.createElement(import_icons_material7.HistoryOutlined, { sx: { fontSize: 14 } }))), /* @__PURE__ */ import_react9.default.createElement(
      import_material7.TextareaAutosize,
      {
        value: prompt,
        onChange: (e) => {
          setPrompt(e.target.value);
          markDirty();
        },
        minRows: 12,
        maxRows: 12,
        style: { width: "100%", resize: "none", boxSizing: "border-box", fontFamily: "monospace", fontSize: 13, overflowY: "auto" },
        placeholder: "Enter the Jinja prompt template\u2026"
      }
    )), /* @__PURE__ */ import_react9.default.createElement(import_material7.Box, { flex: 1 }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Stack, { direction: "row", alignItems: "center", spacing: 0.5 }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Typography, { variant: "caption", color: "text.secondary" }, "Artifact / Event JSON"), /* @__PURE__ */ import_react9.default.createElement(import_material7.IconButton, { size: "small", onClick: (e) => openHistory(e, triggerType), disabled: (triggerType === "artifact" ? artifactHistory : businessHistory).length === 0 }, /* @__PURE__ */ import_react9.default.createElement(import_icons_material7.HistoryOutlined, { sx: { fontSize: 14 } }))), /* @__PURE__ */ import_react9.default.createElement(
      import_material7.TextareaAutosize,
      {
        value: eventData,
        onChange: (e) => setEventData(e.target.value),
        minRows: 12,
        maxRows: 12,
        style: { width: "100%", resize: "none", boxSizing: "border-box", fontFamily: "monospace", fontSize: 13, overflowY: "auto" },
        placeholder: "Enter the artifact or JSON payload to send as the business event data\u2026"
      }
    ))), /* @__PURE__ */ import_react9.default.createElement(import_material7.Stack, { direction: "row", spacing: 2 }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Stack, { direction: "row", alignItems: "flex-end", spacing: 1, sx: { flex: 1 } }, /* @__PURE__ */ import_react9.default.createElement(
      import_material7.FormControlLabel,
      {
        control: /* @__PURE__ */ import_react9.default.createElement(import_material7.Switch, { size: "small", checked: autoTools, onChange: (e) => {
          setAutoTools(e.target.checked);
          markDirty();
        } }),
        label: /* @__PURE__ */ import_react9.default.createElement(import_material7.Typography, { variant: "caption" }, "Auto"),
        sx: { mr: 0, flexShrink: 0 }
      }
    ), /* @__PURE__ */ import_react9.default.createElement(import_material7.FormControl, { variant: "standard", disabled: autoTools, sx: { flex: 1, minWidth: 0 } }, /* @__PURE__ */ import_react9.default.createElement(import_material7.InputLabel, null, "Tools"), /* @__PURE__ */ import_react9.default.createElement(import_material7.Select, { multiple: true, value: tools, onChange: onChangeTools, renderValue: (sel) => autoTools ? `all (${props.toolsAvailable.length})` : sel.join(", ") }, /* @__PURE__ */ import_react9.default.createElement(import_material7.MenuItem, { disableRipple: true, onClickCapture: (e) => e.stopPropagation(), sx: { p: 0.5 } }, /* @__PURE__ */ import_react9.default.createElement(
      import_material7.TextField,
      {
        size: "small",
        placeholder: "Filter\u2026",
        value: toolFilter,
        onChange: (e) => setToolFilter(e.target.value),
        onKeyDown: (e) => e.stopPropagation(),
        fullWidth: true,
        variant: "outlined"
      }
    )), props.toolsAvailable.filter((t) => !toolFilter || t.name.includes(toolFilter) || t.description.toLowerCase().includes(toolFilter.toLowerCase())).map((tool) => /* @__PURE__ */ import_react9.default.createElement(import_material7.MenuItem, { key: tool.name, value: tool.name }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Checkbox, { size: "small", checked: tools.includes(tool.name) }), /* @__PURE__ */ import_react9.default.createElement(import_material7.Box, null, /* @__PURE__ */ import_react9.default.createElement(import_material7.Typography, { variant: "body2" }, tool.name), /* @__PURE__ */ import_react9.default.createElement(import_material7.Typography, { variant: "caption", color: "text.secondary" }, tool.description)))))), /* @__PURE__ */ import_react9.default.createElement(import_material7.Tooltip, { title: "Upload LLM, steps, tools and system to backend" }, /* @__PURE__ */ import_react9.default.createElement("span", null, /* @__PURE__ */ import_react9.default.createElement(
      import_material7.Button,
      {
        variant: configApplied ? "text" : "outlined",
        size: "small",
        startIcon: configApplied ? /* @__PURE__ */ import_react9.default.createElement(import_icons_material7.CheckCircleOutline, { color: "success" }) : /* @__PURE__ */ import_react9.default.createElement(import_icons_material7.Upload, null),
        onClick: handleApply,
        disabled: !llm,
        color: configApplied ? "success" : "primary",
        sx: { flexShrink: 0, whiteSpace: "nowrap" }
      },
      configApplied ? "Config applied" : "Apply Config"
    )))), /* @__PURE__ */ import_react9.default.createElement(import_material7.Stack, { direction: "row", alignItems: "flex-end", spacing: 1, sx: { flex: 1 } }, /* @__PURE__ */ import_react9.default.createElement(
      import_material7.ToggleButtonGroup,
      {
        value: triggerType,
        exclusive: true,
        size: "small",
        onChange: (_, v) => {
          if (v) setTriggerType(v);
        },
        sx: { flexShrink: 0 }
      },
      /* @__PURE__ */ import_react9.default.createElement(import_material7.ToggleButton, { value: "business" }, "Business"),
      /* @__PURE__ */ import_react9.default.createElement(import_material7.ToggleButton, { value: "artifact" }, "Artifact")
    ), triggerType === "artifact" ? /* @__PURE__ */ import_react9.default.createElement(import_material7.FormControl, { variant: "standard", size: "small", sx: { flex: 1 } }, /* @__PURE__ */ import_react9.default.createElement(import_material7.InputLabel, null, "Artifact Kind"), /* @__PURE__ */ import_react9.default.createElement(import_material7.Select, { value: artifactKind, onChange: (e) => setArtifactKind(e.target.value) }, kindsAvailable.map((k) => /* @__PURE__ */ import_react9.default.createElement(import_material7.MenuItem, { key: k, value: k }, k)))) : /* @__PURE__ */ import_react9.default.createElement(import_react9.default.Fragment, null, /* @__PURE__ */ import_react9.default.createElement(
      import_material7.TextField,
      {
        label: "Space",
        variant: "standard",
        size: "small",
        value: eventSpace,
        onChange: (e) => setEventSpace(e.target.value),
        sx: { flex: 1 }
      }
    ), /* @__PURE__ */ import_react9.default.createElement(
      import_material7.TextField,
      {
        label: "Type",
        variant: "standard",
        size: "small",
        value: eventType,
        onChange: (e) => setEventType(e.target.value),
        sx: { flex: 1 }
      }
    ), /* @__PURE__ */ import_react9.default.createElement(import_material7.IconButton, { size: "small", onClick: (e) => openHistory(e, "spacetype"), disabled: spaceTypeHistory.length === 0, sx: { alignSelf: "flex-end", mb: 0.5 } }, /* @__PURE__ */ import_react9.default.createElement(import_icons_material7.HistoryOutlined, { sx: { fontSize: 14 } }))), /* @__PURE__ */ import_react9.default.createElement(import_material7.Tooltip, { title: !configApplied ? "Apply config first" : `Send ${triggerType} event to the backend` }, /* @__PURE__ */ import_react9.default.createElement("span", null, /* @__PURE__ */ import_react9.default.createElement(
      import_material7.Button,
      {
        variant: "contained",
        size: "small",
        startIcon: /* @__PURE__ */ import_react9.default.createElement(import_icons_material7.Bolt, null),
        onClick: handleFire,
        disabled: !configApplied || firing
      },
      firing ? "Firing\u2026" : "Fire"
    ))))), /* @__PURE__ */ import_react9.default.createElement(import_material7.Divider, null), /* @__PURE__ */ import_react9.default.createElement(import_material7.Box, { sx: { flex: 1, overflowY: "auto", bgcolor: "action.hover", borderRadius: 1, p: 1, minHeight: 40 } }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Typography, { variant: "caption", color: "text.secondary" }, "Results"), newContent.length === 0 ? /* @__PURE__ */ import_react9.default.createElement(import_material7.Typography, { variant: "body2", color: "text.disabled", sx: { ml: 1 } }, "No results yet \u2014 apply config then fire.") : newContent.map((item, i) => renderItem(item, i)))), /* @__PURE__ */ import_react9.default.createElement(import_material7.DialogActions, null, /* @__PURE__ */ import_react9.default.createElement(import_material7.Button, { variant: "contained", onClick: () => saveAndClose() }, "Save"), /* @__PURE__ */ import_react9.default.createElement(import_material7.Button, { onClick: () => props.onClose() }, "Cancel")), /* @__PURE__ */ import_react9.default.createElement(import_material7.Menu, { anchorEl: historyAnchor, open: Boolean(historyAnchor), onClose: () => setHistoryAnchor(null), PaperProps: { sx: { maxHeight: 300, overflowY: "auto" } } }, historyType === "spacetype" ? spaceTypeHistory.map((entry, i) => /* @__PURE__ */ import_react9.default.createElement(import_material7.MenuItem, { key: i, onClick: () => selectSpaceTypeHistory(entry), sx: { display: "flex", gap: 1 } }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Typography, { variant: "body2", sx: { fontFamily: "monospace", fontSize: 12, flex: 1 } }, entry.space, " \xB7 ", entry.type), /* @__PURE__ */ import_react9.default.createElement(import_material7.IconButton, { size: "small", onClick: (e) => {
      e.stopPropagation();
      removeFromHistory(i);
    } }, /* @__PURE__ */ import_react9.default.createElement(import_icons_material7.DeleteOutlined, { sx: { fontSize: 14 } })))) : currentHistory.map((entry, i) => /* @__PURE__ */ import_react9.default.createElement(import_material7.MenuItem, { key: i, onClick: () => selectHistory(entry), sx: { maxWidth: 500, display: "flex", gap: 1 } }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Typography, { variant: "body2", noWrap: true, sx: { fontFamily: "monospace", fontSize: 12, flex: 1 } }, entry.length > 80 ? entry.slice(0, 80) + "\u2026" : entry), /* @__PURE__ */ import_react9.default.createElement(import_material7.IconButton, { size: "small", onClick: (e) => {
      e.stopPropagation();
      removeFromHistory(i);
    } }, /* @__PURE__ */ import_react9.default.createElement(import_icons_material7.DeleteOutlined, { sx: { fontSize: 14 } }))))), /* @__PURE__ */ import_react9.default.createElement(import_material7.Dialog, { open: showImportDialog, onClose: () => {
      setShowImportDialog(false);
      setPendingImportTriggerId("");
    } }, /* @__PURE__ */ import_react9.default.createElement(import_material7.DialogTitle, null, "Import from trigger"), /* @__PURE__ */ import_react9.default.createElement(import_material7.DialogContent, { sx: { display: "flex", flexDirection: "column", gap: 2, pt: 1, minWidth: 320 } }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Typography, { variant: "body2", color: "warning.main" }, "This will overwrite the current playground configuration (LLM, steps, tools, system and prompt)."), /* @__PURE__ */ import_react9.default.createElement(import_material7.FormControl, { variant: "standard", fullWidth: true }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Select, { value: pendingImportTriggerId, onChange: (e) => setPendingImportTriggerId(e.target.value), displayEmpty: true }, /* @__PURE__ */ import_react9.default.createElement(import_material7.MenuItem, { value: "" }, /* @__PURE__ */ import_react9.default.createElement(import_material7.Typography, { color: "gray" }, /* @__PURE__ */ import_react9.default.createElement("em", null, "\u2014 select a trigger \u2014"))), props.pinocchioConfig.triggers.map((t) => /* @__PURE__ */ import_react9.default.createElement(import_material7.MenuItem, { key: t.id, value: t.id }, t.id))))), /* @__PURE__ */ import_react9.default.createElement(import_material7.DialogActions, null, /* @__PURE__ */ import_react9.default.createElement(import_material7.Button, { variant: "contained", onClick: confirmImportTrigger, disabled: !pendingImportTriggerId }, "Import"), /* @__PURE__ */ import_react9.default.createElement(import_material7.Button, { onClick: () => {
      setShowImportDialog(false);
      setPendingImportTriggerId("");
    } }, "Cancel"))));
  };

  // src/front/PinocchioTabContent.tsx
  var PinocchioTabContent = (props) => {
    let pinocchioData = props.channelObject.data;
    const pinocchioBoxRef = (0, import_react10.useRef)(null);
    const messagesEndRef = (0, import_react10.useRef)(null);
    const [isAtBottom, setIsAtBottom] = (0, import_react10.useState)(true);
    const [pinocchioBoxTop, setPinocchioBoxTop] = (0, import_react10.useState)(0);
    const [showPlayground, setShowPlayground] = (0, import_react10.useState)(false);
    const [showConfigTrigger, setShowConfigTrigger] = (0, import_react10.useState)(false);
    const [showConfigLlm, setShowConfigLlm] = (0, import_react10.useState)(false);
    const [showConfigProvider, setShowConfigProvider] = (0, import_react10.useState)(false);
    const [showImportExport, setShowImportExport] = (0, import_react10.useState)(false);
    const [anchorMenu, setAnchorMenu] = (0, import_react10.useState)(void 0);
    const priorityOrder = {
      "critical": 0,
      "high": 1,
      "medium": 2,
      "low": 3
    };
    (0, import_react10.useEffect)(() => {
      if (pinocchioBoxRef.current) setPinocchioBoxTop(pinocchioBoxRef.current.getBoundingClientRect().top);
    });
    (0, import_react10.useEffect)(() => {
      if (isAtBottom && pinocchioBoxRef.current) {
        pinocchioBoxRef.current.scrollTo({
          top: pinocchioBoxRef.current.scrollHeight,
          behavior: "auto"
        });
      }
    }, [isAtBottom, pinocchioData.content.length]);
    (0, import_react10.useEffect)(() => {
      const timer = setTimeout(() => {
        if (messagesEndRef.current) {
          messagesEndRef.current.scrollIntoView({
            behavior: pinocchioData.content.length > 50 ? "auto" : "smooth",
            block: "end"
          });
        }
      }, 50);
      return () => clearTimeout(timer);
    }, [pinocchioData.content]);
    const color = (level) => {
      if (level === "low") return "gray";
      if (level === "medium") return "green";
      if (level === "high") return "orange";
      if (level === "critical") return "red";
    };
    const showContent = () => {
      if (!pinocchioData || !pinocchioData.content) return /* @__PURE__ */ import_react11.default.createElement(import_react11.default.Fragment, null);
      return /* @__PURE__ */ import_react11.default.createElement(import_react11.default.Fragment, null, pinocchioData.content.map((item, index) => {
        if (typeof item !== "string") {
          let analysis = item;
          return /* @__PURE__ */ import_react11.default.createElement(import_react11.default.Fragment, { key: index }, analysis.text && /* @__PURE__ */ import_react11.default.createElement(import_material8.Typography, { variant: "body1", sx: { mt: 2 } }, new Date(analysis.timestamp).toISOString(), " ", analysis.text), analysis.findings && [...analysis.findings].sort((a, b) => priorityOrder[a.level] - priorityOrder[b.level]).map((f, fIndex) => {
            let description = f.description;
            if (description.includes(" **") && description.includes("** ")) description = description.replace(" **", " <b><u>").replace("** ", "</u></b> ");
            return /* @__PURE__ */ import_react11.default.createElement(import_material8.Stack, { key: fIndex, direction: "row", alignItems: "center" }, /* @__PURE__ */ import_react11.default.createElement(import_material8.Box, { sx: { width: "70px" } }, /* @__PURE__ */ import_react11.default.createElement(import_material8.Typography, { variant: "body2", sx: { backgroundColor: color(f.level), display: "inline-block", p: 0.5, borderRadius: "4px" } }, f.level)), /* @__PURE__ */ import_react11.default.createElement(import_material8.Typography, { component: "div", variant: "body2" }, /* @__PURE__ */ import_react11.default.createElement("div", { dangerouslySetInnerHTML: { __html: description } })));
          }));
        } else {
          let message = item;
          return /* @__PURE__ */ import_react11.default.createElement(import_react11.default.Fragment, null, /* @__PURE__ */ import_react11.default.createElement(import_material8.Typography, { variant: "body1", sx: { mt: 2 } }, new Date(message.timestamp).toISOString(), " ", message.text));
        }
      }), /* @__PURE__ */ import_react11.default.createElement("span", { ref: messagesEndRef, style: { float: "left", clear: "both" } }));
    };
    const pinocchioConfigClose = (config) => {
      if (config) {
        pinocchioData.config = config;
        let msg = {
          channel: "pinocchio",
          msgtype: "pinocchiomessage",
          id: "1",
          accessKey: props.channelObject.accessString,
          instance: props.channelObject.instanceId,
          command: "configset" /* CONFIGSET */,
          action: import_kwirth_common2.EInstanceMessageAction.COMMAND,
          flow: import_kwirth_common2.EInstanceMessageFlow.REQUEST,
          type: import_kwirth_common2.EInstanceMessageType.DATA,
          data: config
        };
        props.channelObject.webSocket?.send(JSON.stringify(msg));
      }
      setShowConfigTrigger(false);
      setShowConfigLlm(false);
    };
    const pinocchioConfigProviderClose = (providers) => {
      if (providers) {
        pinocchioData.providers = providers;
        let msg = {
          channel: "pinocchio",
          msgtype: "pinocchiomessage",
          id: "1",
          accessKey: props.channelObject.accessString,
          instance: props.channelObject.instanceId,
          command: "providersset" /* PROVIDERSSET */,
          action: import_kwirth_common2.EInstanceMessageAction.COMMAND,
          flow: import_kwirth_common2.EInstanceMessageFlow.REQUEST,
          type: import_kwirth_common2.EInstanceMessageType.DATA,
          data: providers
        };
        props.channelObject.webSocket?.send(JSON.stringify(msg));
      }
      setShowConfigProvider(false);
    };
    const handleScroll = () => {
      if (pinocchioBoxRef.current) {
        const { scrollTop, scrollHeight, clientHeight } = pinocchioBoxRef.current;
        const distanceToBottom = scrollHeight - scrollTop - clientHeight;
        const atBottom = distanceToBottom < 25;
        setIsAtBottom(atBottom);
      }
    };
    const pinocchioPlaygroundStateChange = (state) => {
      const updatedConfig = { ...pinocchioData.config, playground: state };
      pinocchioData.config = updatedConfig;
      const msg = {
        channel: "pinocchio",
        msgtype: "pinocchiomessage",
        id: "1",
        accessKey: props.channelObject.accessString,
        instance: props.channelObject.instanceId,
        command: "configset" /* CONFIGSET */,
        action: import_kwirth_common2.EInstanceMessageAction.COMMAND,
        flow: import_kwirth_common2.EInstanceMessageFlow.REQUEST,
        type: import_kwirth_common2.EInstanceMessageType.DATA,
        data: updatedConfig
      };
      props.channelObject.webSocket?.send(JSON.stringify(msg));
    };
    const pinocchioPlaygroundClose = (newTrigger) => {
      setShowPlayground(false);
      if (!newTrigger) return;
      const updatedConfig = {
        ...pinocchioData.config,
        triggers: [...pinocchioData.config.triggers, newTrigger]
      };
      pinocchioData.config = updatedConfig;
      let msg = {
        channel: "pinocchio",
        msgtype: "pinocchiomessage",
        id: "1",
        accessKey: props.channelObject.accessString,
        instance: props.channelObject.instanceId,
        command: "configset" /* CONFIGSET */,
        action: import_kwirth_common2.EInstanceMessageAction.COMMAND,
        flow: import_kwirth_common2.EInstanceMessageFlow.REQUEST,
        type: import_kwirth_common2.EInstanceMessageType.DATA,
        data: updatedConfig
      };
      props.channelObject.webSocket?.send(JSON.stringify(msg));
    };
    const pinocchioImportExportClose = (providers, config) => {
      if (providers) {
        pinocchioData.providers = providers;
        let msg = {
          channel: "pinocchio",
          msgtype: "pinocchiomessage",
          id: "1",
          accessKey: props.channelObject.accessString,
          instance: props.channelObject.instanceId,
          command: "providersset" /* PROVIDERSSET */,
          action: import_kwirth_common2.EInstanceMessageAction.COMMAND,
          flow: import_kwirth_common2.EInstanceMessageFlow.REQUEST,
          type: import_kwirth_common2.EInstanceMessageType.DATA,
          data: providers
        };
        props.channelObject.webSocket?.send(JSON.stringify(msg));
      }
      if (config) {
        pinocchioData.config = config;
        let msg = {
          channel: "pinocchio",
          msgtype: "pinocchiomessage",
          id: "1",
          accessKey: props.channelObject.accessString,
          instance: props.channelObject.instanceId,
          command: "configset" /* CONFIGSET */,
          action: import_kwirth_common2.EInstanceMessageAction.COMMAND,
          flow: import_kwirth_common2.EInstanceMessageFlow.REQUEST,
          type: import_kwirth_common2.EInstanceMessageType.DATA,
          data: config
        };
        props.channelObject.webSocket?.send(JSON.stringify(msg));
      }
      setShowImportExport(false);
    };
    const onConfigAction = (a) => {
      setAnchorMenu(void 0);
      switch (a) {
        case "provider":
          setShowConfigProvider(true);
          break;
        case "llm":
          setShowConfigLlm(true);
          break;
        case "trigger":
          setShowConfigTrigger(true);
          break;
        case "importexport":
          setShowImportExport(true);
          break;
      }
    };
    return /* @__PURE__ */ import_react11.default.createElement(import_react11.default.Fragment, null, pinocchioData.started && /* @__PURE__ */ import_react11.default.createElement(import_material8.Card, { sx: { display: "flex", flexDirection: "column", flex: 1, width: "98%", alignSelf: "center", marginTop: "8px", minHeight: 0 } }, /* @__PURE__ */ import_react11.default.createElement(import_material8.CardHeader, { title: /* @__PURE__ */ import_react11.default.createElement(import_material8.Stack, { direction: "row", alignItems: "center" }, /* @__PURE__ */ import_react11.default.createElement(import_material8.Typography, { marginRight: "32px" }, /* @__PURE__ */ import_react11.default.createElement("b", null, "Events:"), " ", pinocchioData.content.length), /* @__PURE__ */ import_react11.default.createElement(import_material8.Typography, { marginRight: "32px", flex: 1 }, /* @__PURE__ */ import_react11.default.createElement(import_icons_material8.Info, { fontSize: "small", sx: { marginBottom: "2px" } }), /* @__PURE__ */ import_react11.default.createElement("b", null, "\xA0Status:"), " ", pinocchioData.paused ? "paused" : pinocchioData.started ? "started" : "stopped"), /* @__PURE__ */ import_react11.default.createElement(import_material8.Button, { onClick: () => setShowPlayground(true) }, "Playground"), /* @__PURE__ */ import_react11.default.createElement(import_material8.Button, { onClick: (event) => setAnchorMenu(event.currentTarget) }, "Config")) }), /* @__PURE__ */ import_react11.default.createElement(import_material8.CardContent, { sx: { flex: 1, display: "flex", flexDirection: "column", minHeight: 0, p: 0, "&:last-child": { pb: 0 } } }, /* @__PURE__ */ import_react11.default.createElement(import_material8.Box, { ref: pinocchioBoxRef, sx: { display: "flex", flexDirection: "column", width: "100%", overflowY: "auto", flexGrow: 1, height: `calc(100vh - ${pinocchioBoxTop}px - 16px)` }, onScroll: handleScroll }, /* @__PURE__ */ import_react11.default.createElement(import_material8.Box, { sx: { flex: 1, overflowY: "auto", ml: 1, mr: 1 } }, showContent())))), showConfigTrigger && /* @__PURE__ */ import_react11.default.createElement(PinocchioConfigTrigger, { pinocchioConfig: pinocchioData.config, toolsAvailable: pinocchioData.toolsAvailable.map((t) => t.name), onClose: pinocchioConfigClose }), showConfigLlm && /* @__PURE__ */ import_react11.default.createElement(PinocchioConfigLlm, { pinocchioConfig: pinocchioData.config, providers: pinocchioData.providers, onClose: pinocchioConfigClose }), showConfigProvider && /* @__PURE__ */ import_react11.default.createElement(PinocchioConfigProvider, { providers: pinocchioData.providers, providersAvailable: pinocchioData.providersAvailable, onClose: pinocchioConfigProviderClose }), showPlayground && /* @__PURE__ */ import_react11.default.createElement(PinocchioPlayground, { pinocchioConfig: pinocchioData.config, toolsAvailable: pinocchioData.toolsAvailable, accessString: props.channelObject.accessString, instanceId: props.channelObject.instanceId, webSocket: props.channelObject.webSocket, clusterUrl: props.channelObject.clusterUrl, content: pinocchioData.content, onClose: pinocchioPlaygroundClose, onStateChange: pinocchioPlaygroundStateChange }), showImportExport && /* @__PURE__ */ import_react11.default.createElement(PinocchioImportExport, { providers: pinocchioData.providers, config: pinocchioData.config, onClose: pinocchioImportExportClose }), anchorMenu && /* @__PURE__ */ import_react11.default.createElement(MenuConfig, { anchorParent: anchorMenu, providers: pinocchioData.providers, pinocchioConfig: pinocchioData.config, onAction: onConfigAction, onClose: () => setAnchorMenu(void 0) }));
  };

  // src/front/PinocchioChannel.ts
  var PinocchioChannel = class {
    constructor() {
      this.channelId = "pinocchio";
      this.setupVisible = false;
      this.SetupDialog = PinocchioSetup;
      this.TabContent = PinocchioTabContent;
      this.requirements = {
        accessString: true,
        clusterUrl: true,
        clusterInfo: false,
        exit: false,
        frontChannels: false,
        metrics: false,
        notifier: true,
        notifications: false,
        setup: false,
        settings: false,
        palette: false,
        userSettings: false,
        webSocket: true
      };
    }
    getScope() {
      return import_kwirth_common3.EInstanceConfigScope.NONE;
    }
    getChannelIcon() {
      return PinocchioIcon;
    }
    getSetupVisibility() {
      return this.setupVisible;
    }
    setSetupVisibility(visibility) {
      this.setupVisible = visibility;
    }
    processChannelMessage(channelObject, wsEvent) {
      let msg = JSON.parse(wsEvent.data);
      let pinocchioData = channelObject.data;
      switch (msg.type) {
        case import_kwirth_common3.EInstanceMessageType.DATA:
          if (msg.analysis) pinocchioData.content.push(msg.analysis);
          else if (msg.config) pinocchioData.config = msg.config;
          else if (msg.providers) pinocchioData.providers = msg.providers;
          else if (msg.providersAvailable) pinocchioData.providersAvailable = msg.providersAvailable;
          else if (msg.toolsAvailable) pinocchioData.toolsAvailable = msg.toolsAvailable;
          else if (msg.message) pinocchioData.content.push(msg.message);
          return {
            action: import_kwirth_common3.EChannelRefreshAction.REFRESH
          };
        case import_kwirth_common3.EInstanceMessageType.SIGNAL:
          let signalMessage = JSON.parse(wsEvent.data);
          if (signalMessage.flow === import_kwirth_common3.EInstanceMessageFlow.RESPONSE && signalMessage.action === import_kwirth_common3.EInstanceMessageAction.START) {
            channelObject.instanceId = signalMessage.instance;
            let msgProvidersAvailable = {
              channel: "pinocchio",
              msgtype: "pinocchiomessage",
              action: import_kwirth_common3.EInstanceMessageAction.COMMAND,
              flow: import_kwirth_common3.EInstanceMessageFlow.REQUEST,
              type: import_kwirth_common3.EInstanceMessageType.DATA,
              command: "providersavailable" /* PROVIDERSAVAILABLE */,
              accessKey: channelObject.accessString,
              instance: signalMessage.instance,
              id: "1"
            };
            channelObject.webSocket?.send(JSON.stringify(msgProvidersAvailable));
            let msgToolsAvailable = {
              channel: "pinocchio",
              msgtype: "pinocchiomessage",
              action: import_kwirth_common3.EInstanceMessageAction.COMMAND,
              flow: import_kwirth_common3.EInstanceMessageFlow.REQUEST,
              type: import_kwirth_common3.EInstanceMessageType.DATA,
              command: "toolsavailable" /* TOOLSAVAILABLE */,
              accessKey: channelObject.accessString,
              instance: signalMessage.instance,
              id: "1"
            };
            channelObject.webSocket?.send(JSON.stringify(msgToolsAvailable));
            let msgProviders = {
              channel: "pinocchio",
              msgtype: "pinocchiomessage",
              action: import_kwirth_common3.EInstanceMessageAction.COMMAND,
              flow: import_kwirth_common3.EInstanceMessageFlow.REQUEST,
              type: import_kwirth_common3.EInstanceMessageType.DATA,
              command: "providersget" /* PROVIDERSGET */,
              accessKey: channelObject.accessString,
              instance: signalMessage.instance,
              id: "1"
            };
            channelObject.webSocket?.send(JSON.stringify(msgProviders));
            let msgConfig = {
              channel: "pinocchio",
              msgtype: "pinocchiomessage",
              action: import_kwirth_common3.EInstanceMessageAction.COMMAND,
              flow: import_kwirth_common3.EInstanceMessageFlow.REQUEST,
              type: import_kwirth_common3.EInstanceMessageType.DATA,
              command: "configget" /* CONFIGGET */,
              accessKey: channelObject.accessString,
              instance: signalMessage.instance,
              id: "1"
            };
            channelObject.webSocket?.send(JSON.stringify(msgConfig));
          } else {
            channelObject.notify?.(this.channelId, signalMessage.level, signalMessage.text || signalMessage.data);
          }
          return {
            action: import_kwirth_common3.EChannelRefreshAction.REFRESH
          };
        default:
          console.log(`Invalid message type ${msg.type}`);
          return {
            action: import_kwirth_common3.EChannelRefreshAction.NONE
          };
      }
    }
    async initChannel(channelObject) {
      channelObject.instanceConfig = new PinocchioInstanceConfig();
      channelObject.config = new PinocchioConfig();
      channelObject.data = new PinocchioData();
      let pinocchioObject = channelObject.data;
      pinocchioObject.content = [];
      return false;
    }
    prepareExternalChannel(_contentView, _selectedFiles, _container) {
      return {
        data: new PinocchioData(),
        config: new PinocchioConfig(),
        instanceConfig: new PinocchioInstanceConfig(),
        formConfig: {}
      };
    }
    startChannel(channelObject) {
      let pinocchioObject = channelObject.data;
      pinocchioObject.content.push({ timestamp: Date.now(), text: "Local start pinocchio channel" });
      pinocchioObject.paused = false;
      pinocchioObject.started = true;
      return true;
    }
    pauseChannel(channelObject) {
      let pinocchioObject = channelObject.data;
      pinocchioObject.paused = true;
      return true;
    }
    continueChannel(channelObject) {
      let pinocchioObject = channelObject.data;
      pinocchioObject.paused = false;
      return true;
    }
    stopChannel(channelObject) {
      let pinocchioObject = channelObject.data;
      pinocchioObject.paused = false;
      pinocchioObject.started = false;
      return true;
    }
    socketDisconnected(channelObject) {
      return false;
    }
    socketReconnect(channelObject) {
      return false;
    }
  };

  // src/front/index.ts
  if (!window.__kwirth_plugins__) window.__kwirth_plugins__ = {};
  window.__kwirth_plugins__["pinocchio"] = PinocchioChannel;
})();
