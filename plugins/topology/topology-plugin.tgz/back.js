"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/@kwirthmagnify/kwirth-common/dist/Channel.js
var require_Channel = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/Channel.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.EClusterType = exports2.ClusterTypeEnum = void 0;
    var ClusterTypeEnum;
    (function(ClusterTypeEnum2) {
      ClusterTypeEnum2["KUBERNETES"] = "kubernetes";
      ClusterTypeEnum2["DOCKER"] = "docker";
    })(ClusterTypeEnum || (exports2.ClusterTypeEnum = ClusterTypeEnum = {}));
    var EClusterType2;
    (function(EClusterType3) {
      EClusterType3["KUBERNETES"] = "kubernetes";
      EClusterType3["DOCKER"] = "docker";
    })(EClusterType2 || (exports2.EClusterType = EClusterType2 = {}));
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/InstanceMessage.js
var require_InstanceMessage = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/InstanceMessage.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.EInstanceMessageFlow = exports2.InstanceMessageFlowEnum = exports2.EInstanceMessageAction = exports2.InstanceMessageActionEnum = exports2.EInstanceMessageType = exports2.InstanceMessageTypeEnum = exports2.EInstanceMessageChannel = exports2.InstanceMessageChannelEnum = void 0;
    var InstanceMessageChannelEnum;
    (function(InstanceMessageChannelEnum2) {
      InstanceMessageChannelEnum2["NONE"] = "none";
      InstanceMessageChannelEnum2["LOG"] = "log";
      InstanceMessageChannelEnum2["METRICS"] = "metrics";
      InstanceMessageChannelEnum2["AUDIT"] = "audit";
      InstanceMessageChannelEnum2["OPS"] = "ops";
      InstanceMessageChannelEnum2["ALERT"] = "alert";
      InstanceMessageChannelEnum2["TRIVY"] = "trivy";
    })(InstanceMessageChannelEnum || (exports2.InstanceMessageChannelEnum = InstanceMessageChannelEnum = {}));
    var EInstanceMessageChannel;
    (function(EInstanceMessageChannel2) {
      EInstanceMessageChannel2["NONE"] = "none";
      EInstanceMessageChannel2["LOG"] = "log";
      EInstanceMessageChannel2["METRICS"] = "metrics";
      EInstanceMessageChannel2["AUDIT"] = "audit";
      EInstanceMessageChannel2["OPS"] = "ops";
      EInstanceMessageChannel2["ALERT"] = "alert";
      EInstanceMessageChannel2["TRIVY"] = "trivy";
      EInstanceMessageChannel2["MAGNIFY"] = "magnify";
    })(EInstanceMessageChannel || (exports2.EInstanceMessageChannel = EInstanceMessageChannel = {}));
    var InstanceMessageTypeEnum;
    (function(InstanceMessageTypeEnum2) {
      InstanceMessageTypeEnum2["DATA"] = "data";
      InstanceMessageTypeEnum2["SIGNAL"] = "signal";
    })(InstanceMessageTypeEnum || (exports2.InstanceMessageTypeEnum = InstanceMessageTypeEnum = {}));
    var EInstanceMessageType2;
    (function(EInstanceMessageType3) {
      EInstanceMessageType3["DATA"] = "data";
      EInstanceMessageType3["SIGNAL"] = "signal";
    })(EInstanceMessageType2 || (exports2.EInstanceMessageType = EInstanceMessageType2 = {}));
    var InstanceMessageActionEnum;
    (function(InstanceMessageActionEnum2) {
      InstanceMessageActionEnum2["NONE"] = "none";
      InstanceMessageActionEnum2["ROUTE"] = "route";
      InstanceMessageActionEnum2["START"] = "start";
      InstanceMessageActionEnum2["STOP"] = "stop";
      InstanceMessageActionEnum2["PAUSE"] = "pause";
      InstanceMessageActionEnum2["CONTINUE"] = "continue";
      InstanceMessageActionEnum2["MODIFY"] = "modify";
      InstanceMessageActionEnum2["PING"] = "ping";
      InstanceMessageActionEnum2["RECONNECT"] = "reconnect";
      InstanceMessageActionEnum2["COMMAND"] = "command";
      InstanceMessageActionEnum2["WEBSOCKET"] = "websocket";
    })(InstanceMessageActionEnum || (exports2.InstanceMessageActionEnum = InstanceMessageActionEnum = {}));
    var EInstanceMessageAction2;
    (function(EInstanceMessageAction3) {
      EInstanceMessageAction3["NONE"] = "none";
      EInstanceMessageAction3["RI"] = "ri";
      EInstanceMessageAction3["ROUTE"] = "route";
      EInstanceMessageAction3["START"] = "start";
      EInstanceMessageAction3["STOP"] = "stop";
      EInstanceMessageAction3["PAUSE"] = "pause";
      EInstanceMessageAction3["CONTINUE"] = "continue";
      EInstanceMessageAction3["MODIFY"] = "modify";
      EInstanceMessageAction3["PING"] = "ping";
      EInstanceMessageAction3["RECONNECT"] = "reconnect";
      EInstanceMessageAction3["COMMAND"] = "command";
      EInstanceMessageAction3["WEBSOCKET"] = "websocket";
    })(EInstanceMessageAction2 || (exports2.EInstanceMessageAction = EInstanceMessageAction2 = {}));
    var InstanceMessageFlowEnum;
    (function(InstanceMessageFlowEnum2) {
      InstanceMessageFlowEnum2["IMMEDIATE"] = "immediate";
      InstanceMessageFlowEnum2["REQUEST"] = "request";
      InstanceMessageFlowEnum2["RESPONSE"] = "response";
      InstanceMessageFlowEnum2["UNSOLICITED"] = "unsolicited";
    })(InstanceMessageFlowEnum || (exports2.InstanceMessageFlowEnum = InstanceMessageFlowEnum = {}));
    var EInstanceMessageFlow2;
    (function(EInstanceMessageFlow3) {
      EInstanceMessageFlow3["IMMEDIATE"] = "immediate";
      EInstanceMessageFlow3["REQUEST"] = "request";
      EInstanceMessageFlow3["RESPONSE"] = "response";
      EInstanceMessageFlow3["UNSOLICITED"] = "unsolicited";
    })(EInstanceMessageFlow2 || (exports2.EInstanceMessageFlow = EInstanceMessageFlow2 = {}));
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/InstanceConfig.js
var require_InstanceConfig = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/InstanceConfig.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.EInstanceConfigScope = exports2.EInstanceConfigView = exports2.EInstanceConfigObject = exports2.InstanceConfigScopeEnum = exports2.InstanceConfigViewEnum = exports2.InstanceConfigObjectEnum = void 0;
    var InstanceConfigObjectEnum;
    (function(InstanceConfigObjectEnum2) {
      InstanceConfigObjectEnum2["PODS"] = "pods";
      InstanceConfigObjectEnum2["EVENTS"] = "events";
    })(InstanceConfigObjectEnum || (exports2.InstanceConfigObjectEnum = InstanceConfigObjectEnum = {}));
    var InstanceConfigViewEnum;
    (function(InstanceConfigViewEnum2) {
      InstanceConfigViewEnum2["NONE"] = "none";
      InstanceConfigViewEnum2["CLUSTER"] = "cluster";
      InstanceConfigViewEnum2["NAMESPACE"] = "namespace";
      InstanceConfigViewEnum2["GROUP"] = "group";
      InstanceConfigViewEnum2["POD"] = "pod";
      InstanceConfigViewEnum2["CONTAINER"] = "container";
    })(InstanceConfigViewEnum || (exports2.InstanceConfigViewEnum = InstanceConfigViewEnum = {}));
    var InstanceConfigScopeEnum;
    (function(InstanceConfigScopeEnum2) {
      InstanceConfigScopeEnum2["NONE"] = "none";
      InstanceConfigScopeEnum2["API"] = "api";
      InstanceConfigScopeEnum2["CLUSTER"] = "cluster";
      InstanceConfigScopeEnum2["FILTER"] = "filter";
      InstanceConfigScopeEnum2["VIEW"] = "view";
      InstanceConfigScopeEnum2["SNAPSHOT"] = "snapshot";
      InstanceConfigScopeEnum2["STREAM"] = "stream";
      InstanceConfigScopeEnum2["CREATE"] = "create";
      InstanceConfigScopeEnum2["SUBSCRIBE"] = "subscribe";
      InstanceConfigScopeEnum2["GET"] = "get";
      InstanceConfigScopeEnum2["EXECUTE"] = "execute";
      InstanceConfigScopeEnum2["RESTART"] = "restart";
      InstanceConfigScopeEnum2["WORKLOAD"] = "workload";
      InstanceConfigScopeEnum2["KUBERNETES"] = "kubernetes";
    })(InstanceConfigScopeEnum || (exports2.InstanceConfigScopeEnum = InstanceConfigScopeEnum = {}));
    var EInstanceConfigObject;
    (function(EInstanceConfigObject2) {
      EInstanceConfigObject2["PODS"] = "pods";
      EInstanceConfigObject2["EVENTS"] = "events";
    })(EInstanceConfigObject || (exports2.EInstanceConfigObject = EInstanceConfigObject = {}));
    var EInstanceConfigView;
    (function(EInstanceConfigView2) {
      EInstanceConfigView2["NONE"] = "none";
      EInstanceConfigView2["CLUSTER"] = "cluster";
      EInstanceConfigView2["NAMESPACE"] = "namespace";
      EInstanceConfigView2["GROUP"] = "group";
      EInstanceConfigView2["POD"] = "pod";
      EInstanceConfigView2["CONTAINER"] = "container";
    })(EInstanceConfigView || (exports2.EInstanceConfigView = EInstanceConfigView = {}));
    var EInstanceConfigScope;
    (function(EInstanceConfigScope2) {
      EInstanceConfigScope2["NONE"] = "none";
      EInstanceConfigScope2["API"] = "api";
      EInstanceConfigScope2["CLUSTER"] = "cluster";
      EInstanceConfigScope2["FILTER"] = "filter";
      EInstanceConfigScope2["VIEW"] = "view";
      EInstanceConfigScope2["SNAPSHOT"] = "snapshot";
      EInstanceConfigScope2["STREAM"] = "stream";
      EInstanceConfigScope2["CREATE"] = "create";
      EInstanceConfigScope2["SUBSCRIBE"] = "subscribe";
      EInstanceConfigScope2["GET"] = "get";
      EInstanceConfigScope2["EXECUTE"] = "execute";
      EInstanceConfigScope2["RESTART"] = "restart";
      EInstanceConfigScope2["WORKLOAD"] = "workload";
      EInstanceConfigScope2["KUBERNETES"] = "kubernetes";
    })(EInstanceConfigScope || (exports2.EInstanceConfigScope = EInstanceConfigScope = {}));
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/RouteMessage.js
var require_RouteMessage = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/RouteMessage.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/SignalMessage.js
var require_SignalMessage = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/SignalMessage.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ESignalMessageEvent = exports2.ESignalMessageLevel = exports2.SignalMessageEventEnum = exports2.SignalMessageLevelEnum = void 0;
    var SignalMessageLevelEnum;
    (function(SignalMessageLevelEnum2) {
      SignalMessageLevelEnum2["INFO"] = "info";
      SignalMessageLevelEnum2["WARNING"] = "warning";
      SignalMessageLevelEnum2["ERROR"] = "error";
    })(SignalMessageLevelEnum || (exports2.SignalMessageLevelEnum = SignalMessageLevelEnum = {}));
    var SignalMessageEventEnum;
    (function(SignalMessageEventEnum2) {
      SignalMessageEventEnum2["ADD"] = "add";
      SignalMessageEventEnum2["DELETE"] = "delete";
      SignalMessageEventEnum2["OTHER"] = "other";
    })(SignalMessageEventEnum || (exports2.SignalMessageEventEnum = SignalMessageEventEnum = {}));
    var ESignalMessageLevel2;
    (function(ESignalMessageLevel3) {
      ESignalMessageLevel3["INFO"] = "info";
      ESignalMessageLevel3["WARNING"] = "warning";
      ESignalMessageLevel3["ERROR"] = "error";
    })(ESignalMessageLevel2 || (exports2.ESignalMessageLevel = ESignalMessageLevel2 = {}));
    var ESignalMessageEvent;
    (function(ESignalMessageEvent2) {
      ESignalMessageEvent2["ADD"] = "add";
      ESignalMessageEvent2["DELETE"] = "delete";
      ESignalMessageEvent2["OTHER"] = "other";
    })(ESignalMessageEvent || (exports2.ESignalMessageEvent = ESignalMessageEvent = {}));
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/ApiKey.js
var require_ApiKey = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/ApiKey.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// node_modules/uuid/dist/cjs/max.js
var require_max = __commonJS({
  "node_modules/uuid/dist/cjs/max.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.default = "ffffffff-ffff-ffff-ffff-ffffffffffff";
  }
});

// node_modules/uuid/dist/cjs/nil.js
var require_nil = __commonJS({
  "node_modules/uuid/dist/cjs/nil.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.default = "00000000-0000-0000-0000-000000000000";
  }
});

// node_modules/uuid/dist/cjs/regex.js
var require_regex = __commonJS({
  "node_modules/uuid/dist/cjs/regex.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.default = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/i;
  }
});

// node_modules/uuid/dist/cjs/validate.js
var require_validate = __commonJS({
  "node_modules/uuid/dist/cjs/validate.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var regex_js_1 = require_regex();
    function validate(uuid) {
      return typeof uuid === "string" && regex_js_1.default.test(uuid);
    }
    exports2.default = validate;
  }
});

// node_modules/uuid/dist/cjs/parse.js
var require_parse = __commonJS({
  "node_modules/uuid/dist/cjs/parse.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var validate_js_1 = require_validate();
    function parse(uuid) {
      if (!(0, validate_js_1.default)(uuid)) {
        throw TypeError("Invalid UUID");
      }
      let v;
      return Uint8Array.of((v = parseInt(uuid.slice(0, 8), 16)) >>> 24, v >>> 16 & 255, v >>> 8 & 255, v & 255, (v = parseInt(uuid.slice(9, 13), 16)) >>> 8, v & 255, (v = parseInt(uuid.slice(14, 18), 16)) >>> 8, v & 255, (v = parseInt(uuid.slice(19, 23), 16)) >>> 8, v & 255, (v = parseInt(uuid.slice(24, 36), 16)) / 1099511627776 & 255, v / 4294967296 & 255, v >>> 24 & 255, v >>> 16 & 255, v >>> 8 & 255, v & 255);
    }
    exports2.default = parse;
  }
});

// node_modules/uuid/dist/cjs/stringify.js
var require_stringify = __commonJS({
  "node_modules/uuid/dist/cjs/stringify.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.unsafeStringify = void 0;
    var validate_js_1 = require_validate();
    var byteToHex = [];
    for (let i = 0; i < 256; ++i) {
      byteToHex.push((i + 256).toString(16).slice(1));
    }
    function unsafeStringify(arr, offset = 0) {
      return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
    }
    exports2.unsafeStringify = unsafeStringify;
    function stringify(arr, offset = 0) {
      const uuid = unsafeStringify(arr, offset);
      if (!(0, validate_js_1.default)(uuid)) {
        throw TypeError("Stringified UUID is invalid");
      }
      return uuid;
    }
    exports2.default = stringify;
  }
});

// node_modules/uuid/dist/cjs/rng.js
var require_rng = __commonJS({
  "node_modules/uuid/dist/cjs/rng.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var crypto_1 = require("crypto");
    var rnds8Pool = new Uint8Array(256);
    var poolPtr = rnds8Pool.length;
    function rng() {
      if (poolPtr > rnds8Pool.length - 16) {
        (0, crypto_1.randomFillSync)(rnds8Pool);
        poolPtr = 0;
      }
      return rnds8Pool.slice(poolPtr, poolPtr += 16);
    }
    exports2.default = rng;
  }
});

// node_modules/uuid/dist/cjs/v1.js
var require_v1 = __commonJS({
  "node_modules/uuid/dist/cjs/v1.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.updateV1State = void 0;
    var rng_js_1 = require_rng();
    var stringify_js_1 = require_stringify();
    var _state = {};
    function v1(options, buf, offset) {
      let bytes;
      const isV6 = options?._v6 ?? false;
      if (options) {
        const optionsKeys = Object.keys(options);
        if (optionsKeys.length === 1 && optionsKeys[0] === "_v6") {
          options = void 0;
        }
      }
      if (options) {
        bytes = v1Bytes(options.random ?? options.rng?.() ?? (0, rng_js_1.default)(), options.msecs, options.nsecs, options.clockseq, options.node, buf, offset);
      } else {
        const now = Date.now();
        const rnds = (0, rng_js_1.default)();
        updateV1State(_state, now, rnds);
        bytes = v1Bytes(rnds, _state.msecs, _state.nsecs, isV6 ? void 0 : _state.clockseq, isV6 ? void 0 : _state.node, buf, offset);
      }
      return buf ?? (0, stringify_js_1.unsafeStringify)(bytes);
    }
    function updateV1State(state, now, rnds) {
      state.msecs ??= -Infinity;
      state.nsecs ??= 0;
      if (now === state.msecs) {
        state.nsecs++;
        if (state.nsecs >= 1e4) {
          state.node = void 0;
          state.nsecs = 0;
        }
      } else if (now > state.msecs) {
        state.nsecs = 0;
      } else if (now < state.msecs) {
        state.node = void 0;
      }
      if (!state.node) {
        state.node = rnds.slice(10, 16);
        state.node[0] |= 1;
        state.clockseq = (rnds[8] << 8 | rnds[9]) & 16383;
      }
      state.msecs = now;
      return state;
    }
    exports2.updateV1State = updateV1State;
    function v1Bytes(rnds, msecs, nsecs, clockseq, node, buf, offset = 0) {
      if (rnds.length < 16) {
        throw new Error("Random bytes length must be >= 16");
      }
      if (!buf) {
        buf = new Uint8Array(16);
        offset = 0;
      } else {
        if (offset < 0 || offset + 16 > buf.length) {
          throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
      }
      msecs ??= Date.now();
      nsecs ??= 0;
      clockseq ??= (rnds[8] << 8 | rnds[9]) & 16383;
      node ??= rnds.slice(10, 16);
      msecs += 122192928e5;
      const tl = ((msecs & 268435455) * 1e4 + nsecs) % 4294967296;
      buf[offset++] = tl >>> 24 & 255;
      buf[offset++] = tl >>> 16 & 255;
      buf[offset++] = tl >>> 8 & 255;
      buf[offset++] = tl & 255;
      const tmh = msecs / 4294967296 * 1e4 & 268435455;
      buf[offset++] = tmh >>> 8 & 255;
      buf[offset++] = tmh & 255;
      buf[offset++] = tmh >>> 24 & 15 | 16;
      buf[offset++] = tmh >>> 16 & 255;
      buf[offset++] = clockseq >>> 8 | 128;
      buf[offset++] = clockseq & 255;
      for (let n = 0; n < 6; ++n) {
        buf[offset++] = node[n];
      }
      return buf;
    }
    exports2.default = v1;
  }
});

// node_modules/uuid/dist/cjs/v1ToV6.js
var require_v1ToV6 = __commonJS({
  "node_modules/uuid/dist/cjs/v1ToV6.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var parse_js_1 = require_parse();
    var stringify_js_1 = require_stringify();
    function v1ToV6(uuid) {
      const v1Bytes = typeof uuid === "string" ? (0, parse_js_1.default)(uuid) : uuid;
      const v6Bytes = _v1ToV6(v1Bytes);
      return typeof uuid === "string" ? (0, stringify_js_1.unsafeStringify)(v6Bytes) : v6Bytes;
    }
    exports2.default = v1ToV6;
    function _v1ToV6(v1Bytes) {
      return Uint8Array.of((v1Bytes[6] & 15) << 4 | v1Bytes[7] >> 4 & 15, (v1Bytes[7] & 15) << 4 | (v1Bytes[4] & 240) >> 4, (v1Bytes[4] & 15) << 4 | (v1Bytes[5] & 240) >> 4, (v1Bytes[5] & 15) << 4 | (v1Bytes[0] & 240) >> 4, (v1Bytes[0] & 15) << 4 | (v1Bytes[1] & 240) >> 4, (v1Bytes[1] & 15) << 4 | (v1Bytes[2] & 240) >> 4, 96 | v1Bytes[2] & 15, v1Bytes[3], v1Bytes[8], v1Bytes[9], v1Bytes[10], v1Bytes[11], v1Bytes[12], v1Bytes[13], v1Bytes[14], v1Bytes[15]);
    }
  }
});

// node_modules/uuid/dist/cjs/md5.js
var require_md5 = __commonJS({
  "node_modules/uuid/dist/cjs/md5.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var crypto_1 = require("crypto");
    function md5(bytes) {
      if (Array.isArray(bytes)) {
        bytes = Buffer.from(bytes);
      } else if (typeof bytes === "string") {
        bytes = Buffer.from(bytes, "utf8");
      }
      return (0, crypto_1.createHash)("md5").update(bytes).digest();
    }
    exports2.default = md5;
  }
});

// node_modules/uuid/dist/cjs/v35.js
var require_v35 = __commonJS({
  "node_modules/uuid/dist/cjs/v35.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.URL = exports2.DNS = exports2.stringToBytes = void 0;
    var parse_js_1 = require_parse();
    var stringify_js_1 = require_stringify();
    function stringToBytes(str) {
      str = unescape(encodeURIComponent(str));
      const bytes = new Uint8Array(str.length);
      for (let i = 0; i < str.length; ++i) {
        bytes[i] = str.charCodeAt(i);
      }
      return bytes;
    }
    exports2.stringToBytes = stringToBytes;
    exports2.DNS = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";
    exports2.URL = "6ba7b811-9dad-11d1-80b4-00c04fd430c8";
    function v35(version, hash, value, namespace, buf, offset) {
      const valueBytes = typeof value === "string" ? stringToBytes(value) : value;
      const namespaceBytes = typeof namespace === "string" ? (0, parse_js_1.default)(namespace) : namespace;
      if (typeof namespace === "string") {
        namespace = (0, parse_js_1.default)(namespace);
      }
      if (namespace?.length !== 16) {
        throw TypeError("Namespace must be array-like (16 iterable integer values, 0-255)");
      }
      let bytes = new Uint8Array(16 + valueBytes.length);
      bytes.set(namespaceBytes);
      bytes.set(valueBytes, namespaceBytes.length);
      bytes = hash(bytes);
      bytes[6] = bytes[6] & 15 | version;
      bytes[8] = bytes[8] & 63 | 128;
      if (buf) {
        offset = offset || 0;
        if (offset < 0 || offset + 16 > buf.length) {
          throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
        for (let i = 0; i < 16; ++i) {
          buf[offset + i] = bytes[i];
        }
        return buf;
      }
      return (0, stringify_js_1.unsafeStringify)(bytes);
    }
    exports2.default = v35;
  }
});

// node_modules/uuid/dist/cjs/v3.js
var require_v3 = __commonJS({
  "node_modules/uuid/dist/cjs/v3.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.URL = exports2.DNS = void 0;
    var md5_js_1 = require_md5();
    var v35_js_1 = require_v35();
    var v35_js_2 = require_v35();
    Object.defineProperty(exports2, "DNS", { enumerable: true, get: function() {
      return v35_js_2.DNS;
    } });
    Object.defineProperty(exports2, "URL", { enumerable: true, get: function() {
      return v35_js_2.URL;
    } });
    function v3(value, namespace, buf, offset) {
      return (0, v35_js_1.default)(48, md5_js_1.default, value, namespace, buf, offset);
    }
    v3.DNS = v35_js_1.DNS;
    v3.URL = v35_js_1.URL;
    exports2.default = v3;
  }
});

// node_modules/uuid/dist/cjs/native.js
var require_native = __commonJS({
  "node_modules/uuid/dist/cjs/native.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var crypto_1 = require("crypto");
    exports2.default = { randomUUID: crypto_1.randomUUID };
  }
});

// node_modules/uuid/dist/cjs/v4.js
var require_v4 = __commonJS({
  "node_modules/uuid/dist/cjs/v4.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var native_js_1 = require_native();
    var rng_js_1 = require_rng();
    var stringify_js_1 = require_stringify();
    function v4(options, buf, offset) {
      if (native_js_1.default.randomUUID && !buf && !options) {
        return native_js_1.default.randomUUID();
      }
      options = options || {};
      const rnds = options.random ?? options.rng?.() ?? (0, rng_js_1.default)();
      if (rnds.length < 16) {
        throw new Error("Random bytes length must be >= 16");
      }
      rnds[6] = rnds[6] & 15 | 64;
      rnds[8] = rnds[8] & 63 | 128;
      if (buf) {
        offset = offset || 0;
        if (offset < 0 || offset + 16 > buf.length) {
          throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
        for (let i = 0; i < 16; ++i) {
          buf[offset + i] = rnds[i];
        }
        return buf;
      }
      return (0, stringify_js_1.unsafeStringify)(rnds);
    }
    exports2.default = v4;
  }
});

// node_modules/uuid/dist/cjs/sha1.js
var require_sha1 = __commonJS({
  "node_modules/uuid/dist/cjs/sha1.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var crypto_1 = require("crypto");
    function sha1(bytes) {
      if (Array.isArray(bytes)) {
        bytes = Buffer.from(bytes);
      } else if (typeof bytes === "string") {
        bytes = Buffer.from(bytes, "utf8");
      }
      return (0, crypto_1.createHash)("sha1").update(bytes).digest();
    }
    exports2.default = sha1;
  }
});

// node_modules/uuid/dist/cjs/v5.js
var require_v5 = __commonJS({
  "node_modules/uuid/dist/cjs/v5.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.URL = exports2.DNS = void 0;
    var sha1_js_1 = require_sha1();
    var v35_js_1 = require_v35();
    var v35_js_2 = require_v35();
    Object.defineProperty(exports2, "DNS", { enumerable: true, get: function() {
      return v35_js_2.DNS;
    } });
    Object.defineProperty(exports2, "URL", { enumerable: true, get: function() {
      return v35_js_2.URL;
    } });
    function v5(value, namespace, buf, offset) {
      return (0, v35_js_1.default)(80, sha1_js_1.default, value, namespace, buf, offset);
    }
    v5.DNS = v35_js_1.DNS;
    v5.URL = v35_js_1.URL;
    exports2.default = v5;
  }
});

// node_modules/uuid/dist/cjs/v6.js
var require_v6 = __commonJS({
  "node_modules/uuid/dist/cjs/v6.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var stringify_js_1 = require_stringify();
    var v1_js_1 = require_v1();
    var v1ToV6_js_1 = require_v1ToV6();
    function v6(options, buf, offset) {
      options ??= {};
      offset ??= 0;
      let bytes = (0, v1_js_1.default)({ ...options, _v6: true }, new Uint8Array(16));
      bytes = (0, v1ToV6_js_1.default)(bytes);
      if (buf) {
        if (offset < 0 || offset + 16 > buf.length) {
          throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
        for (let i = 0; i < 16; i++) {
          buf[offset + i] = bytes[i];
        }
        return buf;
      }
      return (0, stringify_js_1.unsafeStringify)(bytes);
    }
    exports2.default = v6;
  }
});

// node_modules/uuid/dist/cjs/v6ToV1.js
var require_v6ToV1 = __commonJS({
  "node_modules/uuid/dist/cjs/v6ToV1.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var parse_js_1 = require_parse();
    var stringify_js_1 = require_stringify();
    function v6ToV1(uuid) {
      const v6Bytes = typeof uuid === "string" ? (0, parse_js_1.default)(uuid) : uuid;
      const v1Bytes = _v6ToV1(v6Bytes);
      return typeof uuid === "string" ? (0, stringify_js_1.unsafeStringify)(v1Bytes) : v1Bytes;
    }
    exports2.default = v6ToV1;
    function _v6ToV1(v6Bytes) {
      return Uint8Array.of((v6Bytes[3] & 15) << 4 | v6Bytes[4] >> 4 & 15, (v6Bytes[4] & 15) << 4 | (v6Bytes[5] & 240) >> 4, (v6Bytes[5] & 15) << 4 | v6Bytes[6] & 15, v6Bytes[7], (v6Bytes[1] & 15) << 4 | (v6Bytes[2] & 240) >> 4, (v6Bytes[2] & 15) << 4 | (v6Bytes[3] & 240) >> 4, 16 | (v6Bytes[0] & 240) >> 4, (v6Bytes[0] & 15) << 4 | (v6Bytes[1] & 240) >> 4, v6Bytes[8], v6Bytes[9], v6Bytes[10], v6Bytes[11], v6Bytes[12], v6Bytes[13], v6Bytes[14], v6Bytes[15]);
    }
  }
});

// node_modules/uuid/dist/cjs/v7.js
var require_v7 = __commonJS({
  "node_modules/uuid/dist/cjs/v7.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.updateV7State = void 0;
    var rng_js_1 = require_rng();
    var stringify_js_1 = require_stringify();
    var _state = {};
    function v7(options, buf, offset) {
      let bytes;
      if (options) {
        bytes = v7Bytes(options.random ?? options.rng?.() ?? (0, rng_js_1.default)(), options.msecs, options.seq, buf, offset);
      } else {
        const now = Date.now();
        const rnds = (0, rng_js_1.default)();
        updateV7State(_state, now, rnds);
        bytes = v7Bytes(rnds, _state.msecs, _state.seq, buf, offset);
      }
      return buf ?? (0, stringify_js_1.unsafeStringify)(bytes);
    }
    function updateV7State(state, now, rnds) {
      state.msecs ??= -Infinity;
      state.seq ??= 0;
      if (now > state.msecs) {
        state.seq = rnds[6] << 23 | rnds[7] << 16 | rnds[8] << 8 | rnds[9];
        state.msecs = now;
      } else {
        state.seq = state.seq + 1 | 0;
        if (state.seq === 0) {
          state.msecs++;
        }
      }
      return state;
    }
    exports2.updateV7State = updateV7State;
    function v7Bytes(rnds, msecs, seq, buf, offset = 0) {
      if (rnds.length < 16) {
        throw new Error("Random bytes length must be >= 16");
      }
      if (!buf) {
        buf = new Uint8Array(16);
        offset = 0;
      } else {
        if (offset < 0 || offset + 16 > buf.length) {
          throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
      }
      msecs ??= Date.now();
      seq ??= rnds[6] * 127 << 24 | rnds[7] << 16 | rnds[8] << 8 | rnds[9];
      buf[offset++] = msecs / 1099511627776 & 255;
      buf[offset++] = msecs / 4294967296 & 255;
      buf[offset++] = msecs / 16777216 & 255;
      buf[offset++] = msecs / 65536 & 255;
      buf[offset++] = msecs / 256 & 255;
      buf[offset++] = msecs & 255;
      buf[offset++] = 112 | seq >>> 28 & 15;
      buf[offset++] = seq >>> 20 & 255;
      buf[offset++] = 128 | seq >>> 14 & 63;
      buf[offset++] = seq >>> 6 & 255;
      buf[offset++] = seq << 2 & 255 | rnds[10] & 3;
      buf[offset++] = rnds[11];
      buf[offset++] = rnds[12];
      buf[offset++] = rnds[13];
      buf[offset++] = rnds[14];
      buf[offset++] = rnds[15];
      return buf;
    }
    exports2.default = v7;
  }
});

// node_modules/uuid/dist/cjs/version.js
var require_version = __commonJS({
  "node_modules/uuid/dist/cjs/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var validate_js_1 = require_validate();
    function version(uuid) {
      if (!(0, validate_js_1.default)(uuid)) {
        throw TypeError("Invalid UUID");
      }
      return parseInt(uuid.slice(14, 15), 16);
    }
    exports2.default = version;
  }
});

// node_modules/uuid/dist/cjs/index.js
var require_cjs = __commonJS({
  "node_modules/uuid/dist/cjs/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.version = exports2.validate = exports2.v7 = exports2.v6ToV1 = exports2.v6 = exports2.v5 = exports2.v4 = exports2.v3 = exports2.v1ToV6 = exports2.v1 = exports2.stringify = exports2.parse = exports2.NIL = exports2.MAX = void 0;
    var max_js_1 = require_max();
    Object.defineProperty(exports2, "MAX", { enumerable: true, get: function() {
      return max_js_1.default;
    } });
    var nil_js_1 = require_nil();
    Object.defineProperty(exports2, "NIL", { enumerable: true, get: function() {
      return nil_js_1.default;
    } });
    var parse_js_1 = require_parse();
    Object.defineProperty(exports2, "parse", { enumerable: true, get: function() {
      return parse_js_1.default;
    } });
    var stringify_js_1 = require_stringify();
    Object.defineProperty(exports2, "stringify", { enumerable: true, get: function() {
      return stringify_js_1.default;
    } });
    var v1_js_1 = require_v1();
    Object.defineProperty(exports2, "v1", { enumerable: true, get: function() {
      return v1_js_1.default;
    } });
    var v1ToV6_js_1 = require_v1ToV6();
    Object.defineProperty(exports2, "v1ToV6", { enumerable: true, get: function() {
      return v1ToV6_js_1.default;
    } });
    var v3_js_1 = require_v3();
    Object.defineProperty(exports2, "v3", { enumerable: true, get: function() {
      return v3_js_1.default;
    } });
    var v4_js_1 = require_v4();
    Object.defineProperty(exports2, "v4", { enumerable: true, get: function() {
      return v4_js_1.default;
    } });
    var v5_js_1 = require_v5();
    Object.defineProperty(exports2, "v5", { enumerable: true, get: function() {
      return v5_js_1.default;
    } });
    var v6_js_1 = require_v6();
    Object.defineProperty(exports2, "v6", { enumerable: true, get: function() {
      return v6_js_1.default;
    } });
    var v6ToV1_js_1 = require_v6ToV1();
    Object.defineProperty(exports2, "v6ToV1", { enumerable: true, get: function() {
      return v6ToV1_js_1.default;
    } });
    var v7_js_1 = require_v7();
    Object.defineProperty(exports2, "v7", { enumerable: true, get: function() {
      return v7_js_1.default;
    } });
    var validate_js_1 = require_validate();
    Object.defineProperty(exports2, "validate", { enumerable: true, get: function() {
      return validate_js_1.default;
    } });
    var version_js_1 = require_version();
    Object.defineProperty(exports2, "version", { enumerable: true, get: function() {
      return version_js_1.default;
    } });
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/AccessKey.js
var require_AccessKey = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/AccessKey.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AccessKey = void 0;
    exports2.accessKeyBuild = accessKeyBuild;
    exports2.accessKeyCreate = accessKeyCreate;
    exports2.accessKeyDeserialize = accessKeyDeserialize;
    exports2.accessKeySerialize = accessKeySerialize;
    exports2.parseResource = parseResource;
    exports2.parseResources = parseResources;
    exports2.buildResource = buildResource;
    var uuid_1 = require_cjs();
    var AccessKey = class {
      constructor() {
        this.id = "";
        this.type = "volatile";
        this.resources = "";
      }
    };
    exports2.AccessKey = AccessKey;
    function accessKeyCreate(type, resources) {
      let accessKey = new AccessKey();
      accessKey.id = (0, uuid_1.v4)();
      accessKey.type = type;
      accessKey.resources = resources;
      return accessKey;
    }
    function accessKeyBuild(id, type, resources) {
      let accessKey = new AccessKey();
      accessKey.id = id;
      accessKey.type = type;
      accessKey.resources = resources;
      return accessKey;
    }
    function accessKeySerialize(accessKey) {
      return `${accessKey.id}|${accessKey.type}|${accessKey.resources}`;
    }
    function accessKeyDeserialize(key) {
      var parts = key.split("|");
      return accessKeyBuild(parts[0], parts[1], parts[2]);
    }
    function parseResource(key) {
      var parts = key.split(":");
      return {
        scopes: parts[0],
        namespaces: parts[1],
        groups: parts[2],
        pods: parts[3],
        containers: parts[4]
      };
    }
    function parseResources(key) {
      if (!key)
        return [];
      let ress = key.split(";");
      let result = [];
      for (var res of ress) {
        result.push(parseResource(res));
      }
      return result;
    }
    function buildResource(scopes, namespaces, groups, pods, containers) {
      return `${scopes.join(",")}:${namespaces.join(",")}:${groups.join(",")}:${pods.join(",")}:${containers.join(",")}`;
    }
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/Global.js
var require_Global = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/Global.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/Version.js
var require_Version = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/Version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.versionGreaterThan = exports2.versionGreatOrEqualThan = void 0;
    var versionGreatOrEqualThan = (version1, version2) => {
      return versionGreaterThan(version1, version2) || version1 === version2;
    };
    exports2.versionGreatOrEqualThan = versionGreatOrEqualThan;
    var versionGreaterThan = (version1, version2) => {
      const v1 = version1.split(".").map(Number);
      const v2 = version2.split(".").map(Number);
      for (let i = 0; i < Math.max(v1.length, v2.length); i++) {
        const num1 = v1[i] || 0;
        const num2 = v2[i] || 0;
        if (num1 > num2)
          return true;
        else if (num1 < num2)
          return false;
      }
      return false;
    };
    exports2.versionGreaterThan = versionGreaterThan;
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/FrontChannel.js
var require_FrontChannel = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/FrontChannel.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.EChannelRefreshAction = exports2.ENotifyLevel = void 0;
    var ENotifyLevel;
    (function(ENotifyLevel2) {
      ENotifyLevel2["INFO"] = "info";
      ENotifyLevel2["ERROR"] = "error";
      ENotifyLevel2["WARNING"] = "warning";
      ENotifyLevel2["SUCCESS"] = "success";
    })(ENotifyLevel || (exports2.ENotifyLevel = ENotifyLevel = {}));
    var EChannelRefreshAction;
    (function(EChannelRefreshAction2) {
      EChannelRefreshAction2[EChannelRefreshAction2["NONE"] = 0] = "NONE";
      EChannelRefreshAction2[EChannelRefreshAction2["REFRESH"] = 1] = "REFRESH";
      EChannelRefreshAction2[EChannelRefreshAction2["STOP"] = 2] = "STOP";
    })(EChannelRefreshAction || (exports2.EChannelRefreshAction = EChannelRefreshAction = {}));
  }
});

// node_modules/@kwirthmagnify/kwirth-common/dist/index.js
var require_dist = __commonJS({
  "node_modules/@kwirthmagnify/kwirth-common/dist/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p)) __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_Channel(), exports2);
    __exportStar(require_InstanceMessage(), exports2);
    __exportStar(require_InstanceConfig(), exports2);
    __exportStar(require_RouteMessage(), exports2);
    __exportStar(require_SignalMessage(), exports2);
    __exportStar(require_ApiKey(), exports2);
    __exportStar(require_AccessKey(), exports2);
    __exportStar(require_Global(), exports2);
    __exportStar(require_Version(), exports2);
    __exportStar(require_FrontChannel(), exports2);
  }
});

// src/back/index.ts
var index_exports = {};
__export(index_exports, {
  TopologyChannel: () => TopologyChannel,
  default: () => index_default
});
module.exports = __toCommonJS(index_exports);
var import_kwirth_common = __toESM(require_dist(), 1);
function podStatus(p) {
  if (p.metadata?.deletionTimestamp) return "Terminating";
  switch (p.status?.phase) {
    case "Running":
      return "Running";
    case "Pending":
      return "Pending";
    case "Succeeded":
      return "Succeeded";
    case "Failed":
      return "Failed";
    default:
      return "Unknown";
  }
}
function controllerStatus(ready, desired) {
  if (desired === void 0 || desired === 0) return "Unknown";
  if ((ready ?? 0) >= desired) return "Running";
  if ((ready ?? 0) > 0) return "Pending";
  return "Failed";
}
function pvcStatus(p) {
  switch (p.status?.phase) {
    case "Bound":
      return "Bound";
    case "Pending":
      return "Pending";
    case "Released":
      return "Released";
    case "Lost":
      return "Lost";
    default:
      return "Unknown";
  }
}
var TopologyChannel = class {
  constructor(clusterInfo, backChannelObject) {
    this.channelId = "topology";
    this.requirements = {
      storage: false,
      providers: ["events"]
    };
    this.webSockets = [];
    this.serviceCache = /* @__PURE__ */ new Map();
    this.pvcCache = /* @__PURE__ */ new Map();
    this.startChannel = async () => {
      this.clusterInfo.addSubscriber("events", this, {
        kinds: ["Pod", "Service", "Deployment", "StatefulSet", "DaemonSet", "ReplicaSet", "Job", "CronJob", "Ingress", "PersistentVolumeClaim"],
        syncInstances: false
      });
    };
    this.addObject = async (ws, instanceConfig) => {
      try {
        let entry = this.webSockets.find((s) => s.ws === ws);
        if (!entry) {
          this.webSockets.push({ ws, lastRefresh: Date.now(), instances: [] });
          entry = this.webSockets[this.webSockets.length - 1];
        }
        if (entry.instances.some((i) => i.instanceId === instanceConfig.instance)) return true;
        const ns = instanceConfig.namespace;
        const namespaces = ns && ns !== "" && ns !== "*all" ? ns.split(",").filter(Boolean) : ["*all"];
        const data = instanceConfig.data;
        const toStrArray = (v) => Array.isArray(v) && v.length > 0 ? v : void 0;
        const pods = toStrArray(data?.pods);
        const services = toStrArray(data?.services);
        const ingresses = toStrArray(data?.ingresses);
        const groups = toStrArray(data?.groups);
        const inst = {
          instanceId: instanceConfig.instance,
          namespaces,
          pods,
          services,
          ingresses,
          groups,
          paused: false
        };
        entry.instances.push(inst);
        await this.sendSnapshot(ws, inst);
      } catch (err) {
        this.sendSignal(ws, instanceConfig, import_kwirth_common.ESignalMessageLevel.ERROR, err?.message ?? String(err));
      }
      return true;
    };
    this.deleteObject = async () => false;
    this.containsAsset = () => false;
    this.clusterInfo = clusterInfo;
    this.backChannelObject = backChannelObject;
  }
  getChannelData() {
    return {
      id: "topology",
      routable: false,
      pauseable: false,
      modifiable: false,
      reconnectable: true,
      metrics: false,
      sources: [import_kwirth_common.EClusterType.KUBERNETES],
      endpoints: [],
      websocket: false,
      cluster: true,
      resourced: true
    };
  }
  getChannelScopeLevel(scope) {
    return ["", "filter", "view", "cluster"].indexOf(scope);
  }
  processProviderEvent(providerId, obj) {
    if (providerId !== "events") return;
    const type = obj.type;
    const resource = obj.obj;
    if (resource.kind === "Service") {
      if (type === "DELETED") this.serviceCache.delete(resource.metadata?.uid ?? "");
      else if (resource.metadata?.uid) this.serviceCache.set(resource.metadata.uid, resource);
    }
    if (resource.kind === "PersistentVolumeClaim") {
      if (type === "DELETED") this.pvcCache.delete(resource.metadata?.uid ?? "");
      else if (resource.metadata?.uid) this.pvcCache.set(resource.metadata.uid, resource);
    }
    const mapped = this.mapResource(resource);
    if (!mapped) return;
    if (type !== "DELETED") {
      const svcList = Array.from(this.serviceCache.values());
      const edges = this.computeEdges(resource, svcList);
      if (edges.length > 0) mapped.edges = edges;
    }
    for (const entry of this.webSockets) {
      for (const inst of entry.instances) {
        if (inst.paused) continue;
        const ns = resource.metadata?.namespace;
        if (!inst.namespaces.includes("*all") && ns && !inst.namespaces.includes(ns)) continue;
        if (inst.focusedUids && !inst.focusedUids.has(resource.metadata?.uid ?? "")) continue;
        this.emit(entry.ws, inst, mapped, type);
      }
    }
  }
  async endpointRequest(_e, _req, _res) {
  }
  async websocketRequest(_ws) {
  }
  async processCommand(ws, msg) {
    const m = msg;
    try {
      switch (m.topoAction) {
        case "SCALE":
          await this.doScale(ws, msg, m.kind, m.namespace, m.name, m.replicas ?? 0);
          return true;
        case "RESTART":
          await this.doRestart(ws, msg, m.kind, m.namespace, m.name);
          return true;
        case "DELETE_POD":
          await this.clusterInfo.coreApi.deleteNamespacedPod({ name: m.name, namespace: m.namespace });
          this.sendSignal(ws, msg, import_kwirth_common.ESignalMessageLevel.INFO, `Pod ${m.name} deleted`);
          return true;
        default:
          return false;
      }
    } catch (err) {
      this.sendSignal(ws, msg, import_kwirth_common.ESignalMessageLevel.ERROR, err?.message ?? String(err));
      return false;
    }
  }
  containsInstance(instanceId) {
    return this.webSockets.some((s) => s.instances.some((i) => i.instanceId === instanceId));
  }
  containsConnection(ws) {
    return this.webSockets.some((s) => s.ws === ws);
  }
  removeConnection(ws) {
    this.webSockets = this.webSockets.filter((s) => s.ws !== ws);
  }
  refreshConnection(ws) {
    const entry = this.webSockets.find((s) => s.ws === ws);
    if (entry) {
      entry.lastRefresh = Date.now();
      return true;
    }
    return false;
  }
  updateConnection(ws, instanceId) {
    return this.webSockets.some((s) => s.ws === ws && s.instances.some((i) => i.instanceId === instanceId));
  }
  pauseContinueInstance(ws, instanceConfig, action) {
    const inst = this.findInstance(ws, instanceConfig.instance);
    if (!inst) return;
    inst.paused = action === import_kwirth_common.EInstanceMessageAction.PAUSE;
    this.sendInstanceConfig(
      ws,
      action,
      import_kwirth_common.EInstanceMessageFlow.RESPONSE,
      instanceConfig,
      inst.paused ? "Topology paused" : "Topology resumed"
    );
  }
  modifyInstance() {
  }
  stopInstance(ws, instanceConfig) {
    const entry = this.webSockets.find((s) => s.ws === ws);
    if (!entry) return;
    entry.instances = entry.instances.filter((i) => i.instanceId !== instanceConfig.instance);
    this.sendInstanceConfig(ws, import_kwirth_common.EInstanceMessageAction.STOP, import_kwirth_common.EInstanceMessageFlow.RESPONSE, instanceConfig, "Topology stopped");
  }
  removeInstance(ws, instanceId) {
    const entry = this.webSockets.find((s) => s.ws === ws);
    if (!entry) return;
    entry.instances = entry.instances.filter((i) => i.instanceId !== instanceId);
  }
  nsMatch(inst, ns) {
    return inst.namespaces.includes("*all") || !!ns && inst.namespaces.includes(ns);
  }
  async sendSnapshot(ws, inst) {
    const isFocused = !!(inst.pods?.length || inst.services?.length || inst.ingresses?.length || inst.groups?.length);
    if (isFocused) {
      await this.sendFocusedSnapshot(ws, inst);
    } else {
      await this.sendFullSnapshot(ws, inst);
    }
  }
  async sendFullSnapshot(ws, inst) {
    const [pods, svcs, deps, sts, ds, rs, jobs, crons, ings, pvcs] = await Promise.allSettled([
      this.clusterInfo.coreApi.listPodForAllNamespaces(),
      this.clusterInfo.coreApi.listServiceForAllNamespaces(),
      this.clusterInfo.appsApi.listDeploymentForAllNamespaces(),
      this.clusterInfo.appsApi.listStatefulSetForAllNamespaces(),
      this.clusterInfo.appsApi.listDaemonSetForAllNamespaces(),
      this.clusterInfo.appsApi.listReplicaSetForAllNamespaces(),
      this.clusterInfo.batchApi.listJobForAllNamespaces(),
      this.clusterInfo.batchApi.listCronJobForAllNamespaces(),
      this.clusterInfo.networkApi.listIngressForAllNamespaces(),
      this.clusterInfo.coreApi.listPersistentVolumeClaimForAllNamespaces()
    ]);
    const svcList = svcs.status === "fulfilled" ? svcs.value.items.filter((s) => this.nsMatch(inst, s.metadata?.namespace)) : [];
    const pvcList = pvcs.status === "fulfilled" ? pvcs.value.items.filter((p) => this.nsMatch(inst, p.metadata?.namespace)) : [];
    svcList.forEach((s) => {
      if (s.metadata?.uid) this.serviceCache.set(s.metadata.uid, s);
    });
    pvcList.forEach((p) => {
      if (p.metadata?.uid) this.pvcCache.set(p.metadata.uid, p);
    });
    svcList.forEach((s) => this.emit(ws, inst, this.mapService(s), "ADDED"));
    if (deps.status === "fulfilled") deps.value.items.filter((d) => this.nsMatch(inst, d.metadata?.namespace)).forEach((d) => this.emit(ws, inst, { ...this.mapDeployment(d), edges: this.edgesForController(d.spec?.selector?.matchLabels, d.metadata?.namespace, svcList) }, "ADDED"));
    if (sts.status === "fulfilled") sts.value.items.filter((s) => this.nsMatch(inst, s.metadata?.namespace)).forEach((s) => this.emit(ws, inst, { ...this.mapStatefulSet(s), edges: this.edgesForController(s.spec?.selector?.matchLabels, s.metadata?.namespace, svcList) }, "ADDED"));
    if (ds.status === "fulfilled") ds.value.items.filter((d) => this.nsMatch(inst, d.metadata?.namespace)).forEach((d) => this.emit(ws, inst, { ...this.mapDaemonSet(d), edges: this.edgesForController(d.spec?.selector?.matchLabels, d.metadata?.namespace, svcList) }, "ADDED"));
    if (rs.status === "fulfilled") rs.value.items.filter((r) => this.nsMatch(inst, r.metadata?.namespace)).forEach((r) => this.emit(ws, inst, this.mapReplicaSet(r), "ADDED"));
    if (jobs.status === "fulfilled") jobs.value.items.filter((j) => this.nsMatch(inst, j.metadata?.namespace)).forEach((j) => this.emit(ws, inst, this.mapJob(j), "ADDED"));
    if (crons.status === "fulfilled") crons.value.items.filter((c) => this.nsMatch(inst, c.metadata?.namespace)).forEach((c) => this.emit(ws, inst, this.mapCronJob(c), "ADDED"));
    if (ings.status === "fulfilled") ings.value.items.filter((i) => this.nsMatch(inst, i.metadata?.namespace)).forEach((i) => this.emit(ws, inst, { ...this.mapIngress(i), edges: this.edgesForIngress(i, svcList) }, "ADDED"));
    if (pods.status === "fulfilled") pods.value.items.filter((p) => this.nsMatch(inst, p.metadata?.namespace)).forEach((p) => this.emit(ws, inst, this.mapPod(p), "ADDED"));
    pvcList.forEach((p) => this.emit(ws, inst, this.mapPvc(p), "ADDED"));
  }
  async sendFocusedSnapshot(ws, inst) {
    const [pods, svcs, deps, sts, ds, rs, jobs, crons, ings, pvcs] = await Promise.allSettled([
      this.clusterInfo.coreApi.listPodForAllNamespaces(),
      this.clusterInfo.coreApi.listServiceForAllNamespaces(),
      this.clusterInfo.appsApi.listDeploymentForAllNamespaces(),
      this.clusterInfo.appsApi.listStatefulSetForAllNamespaces(),
      this.clusterInfo.appsApi.listDaemonSetForAllNamespaces(),
      this.clusterInfo.appsApi.listReplicaSetForAllNamespaces(),
      this.clusterInfo.batchApi.listJobForAllNamespaces(),
      this.clusterInfo.batchApi.listCronJobForAllNamespaces(),
      this.clusterInfo.networkApi.listIngressForAllNamespaces(),
      this.clusterInfo.coreApi.listPersistentVolumeClaimForAllNamespaces()
    ]);
    const ctx = {
      allPods: pods.status === "fulfilled" ? pods.value.items.filter((p) => this.nsMatch(inst, p.metadata?.namespace)) : [],
      allSvcs: svcs.status === "fulfilled" ? svcs.value.items.filter((s) => this.nsMatch(inst, s.metadata?.namespace)) : [],
      allDeps: deps.status === "fulfilled" ? deps.value.items.filter((d) => this.nsMatch(inst, d.metadata?.namespace)) : [],
      allSts: sts.status === "fulfilled" ? sts.value.items.filter((s) => this.nsMatch(inst, s.metadata?.namespace)) : [],
      allDs: ds.status === "fulfilled" ? ds.value.items.filter((d) => this.nsMatch(inst, d.metadata?.namespace)) : [],
      allRs: rs.status === "fulfilled" ? rs.value.items.filter((r) => this.nsMatch(inst, r.metadata?.namespace)) : [],
      allJobs: jobs.status === "fulfilled" ? jobs.value.items.filter((j) => this.nsMatch(inst, j.metadata?.namespace)) : [],
      allCrons: crons.status === "fulfilled" ? crons.value.items.filter((c) => this.nsMatch(inst, c.metadata?.namespace)) : [],
      allIngs: ings.status === "fulfilled" ? ings.value.items.filter((i) => this.nsMatch(inst, i.metadata?.namespace)) : [],
      allPvcs: pvcs.status === "fulfilled" ? pvcs.value.items.filter((p) => this.nsMatch(inst, p.metadata?.namespace)) : [],
      included: /* @__PURE__ */ new Set()
    };
    ctx.allSvcs.forEach((s) => {
      if (s.metadata?.uid) this.serviceCache.set(s.metadata.uid, s);
    });
    ctx.allPvcs.forEach((p) => {
      if (p.metadata?.uid) this.pvcCache.set(p.metadata.uid, p);
    });
    for (const name of inst.pods ?? []) {
      const pod = ctx.allPods.find((p) => p.metadata?.name === name);
      if (pod) this.addPodChain(pod, ctx);
    }
    for (const name of inst.services ?? []) {
      const svc = ctx.allSvcs.find((s) => s.metadata?.name === name);
      if (svc) this.addServiceChain(svc, ctx);
    }
    for (const name of inst.ingresses ?? []) {
      const ing = ctx.allIngs.find((i) => i.metadata?.name === name);
      if (ing) this.addIngressChain(ing, ctx);
    }
    for (const groupStr of inst.groups ?? []) {
      const sep = groupStr.indexOf("/");
      if (sep > 0) this.addGroupChain(groupStr.substring(0, sep), groupStr.substring(sep + 1), ctx);
    }
    inst.focusedUids = ctx.included;
    const inc = ctx.included;
    ctx.allSvcs.filter((s) => inc.has(s.metadata?.uid ?? "")).forEach((s) => this.emit(ws, inst, this.mapService(s), "ADDED"));
    ctx.allDeps.filter((d) => inc.has(d.metadata?.uid ?? "")).forEach((d) => this.emit(ws, inst, { ...this.mapDeployment(d), edges: this.edgesForController(d.spec?.selector?.matchLabels, d.metadata?.namespace, ctx.allSvcs) }, "ADDED"));
    ctx.allSts.filter((s) => inc.has(s.metadata?.uid ?? "")).forEach((s) => this.emit(ws, inst, { ...this.mapStatefulSet(s), edges: this.edgesForController(s.spec?.selector?.matchLabels, s.metadata?.namespace, ctx.allSvcs) }, "ADDED"));
    ctx.allDs.filter((d) => inc.has(d.metadata?.uid ?? "")).forEach((d) => this.emit(ws, inst, { ...this.mapDaemonSet(d), edges: this.edgesForController(d.spec?.selector?.matchLabels, d.metadata?.namespace, ctx.allSvcs) }, "ADDED"));
    ctx.allRs.filter((r) => inc.has(r.metadata?.uid ?? "")).forEach((r) => this.emit(ws, inst, this.mapReplicaSet(r), "ADDED"));
    ctx.allJobs.filter((j) => inc.has(j.metadata?.uid ?? "")).forEach((j) => this.emit(ws, inst, this.mapJob(j), "ADDED"));
    ctx.allCrons.filter((c) => inc.has(c.metadata?.uid ?? "")).forEach((c) => this.emit(ws, inst, this.mapCronJob(c), "ADDED"));
    ctx.allIngs.filter((i) => inc.has(i.metadata?.uid ?? "")).forEach((i) => this.emit(ws, inst, { ...this.mapIngress(i), edges: this.edgesForIngress(i, ctx.allSvcs) }, "ADDED"));
    ctx.allPods.filter((p) => inc.has(p.metadata?.uid ?? "")).forEach((p) => this.emit(ws, inst, this.mapPod(p), "ADDED"));
    ctx.allPvcs.filter((p) => inc.has(p.metadata?.uid ?? "")).forEach((p) => this.emit(ws, inst, this.mapPvc(p), "ADDED"));
  }
  addPodChain(pod, ctx) {
    const uid = pod.metadata?.uid ?? "";
    if (ctx.included.has(uid)) return;
    ctx.included.add(uid);
    const podNs = pod.metadata?.namespace;
    for (const vol of pod.spec?.volumes ?? []) {
      const claimName = vol.persistentVolumeClaim?.claimName;
      if (!claimName) continue;
      const pvc = ctx.allPvcs.find((p) => p.metadata?.name === claimName && p.metadata?.namespace === podNs);
      if (pvc?.metadata?.uid) ctx.included.add(pvc.metadata.uid);
    }
    for (const ownerRef of pod.metadata?.ownerReferences ?? []) {
      if (ownerRef.kind === "ReplicaSet") {
        const rs = ctx.allRs.find((r) => r.metadata?.uid === ownerRef.uid);
        if (rs) {
          ctx.included.add(rs.metadata?.uid ?? "");
          for (const rsOwner of rs.metadata?.ownerReferences ?? []) {
            if (rsOwner.kind === "Deployment") {
              const dep = ctx.allDeps.find((d) => d.metadata?.uid === rsOwner.uid);
              if (dep?.metadata?.uid) ctx.included.add(dep.metadata.uid);
            }
          }
        }
      } else if (ownerRef.kind === "StatefulSet") {
        const sts = ctx.allSts.find((s) => s.metadata?.uid === ownerRef.uid);
        if (sts?.metadata?.uid) ctx.included.add(sts.metadata.uid);
      } else if (ownerRef.kind === "DaemonSet") {
        const ds = ctx.allDs.find((d) => d.metadata?.uid === ownerRef.uid);
        if (ds?.metadata?.uid) ctx.included.add(ds.metadata.uid);
      } else if (ownerRef.kind === "Job") {
        const job = ctx.allJobs.find((j) => j.metadata?.uid === ownerRef.uid);
        if (job) {
          ctx.included.add(job.metadata?.uid ?? "");
          for (const jobOwner of job.metadata?.ownerReferences ?? []) {
            if (jobOwner.kind === "CronJob") {
              const cron = ctx.allCrons.find((c) => c.metadata?.uid === jobOwner.uid);
              if (cron?.metadata?.uid) ctx.included.add(cron.metadata.uid);
            }
          }
        }
      }
    }
    const podLabels = pod.metadata?.labels ?? {};
    for (const svc of ctx.allSvcs) {
      if (svc.metadata?.namespace !== podNs) continue;
      const sel = svc.spec?.selector ?? {};
      if (Object.keys(sel).length > 0 && Object.entries(sel).every(([k, v]) => podLabels[k] === v)) {
        ctx.included.add(svc.metadata?.uid ?? "");
        this.addIngressForService(svc, ctx);
      }
    }
  }
  addIngressForService(svc, ctx) {
    for (const ing of ctx.allIngs) {
      if (ing.metadata?.namespace !== svc.metadata?.namespace) continue;
      for (const rule of ing.spec?.rules ?? []) {
        for (const path of rule.http?.paths ?? []) {
          if (path.backend?.service?.name === svc.metadata?.name) {
            ctx.included.add(ing.metadata?.uid ?? "");
          }
        }
      }
    }
  }
  addServiceChain(svc, ctx) {
    if (ctx.included.has(svc.metadata?.uid ?? "")) return;
    ctx.included.add(svc.metadata?.uid ?? "");
    this.addIngressForService(svc, ctx);
    const sel = svc.spec?.selector ?? {};
    if (Object.keys(sel).length === 0) return;
    const svcNs = svc.metadata?.namespace;
    for (const pod of ctx.allPods) {
      if (pod.metadata?.namespace !== svcNs) continue;
      const podLabels = pod.metadata?.labels ?? {};
      if (Object.entries(sel).every(([k, v]) => podLabels[k] === v)) {
        this.addPodChain(pod, ctx);
      }
    }
  }
  addIngressChain(ing, ctx) {
    if (ctx.included.has(ing.metadata?.uid ?? "")) return;
    ctx.included.add(ing.metadata?.uid ?? "");
    const ingNs = ing.metadata?.namespace;
    for (const rule of ing.spec?.rules ?? []) {
      for (const path of rule.http?.paths ?? []) {
        const svcName = path.backend?.service?.name;
        const svc = ctx.allSvcs.find((s) => s.metadata?.namespace === ingNs && s.metadata?.name === svcName);
        if (svc) this.addServiceChain(svc, ctx);
      }
    }
  }
  addGroupChain(kind, name, ctx) {
    switch (kind) {
      case "Deployment": {
        const dep = ctx.allDeps.find((d) => d.metadata?.name === name);
        if (!dep?.metadata?.uid) return;
        ctx.included.add(dep.metadata.uid);
        for (const rs of ctx.allRs) {
          if (!rs.metadata?.ownerReferences?.some((r) => r.uid === dep.metadata?.uid)) continue;
          ctx.included.add(rs.metadata?.uid ?? "");
          ctx.allPods.filter((p) => p.metadata?.ownerReferences?.some((r) => r.uid === rs.metadata?.uid)).forEach((p) => this.addPodChain(p, ctx));
        }
        break;
      }
      case "StatefulSet": {
        const sts = ctx.allSts.find((s) => s.metadata?.name === name);
        if (!sts?.metadata?.uid) return;
        ctx.included.add(sts.metadata.uid);
        ctx.allPods.filter((p) => p.metadata?.ownerReferences?.some((r) => r.uid === sts.metadata?.uid)).forEach((p) => this.addPodChain(p, ctx));
        break;
      }
      case "DaemonSet": {
        const ds = ctx.allDs.find((d) => d.metadata?.name === name);
        if (!ds?.metadata?.uid) return;
        ctx.included.add(ds.metadata.uid);
        ctx.allPods.filter((p) => p.metadata?.ownerReferences?.some((r) => r.uid === ds.metadata?.uid)).forEach((p) => this.addPodChain(p, ctx));
        break;
      }
      case "ReplicaSet": {
        const rs = ctx.allRs.find((r) => r.metadata?.name === name);
        if (!rs?.metadata?.uid) return;
        ctx.included.add(rs.metadata.uid);
        ctx.allPods.filter((p) => p.metadata?.ownerReferences?.some((r) => r.uid === rs.metadata?.uid)).forEach((p) => this.addPodChain(p, ctx));
        break;
      }
      case "Job": {
        const job = ctx.allJobs.find((j) => j.metadata?.name === name);
        if (!job?.metadata?.uid) return;
        ctx.included.add(job.metadata.uid);
        ctx.allPods.filter((p) => p.metadata?.ownerReferences?.some((r) => r.uid === job.metadata?.uid)).forEach((p) => this.addPodChain(p, ctx));
        break;
      }
      case "CronJob": {
        const cron = ctx.allCrons.find((c) => c.metadata?.name === name);
        if (!cron?.metadata?.uid) return;
        ctx.included.add(cron.metadata.uid);
        for (const job of ctx.allJobs.filter((j) => j.metadata?.ownerReferences?.some((r) => r.uid === cron.metadata?.uid))) {
          ctx.included.add(job.metadata?.uid ?? "");
          ctx.allPods.filter((p) => p.metadata?.ownerReferences?.some((r) => r.uid === job.metadata?.uid)).forEach((p) => this.addPodChain(p, ctx));
        }
        break;
      }
    }
  }
  mapResource(resource) {
    switch (resource.kind) {
      case "Pod":
        return this.mapPod(resource);
      case "Service":
        return this.mapService(resource);
      case "Deployment":
        return this.mapDeployment(resource);
      case "StatefulSet":
        return this.mapStatefulSet(resource);
      case "DaemonSet":
        return this.mapDaemonSet(resource);
      case "ReplicaSet":
        return this.mapReplicaSet(resource);
      case "Job":
        return this.mapJob(resource);
      case "CronJob":
        return this.mapCronJob(resource);
      case "Ingress":
        return this.mapIngress(resource);
      case "PersistentVolumeClaim":
        return this.mapPvc(resource);
      default:
        return null;
    }
  }
  computeEdges(resource, svcList) {
    switch (resource.kind) {
      case "Deployment":
      case "StatefulSet":
      case "DaemonSet":
        return this.edgesForController(resource.spec?.selector?.matchLabels, resource.metadata?.namespace, svcList);
      case "Ingress":
        return this.edgesForIngress(resource, svcList);
      default:
        return [];
    }
  }
  mapPod(p) {
    const ns = p.metadata?.namespace ?? "";
    const pvcEdges = [];
    for (const vol of p.spec?.volumes ?? []) {
      const claimName = vol.persistentVolumeClaim?.claimName;
      if (!claimName) continue;
      for (const pvc of this.pvcCache.values()) {
        if (pvc.metadata?.name === claimName && pvc.metadata?.namespace === ns && pvc.metadata?.uid) {
          pvcEdges.push({ targetUid: pvc.metadata.uid, label: vol.name });
          break;
        }
      }
    }
    return {
      kind: "Pod",
      uid: p.metadata?.uid ?? "",
      name: p.metadata?.name ?? "",
      namespace: ns,
      status: podStatus(p),
      labels: p.metadata?.labels ?? {},
      image: p.spec?.containers?.[0]?.image,
      containers: p.spec?.containers?.map((c) => c.name) ?? [],
      ownerUids: p.metadata?.ownerReferences?.map((r) => r.uid) ?? [],
      edges: pvcEdges.length > 0 ? pvcEdges : void 0
    };
  }
  mapService(s) {
    return {
      kind: "Service",
      uid: s.metadata?.uid ?? "",
      name: s.metadata?.name ?? "",
      namespace: s.metadata?.namespace ?? "",
      status: "Running",
      labels: s.metadata?.labels ?? {},
      ports: s.spec?.ports?.map((p) => p.port) ?? []
    };
  }
  mapDeployment(d) {
    const ready = d.status?.readyReplicas ?? 0;
    const desired = d.spec?.replicas ?? 0;
    const avail = d.status?.availableReplicas ?? 0;
    const status = desired === 0 ? "Unknown" : ready === desired && avail === desired ? "Running" : ready > 0 ? "Pending" : "Failed";
    return {
      kind: "Deployment",
      uid: d.metadata?.uid ?? "",
      name: d.metadata?.name ?? "",
      namespace: d.metadata?.namespace ?? "",
      status,
      labels: d.metadata?.labels ?? {},
      replicas: desired,
      readyReplicas: ready
    };
  }
  mapStatefulSet(s) {
    return {
      kind: "StatefulSet",
      uid: s.metadata?.uid ?? "",
      name: s.metadata?.name ?? "",
      namespace: s.metadata?.namespace ?? "",
      status: controllerStatus(s.status?.readyReplicas, s.spec?.replicas),
      labels: s.metadata?.labels ?? {},
      replicas: s.spec?.replicas ?? 0,
      readyReplicas: s.status?.readyReplicas ?? 0
    };
  }
  mapDaemonSet(d) {
    return {
      kind: "DaemonSet",
      uid: d.metadata?.uid ?? "",
      name: d.metadata?.name ?? "",
      namespace: d.metadata?.namespace ?? "",
      status: controllerStatus(d.status?.numberReady, d.status?.desiredNumberScheduled),
      labels: d.metadata?.labels ?? {},
      replicas: d.status?.desiredNumberScheduled ?? 0,
      readyReplicas: d.status?.numberReady ?? 0
    };
  }
  mapReplicaSet(r) {
    return {
      kind: "ReplicaSet",
      uid: r.metadata?.uid ?? "",
      name: r.metadata?.name ?? "",
      namespace: r.metadata?.namespace ?? "",
      status: controllerStatus(r.status?.readyReplicas, r.spec?.replicas),
      labels: r.metadata?.labels ?? {},
      replicas: r.spec?.replicas ?? 0,
      readyReplicas: r.status?.readyReplicas ?? 0,
      ownerUids: r.metadata?.ownerReferences?.map((ref) => ref.uid) ?? []
    };
  }
  mapJob(j) {
    const status = (j.status?.succeeded ?? 0) > 0 ? "Succeeded" : (j.status?.active ?? 0) > 0 ? "Running" : "Unknown";
    return {
      kind: "Job",
      uid: j.metadata?.uid ?? "",
      name: j.metadata?.name ?? "",
      namespace: j.metadata?.namespace ?? "",
      status,
      labels: j.metadata?.labels ?? {},
      ownerUids: j.metadata?.ownerReferences?.map((ref) => ref.uid) ?? []
    };
  }
  mapCronJob(c) {
    return {
      kind: "CronJob",
      uid: c.metadata?.uid ?? "",
      name: c.metadata?.name ?? "",
      namespace: c.metadata?.namespace ?? "",
      status: (c.status?.active?.length ?? 0) > 0 ? "Running" : "Unknown",
      labels: c.metadata?.labels ?? {}
    };
  }
  mapIngress(i) {
    return {
      kind: "Ingress",
      uid: i.metadata?.uid ?? "",
      name: i.metadata?.name ?? "",
      namespace: i.metadata?.namespace ?? "",
      status: "Running",
      labels: i.metadata?.labels ?? {},
      host: i.spec?.rules?.[0]?.host
    };
  }
  mapPvc(p) {
    return {
      kind: "PersistentVolumeClaim",
      uid: p.metadata?.uid ?? "",
      name: p.metadata?.name ?? "",
      namespace: p.metadata?.namespace ?? "",
      status: pvcStatus(p),
      labels: p.metadata?.labels ?? {},
      storageClass: p.spec?.storageClassName,
      capacity: p.status?.capacity?.["storage"],
      accessModes: p.spec?.accessModes
    };
  }
  edgesForController(matchLabels, namespace, services) {
    if (!matchLabels) return [];
    return services.filter((s) => {
      if (s.metadata?.namespace !== namespace) return false;
      const sel = s.spec?.selector ?? {};
      return Object.entries(sel).every(([k, v]) => matchLabels[k] === v);
    }).filter((s) => !!s.metadata?.uid).map((s) => ({ targetUid: s.metadata.uid, label: "exposes" }));
  }
  edgesForIngress(ingress, services) {
    const ns = ingress.metadata?.namespace;
    const edges = [];
    for (const rule of ingress.spec?.rules ?? []) {
      for (const path of rule.http?.paths ?? []) {
        const svcName = path.backend?.service?.name;
        const svc = services.find((s) => s.metadata?.namespace === ns && s.metadata?.name === svcName);
        if (svc?.metadata?.uid) edges.push({ targetUid: svc.metadata.uid, label: path.path ?? "/" });
      }
    }
    return edges;
  }
  emit(ws, inst, partial, topoAction) {
    if (inst.paused) return;
    const msg = {
      action: import_kwirth_common.EInstanceMessageAction.NONE,
      flow: import_kwirth_common.EInstanceMessageFlow.UNSOLICITED,
      channel: "topology",
      instance: inst.instanceId,
      type: import_kwirth_common.EInstanceMessageType.DATA,
      topoAction,
      kind: partial.kind,
      uid: partial.uid,
      name: partial.name,
      namespace: partial.namespace,
      status: partial.status,
      labels: partial.labels ?? {},
      annotations: partial.annotations,
      replicas: partial.replicas,
      readyReplicas: partial.readyReplicas,
      image: partial.image,
      ports: partial.ports,
      host: partial.host,
      storageClass: partial.storageClass,
      capacity: partial.capacity,
      accessModes: partial.accessModes,
      edges: partial.edges,
      ownerUids: partial.ownerUids,
      containers: partial.containers
    };
    try {
      ws.send(JSON.stringify(msg));
    } catch (err) {
      console.warn("[TopologyChannel] send error", err);
    }
  }
  sendInstanceConfig(ws, action, flow, cfg, text) {
    const resp = {
      action,
      flow,
      channel: "topology",
      instance: cfg.instance,
      type: import_kwirth_common.EInstanceMessageType.SIGNAL,
      text
    };
    try {
      ws.send(JSON.stringify(resp));
    } catch (err) {
      console.warn("[TopologyChannel] sendInstanceConfig error", err);
    }
  }
  sendSignal(ws, msg, level, text) {
    const sig = {
      action: import_kwirth_common.EInstanceMessageAction.NONE,
      flow: import_kwirth_common.EInstanceMessageFlow.RESPONSE,
      level,
      channel: "topology",
      instance: msg.instance,
      type: import_kwirth_common.EInstanceMessageType.SIGNAL,
      text
    };
    try {
      ws.send(JSON.stringify(sig));
    } catch (err) {
      console.warn("[TopologyChannel] sendSignal error", err);
    }
  }
  async doScale(ws, msg, kind, ns, name, replicas) {
    const patch = [{ op: "replace", path: "/spec/replicas", value: replicas }];
    switch (kind) {
      case "Deployment":
        await this.clusterInfo.appsApi.patchNamespacedDeployment({ name, namespace: ns, body: patch });
        break;
      case "StatefulSet":
        await this.clusterInfo.appsApi.patchNamespacedStatefulSet({ name, namespace: ns, body: patch });
        break;
      case "ReplicaSet":
        await this.clusterInfo.appsApi.patchNamespacedReplicaSet({ name, namespace: ns, body: patch });
        break;
    }
    this.sendSignal(ws, msg, import_kwirth_common.ESignalMessageLevel.INFO, `${kind} ${name} scaled to ${replicas}`);
  }
  async doRestart(ws, msg, kind, ns, name) {
    const patch = [{ op: "add", path: "/spec/template/metadata/annotations", value: { "kubectl.kubernetes.io/restartedAt": (/* @__PURE__ */ new Date()).toISOString() } }];
    switch (kind) {
      case "Deployment":
        await this.clusterInfo.appsApi.patchNamespacedDeployment({ name, namespace: ns, body: patch });
        break;
      case "StatefulSet":
        await this.clusterInfo.appsApi.patchNamespacedStatefulSet({ name, namespace: ns, body: patch });
        break;
      case "DaemonSet":
        await this.clusterInfo.appsApi.patchNamespacedDaemonSet({ name, namespace: ns, body: patch });
        break;
    }
    this.sendSignal(ws, msg, import_kwirth_common.ESignalMessageLevel.INFO, `${kind} ${name} restart triggered`);
  }
  findInstance(ws, instanceId) {
    return this.webSockets.find((s) => s.ws === ws)?.instances.find((i) => i.instanceId === instanceId);
  }
};
var index_default = TopologyChannel;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TopologyChannel
});
