# Censor

A pack for **[Kwirth](https://kwirthmagnify.dev)**: several extensions installed together, as one.

Censor pack for Kwirth - LLM-based log noise filtering channel plus its custom login page

> **Kwirth** is an open-source Kubernetes observability and operations tool: logs, metrics, events
> and more, in real time, extended with plugins.
> Website: **https://kwirthmagnify.dev** · Source: **https://github.com/kwirthmagnify/kwirth**

## What it installs

| Type | Id | Version |
|---|---|---|
| plugin | `censor` | 0.2.52 |
| login | `censor` | 0.1.5 |

## Installing it

From Kwirth: **☰ → Manage extensions → Packs**, find it in the marketplace and
install it. Every member is validated before any of them is installed, so a pack either goes in
whole or not at all.
